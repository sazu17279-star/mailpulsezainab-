# MailPulse — Complete Production Package

**Watermark-free email tracking · Multi-account Gmail (up to 10) · Campaigns · US state scheduler · Chrome MV3 extension**

This archive contains the full web application (React + Vite + Vercel API routes) and the Chrome Extension (Manifest V3).

---

## Package contents

```
MailPulse/
├── MAILPULSE-README.md          ← this file (start here)
├── package.json                 ← frontend dependencies
├── vite.config.ts / tsconfig.*  ← build config
├── index.html
├── src/                         ← React dashboard (slate-grey + soft-blue UI)
│   ├── pages/                   ← Dashboard, Composer, Campaigns, Scheduler, Settings…
│   ├── components/              ← GmailAccountPicker, Layout, etc.
│   └── lib/                     ← gmail OAuth, API client, US timezones
├── api/                         ← Vercel serverless API routes
│   ├── track-prepare.js         ← watermark-free pixel prep
│   ├── track-open.js / track-click.js
│   ├── extension-bridge.js      ← extension ↔ dashboard notifications
│   ├── gmail-send.js            ← multi-account Gmail dispatch
│   ├── schedule.js              ← US state timezone scheduler
│   ├── campaigns.js / recipients.js / stats.js / …
│   └── reset-data.js            ← wipe to pure zero-state
├── extension/                   ← Chrome MV3 (also as mailpulse-extension.zip)
│   ├── manifest.json
│   ├── background.js            ← service worker (alerts + chrome.identity)
│   ├── content.js               ← Gmail compose toolbar + tracking toggle
│   ├── content.css
│   ├── popup.html / popup.js / popup.css
│   ├── icons/
│   └── README.md
├── public/
│   ├── mailpulse-extension.zip  ← extension-only zip for quick Load unpacked
│   ├── favicon.svg
│   ├── help/chrome.html
│   └── oauth/gmail/callback/    ← standalone OAuth popup callback (no iframe)
└── dist/                        ← production build (after npm run build)
```

---

## 1) Run the web dashboard

### Requirements
- Node.js 18+
- A Supabase project (Postgres) — set env vars (see below)
- Optional: Google OAuth client for Gmail connect

### Install & build
```bash
cd MailPulse
npm install
cp .env.example .env   # if provided — or set vars in your host
npm run build
```

### Environment variables
```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
VITE_SUPABASE_URL=              # same as NEXT_PUBLIC_SUPABASE_URL
VITE_SUPABASE_ANON_KEY=
VITE_GOOGLE_CLIENT_ID=          # Web OAuth client ID
```

### Deploy (Vercel)
- Import this folder as a Vercel project
- `api/` becomes serverless functions automatically
- Set the env vars in the Vercel dashboard
- Add OAuth redirect URI: `https://YOUR-DOMAIN/oauth/gmail/callback`

### Database tables
Create (if not already present) via your Supabase SQL or the app’s tooling:

- `mp_campaigns`
- `mp_recipients`
- `mp_tracking_events`
- `mp_notifications`
- `mp_templates`

The app ships in a **pure clean state** — no seeded campaigns, stats start at **0**.

---

## 2) Install the Chrome Extension (Load unpacked)

### Option A — From the nested folder
1. Open Chrome → `chrome://extensions`
2. Enable **Developer mode** (top right)
3. Click **Load unpacked**
4. Select the `extension/` folder inside this package

### Option B — From the extension-only zip
1. Unzip `public/mailpulse-extension.zip` (or `mailpulse-extension.zip` at package root)
2. Load the unzipped folder via **Load unpacked**

### After install
1. Open the extension popup
2. Paste your MailPulse dashboard URL (e.g. `https://your-app.vercel.app`)
3. Click **Save & sync**
4. Click **Add account** to connect Gmail (uses `chrome.identity` / `launchWebAuthFlow` — **never an iframe**)
5. Open [Gmail](https://mail.google.com) → Compose — the **MailPulse** bar appears with:
   - **From** account switcher (up to 10 accounts)
   - **Tracking on/off** toggle
   - Inject pixel (zero watermark)

### Link extension to the web dashboard
1. Copy the **Extension ID** from `chrome://extensions`
2. In the dashboard → **Extension** or **Settings** → paste Extension ID → Save & ping
3. Connect Gmail from Settings (standalone popup) or from the extension popup

### Google Cloud OAuth notes (avoid “refused to connect”)
- **Do not** embed `accounts.google.com` in iframes
- Extension: OAuth client type **Chrome Extension** + your extension ID
- Web: OAuth client type **Web** + redirect  
  `https://YOUR-DOMAIN/oauth/gmail/callback`
- Enable Gmail API scopes: `gmail.send`, `gmail.compose`, userinfo email/profile

---

## 3) Product features checklist

| Feature | Status |
|--------|--------|
| Slate-grey + soft-blue dashboard | ✓ |
| Multi-account Gmail (max 10) | ✓ |
| Per-email token isolation (no leakage) | ✓ |
| Campaign composer + bulk paste recipients | ✓ |
| Instant dispatch with **10-second** pacing | ✓ |
| US state–specific timezone scheduler | ✓ |
| Watermark-free open pixel + click redirects | ✓ |
| `/api/track-prepare`, `/api/extension-bridge` | ✓ |
| Real-time desktop notifications (extension SW) | ✓ |
| Zero pre-seeded metrics / clean state | ✓ |
| Gmail compose toolbar toggle | ✓ |

---

## 4) Instant dispatch pacing

Campaign send loops enforce a **strict 10 second** gap between sequential emails (`INSTANT_DISPATCH_GAP_MS = 10000`) to protect deliverability.

---

## 5) Clean / reset data

Dashboard → **Settings** → “Wipe all tracking data”  
or `POST /api/reset-data` with body `{ "confirm": "RESET_ALL_DATA" }`

---

## 6) Support tips

- **Popup blocked** on Connect Gmail → allow popups for the dashboard origin  
- **Token expired** → re-connect that specific account from the account switcher  
- **Extension not pinging** → reload extension, re-save dashboard URL + Extension ID  
- **Gmail bar missing** → hard-refresh Gmail after loading the extension  

---

© MailPulse — free tracking, zero watermark, multi-account Gmail.
