import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Trash2, Search } from 'lucide-react';
import { api } from '../lib/api';
import type { Campaign } from '../lib/types';
import StatusBadge from '../components/StatusBadge';
import LoadingState, { EmptyState } from '../components/LoadingState';
import { formatDateTime } from '../lib/storage';

export default function Campaigns() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [q, setQ] = useState('');
  const [deleting, setDeleting] = useState<number | null>(null);

  const load = async () => {
    try {
      setError('');
      const data = await api.getCampaigns();
      setCampaigns(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const filtered = campaigns.filter(
    (c) =>
      c.name.toLowerCase().includes(q.toLowerCase()) ||
      c.subject.toLowerCase().includes(q.toLowerCase())
  );

  const remove = async (id: number) => {
    if (!confirm('Delete this campaign and all tracking data?')) return;
    setDeleting(id);
    try {
      await api.deleteCampaign(id);
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Delete failed');
    } finally {
      setDeleting(null);
    }
  };

  if (loading) return <LoadingState />;

  return (
    <div className="max-w-6xl space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-semibold tracking-tight text-slate-850">Campaigns</h1>
          <p className="text-sm text-slate-500 mt-1">Manage drafts, scheduled sends, and live tracking.</p>
        </div>
        <Link
          to="/composer"
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-soft-blue text-white text-sm font-semibold shadow-lg shadow-blue-500/25"
        >
          <Plus className="h-4 w-4" /> Compose
        </Link>
      </div>

      {error && (
        <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div>
      )}

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search campaigns…"
          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-soft-blue/30 focus:border-soft-blue"
        />
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          title="No campaigns found"
          description="Create a campaign from the composer — paste recipients, personalize, and track opens invisibly."
        />
      ) : (
        <div className="grid gap-3">
          {filtered.map((c) => (
            <div
              key={c.id}
              className="rounded-2xl border border-slate-200/80 bg-white p-4 md:p-5 shadow-sm flex flex-col md:flex-row md:items-center gap-4"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <Link to={`/campaigns/${c.id}`} className="font-semibold text-slate-850 hover:text-soft-blue">
                    {c.name}
                  </Link>
                  <StatusBadge status={c.status} />
                </div>
                <div className="text-sm text-slate-500 mt-0.5 truncate">{c.subject}</div>
                <div className="text-xs text-slate-400 mt-2 font-mono">
                  {formatDateTime(c.created_at)}
                  {c.schedule_at ? ` · scheduled ${formatDateTime(c.schedule_at)}` : ''}
                </div>
              </div>
              <div className="flex items-center gap-4 text-center">
                <div>
                  <div className="text-lg font-semibold text-slate-800 font-mono">{c.sent_count || 0}</div>
                  <div className="text-[10px] uppercase tracking-wide text-slate-400">Sent</div>
                </div>
                <div>
                  <div className="text-lg font-semibold text-slate-800 font-mono">{c.open_count || 0}</div>
                  <div className="text-[10px] uppercase tracking-wide text-slate-400">Opens</div>
                </div>
                <div>
                  <div className="text-lg font-semibold text-slate-800 font-mono">{c.click_count || 0}</div>
                  <div className="text-[10px] uppercase tracking-wide text-slate-400">Clicks</div>
                </div>
                <button
                  onClick={() => remove(c.id)}
                  disabled={deleting === c.id}
                  className="ml-2 h-9 w-9 rounded-lg border border-slate-200 text-slate-400 hover:text-rose-600 hover:border-rose-200 flex items-center justify-center"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
