import { useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Clock, MapPin, CalendarCheck, Search, Zap, Sparkles, SlidersHorizontal } from 'lucide-react';
import { api } from '../lib/api';
import type { Campaign } from '../lib/types';
import LoadingState from '../components/LoadingState';
import StatusBadge from '../components/StatusBadge';
import { formatDateTime, loadSettings } from '../lib/storage';
import {
  DEFAULT_US_STATE,
  US_STATE_TIMEZONES,
  findUsState,
  INSTANT_DISPATCH_GAP_MS,
  SCHEDULE_WINDOW_PRESETS,
  type SchedulePresetId,
  formatHourMinute,
} from '../lib/usTimezones';

type UsStateRow = {
  code: string;
  name: string;
  timezone: string;
  abbr: string;
  offset_hours: number;
  next_send_at: string;
  label: string;
  local_hour: number;
  local_minute?: number;
  local_time?: string;
  window_start?: string;
  window_end?: string;
};

const HOUR_OPTIONS = Array.from({ length: 24 }, (_, h) => h);
const MINUTE_OPTIONS = [0, 15, 30, 45];

export default function Scheduler() {
  const location = useLocation();
  const presetId = (location.state as { campaignId?: number } | null)?.campaignId;
  const settings = loadSettings();

  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [usStates, setUsStates] = useState<UsStateRow[]>([]);
  const [campaignId, setCampaignId] = useState<number | ''>(presetId || '');
  const [usState, setUsState] = useState(DEFAULT_US_STATE);
  const [windowPreset, setWindowPreset] = useState<SchedulePresetId>('smart');
  const [customHour, setCustomHour] = useState(settings.defaultSendHour ?? 10);
  const [customMinute, setCustomMinute] = useState(0);
  const [customStartH, setCustomStartH] = useState(9);
  const [customStartM, setCustomStartM] = useState(0);
  const [customEndH, setCustomEndH] = useState(16);
  const [customEndM, setCustomEndM] = useState(0);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [windowMeta, setWindowMeta] = useState<string>('');

  const activePreset =
    SCHEDULE_WINDOW_PRESETS.find((p) => p.id === windowPreset) || SCHEDULE_WINDOW_PRESETS[0];

  const scheduleQuery = useMemo(() => {
    if (windowPreset === 'custom') {
      return {
        preset: 'custom' as const,
        mode: 'custom',
        start_hour: customStartH,
        start_minute: customStartM,
        end_hour: customEndH,
        end_minute: customEndM,
        target_hour: customHour,
        target_minute: customMinute,
      };
    }
    return {
      preset: windowPreset,
      mode: activePreset.mode,
      start_hour: activePreset.start_hour,
      start_minute: activePreset.start_minute,
      end_hour: activePreset.end_hour,
      end_minute: activePreset.end_minute,
    };
  }, [
    windowPreset,
    activePreset,
    customHour,
    customMinute,
    customStartH,
    customStartM,
    customEndH,
    customEndM,
  ]);

  const load = async () => {
    try {
      setError('');
      const [c, z] = await Promise.all([api.getCampaigns(), api.getScheduleZones(scheduleQuery)]);
      setCampaigns(c);
      setUsStates(z.us_states || []);
      if (z.window?.label) setWindowMeta(z.window.label);
      if (!campaignId && c.length) setCampaignId(c[0].id);

      const fromSettings = US_STATE_TIMEZONES.find((s) => s.timezone === settings.defaultTimezone);
      if (fromSettings) setUsState(fromSettings.code);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    setLoading(true);
    api
      .getScheduleZones(scheduleQuery)
      .then((z) => {
        setUsStates(z.us_states || []);
        if (z.window?.label) setWindowMeta(z.window.label);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [scheduleQuery]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = usStates.length
      ? usStates
      : US_STATE_TIMEZONES.map((s) => ({
          ...s,
          offset_hours: 0,
          next_send_at: '',
          label: s.name,
          local_hour: customHour,
          local_time: formatHourMinute(customHour, customMinute),
        }));
    if (!q) return list;
    return list.filter(
      (s) =>
        s.name.toLowerCase().includes(q) ||
        s.code.toLowerCase().includes(q) ||
        s.timezone.toLowerCase().includes(q) ||
        s.abbr.toLowerCase().includes(q)
    );
  }, [usStates, query, customHour, customMinute]);

  const selected: UsStateRow = (() => {
    const fromApi = usStates.find((s) => s.code === usState);
    if (fromApi) return fromApi;
    const local = findUsState(usState) || US_STATE_TIMEZONES.find((s) => s.code === DEFAULT_US_STATE)!;
    return {
      code: local.code,
      name: local.name,
      timezone: local.timezone,
      abbr: local.abbr,
      offset_hours: 0,
      next_send_at: '',
      label: `${local.name} (${local.code}) · ${local.abbr}`,
      local_hour: customHour,
      local_time: formatHourMinute(customHour, customMinute),
    };
  })();

  const schedule = async () => {
    if (!campaignId) {
      setError('Select a campaign');
      return;
    }
    setSaving(true);
    setError('');
    setMessage('');
    try {
      const res = await api.scheduleCampaign({
        campaign_id: Number(campaignId),
        us_state: usState,
        timezone: selected.timezone,
        preset: windowPreset,
        window_preset: windowPreset,
        mode: scheduleQuery.mode,
        start_hour: scheduleQuery.start_hour,
        start_minute: scheduleQuery.start_minute,
        end_hour: scheduleQuery.end_hour,
        end_minute: scheduleQuery.end_minute,
        target_hour: windowPreset === 'custom' ? customHour : undefined,
        target_minute: windowPreset === 'custom' ? customMinute : undefined,
        throttle_ms: INSTANT_DISPATCH_GAP_MS,
      });
      const localLabel = res.local_time || formatHourMinute(res.local_hour, res.local_minute || 0);
      const winLabel = res.window
        ? `${res.window.start}–${res.window.end} (${res.window.mode})`
        : windowMeta;
      setMessage(
        `${res.message} · fires ${formatDateTime(res.scheduled_for)} UTC · local ${localLabel} · window ${winLabel}. After release, instant dispatch uses a ${INSTANT_DISPATCH_GAP_MS / 1000}s gap between emails.`
      );
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Schedule failed');
    } finally {
      setSaving(false);
    }
  };

  if (loading && !usStates.length) return <LoadingState />;

  return (
    <div className="max-w-5xl space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight text-slate-850 flex items-center gap-2">
          <Clock className="h-7 w-7 text-soft-blue" />
          US state smart scheduler
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Map each US state to its timezone, then choose a <strong className="text-slate-700">flexible engagement window</strong>{' '}
          — morning, afternoon, or auto peak. No longer locked to 9:00 AM. Instant send still uses a strict{' '}
          {INSTANT_DISPATCH_GAP_MS / 1000}s gap between messages.
        </p>
      </div>

      {error && (
        <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div>
      )}
      {message && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
          {message}
        </div>
      )}

      <div className="grid lg:grid-cols-5 gap-5">
        <div className="lg:col-span-3 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
          <div>
            <label className="text-xs font-semibold uppercase tracking-wide text-slate-400">Campaign</label>
            <select
              value={campaignId}
              onChange={(e) => setCampaignId(Number(e.target.value))}
              className="mt-1.5 w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm"
            >
              {campaigns.length === 0 && <option value="">No campaigns yet</option>}
              {campaigns.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.status})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs font-semibold uppercase tracking-wide text-slate-400 flex items-center gap-1.5">
              <MapPin className="h-3.5 w-3.5" /> Recipient US state
            </label>
            <select
              value={usState}
              onChange={(e) => setUsState(e.target.value)}
              className="mt-1.5 w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm"
            >
              {US_STATE_TIMEZONES.map((s) => (
                <option key={s.code} value={s.code}>
                  {s.name} ({s.code}) — {s.abbr} · {s.timezone}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs font-semibold uppercase tracking-wide text-slate-400 flex items-center gap-1.5">
              <Sparkles className="h-3.5 w-3.5" /> Engagement window
            </label>
            <div className="mt-2 grid sm:grid-cols-2 gap-2">
              {SCHEDULE_WINDOW_PRESETS.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setWindowPreset(p.id)}
                  className={`text-left p-3 rounded-xl border transition-colors ${
                    windowPreset === p.id
                      ? 'border-soft-blue bg-blue-50/60 ring-1 ring-soft-blue/20'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="text-sm font-semibold text-slate-800">{p.label}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5 leading-snug">{p.description}</div>
                  {p.id !== 'custom' && (
                    <div className="text-[10px] font-mono text-soft-blue mt-1.5">
                      {formatHourMinute(p.start_hour, p.start_minute)}–
                      {formatHourMinute(p.end_hour, p.end_minute)}
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>

          {windowPreset === 'custom' && (
            <div className="rounded-xl border border-slate-200 bg-slate-50/80 p-4 space-y-3">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-800">
                <SlidersHorizontal className="h-4 w-4 text-soft-blue" />
                Custom local time
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] uppercase text-slate-400 font-semibold">Send hour</label>
                  <select
                    value={customHour}
                    onChange={(e) => setCustomHour(Number(e.target.value))}
                    className="mt-1 w-full px-2 py-2 rounded-lg border border-slate-200 text-sm"
                  >
                    {HOUR_OPTIONS.map((h) => (
                      <option key={h} value={h}>
                        {formatHourMinute(h, 0)}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[11px] uppercase text-slate-400 font-semibold">Minute</label>
                  <select
                    value={customMinute}
                    onChange={(e) => setCustomMinute(Number(e.target.value))}
                    className="mt-1 w-full px-2 py-2 rounded-lg border border-slate-200 text-sm"
                  >
                    {MINUTE_OPTIONS.map((m) => (
                      <option key={m} value={m}>
                        :{String(m).padStart(2, '0')}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 pt-1 border-t border-slate-200">
                <div>
                  <label className="text-[11px] uppercase text-slate-400 font-semibold">Window start</label>
                  <div className="flex gap-1 mt-1">
                    <select
                      value={customStartH}
                      onChange={(e) => setCustomStartH(Number(e.target.value))}
                      className="flex-1 px-2 py-2 rounded-lg border border-slate-200 text-sm"
                    >
                      {HOUR_OPTIONS.map((h) => (
                        <option key={h} value={h}>
                          {h}
                        </option>
                      ))}
                    </select>
                    <select
                      value={customStartM}
                      onChange={(e) => setCustomStartM(Number(e.target.value))}
                      className="w-20 px-2 py-2 rounded-lg border border-slate-200 text-sm"
                    >
                      {MINUTE_OPTIONS.map((m) => (
                        <option key={m} value={m}>
                          {String(m).padStart(2, '0')}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="text-[11px] uppercase text-slate-400 font-semibold">Window end</label>
                  <div className="flex gap-1 mt-1">
                    <select
                      value={customEndH}
                      onChange={(e) => setCustomEndH(Number(e.target.value))}
                      className="flex-1 px-2 py-2 rounded-lg border border-slate-200 text-sm"
                    >
                      {HOUR_OPTIONS.map((h) => (
                        <option key={h} value={h}>
                          {h}
                        </option>
                      ))}
                    </select>
                    <select
                      value={customEndM}
                      onChange={(e) => setCustomEndM(Number(e.target.value))}
                      className="w-20 px-2 py-2 rounded-lg border border-slate-200 text-sm"
                    >
                      {MINUTE_OPTIONS.map((m) => (
                        <option key={m} value={m}>
                          {String(m).padStart(2, '0')}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="grid sm:grid-cols-2 gap-3">
            <div className="rounded-xl bg-slate-50 border border-slate-100 p-3">
              <div className="text-[11px] uppercase tracking-wide text-slate-400 font-semibold">IANA zone</div>
              <div className="text-sm font-mono text-slate-800 mt-1">{selected.timezone}</div>
            </div>
            <div className="rounded-xl bg-slate-50 border border-slate-100 p-3">
              <div className="text-[11px] uppercase tracking-wide text-slate-400 font-semibold">
                Dynamic window
              </div>
              <div className="text-sm font-semibold text-slate-800 mt-1">
                {selected.window_start && selected.window_end
                  ? `${selected.window_start}–${selected.window_end}`
                  : windowMeta || activePreset.label}
              </div>
            </div>
          </div>

          {selected.next_send_at ? (
            <div className="rounded-xl bg-blue-50/80 border border-soft-blue/20 p-4 flex gap-3">
              <CalendarCheck className="h-5 w-5 text-soft-blue shrink-0 mt-0.5" />
              <div>
                <div className="text-sm font-semibold text-slate-800">
                  Next send in {selected.name || usState}:{' '}
                  {selected.local_time || formatHourMinute(selected.local_hour, selected.local_minute || 0)} local
                </div>
                <div className="text-sm text-slate-600 mt-0.5">
                  {formatDateTime(selected.next_send_at)} (UTC instant)
                </div>
                <div className="text-xs text-slate-400 mt-1">
                  {selected.label || `${selected.name} · ${selected.abbr} · ${selected.timezone}`}
                </div>
              </div>
            </div>
          ) : null}

          <div className="rounded-xl border border-amber-100 bg-amber-50/50 px-3 py-2 text-xs text-amber-900 flex gap-2">
            <Zap className="h-3.5 w-3.5 shrink-0 mt-0.5" />
            <span>
              <strong>Instant dispatch</strong> (campaign detail) sends immediately with a fixed{' '}
              {INSTANT_DISPATCH_GAP_MS / 1000}s gap. <strong>Scheduled mode</strong> holds until the computed local
              window time above, then applies the same {INSTANT_DISPATCH_GAP_MS / 1000}s pacing when you release the
              send.
            </span>
          </div>

          <button
            onClick={schedule}
            disabled={saving || !campaigns.length}
            className="w-full py-3 rounded-xl bg-soft-blue text-white text-sm font-semibold shadow-lg shadow-blue-500/25 disabled:opacity-50"
          >
            {saving
              ? 'Scheduling…'
              : `Schedule · ${selected.local_time || activePreset.label} local`}
          </button>
        </div>

        <div className="lg:col-span-2 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <MapPin className="h-4 w-4 text-slate-500" />
            <h3 className="font-semibold text-slate-800">US states</h3>
          </div>
          <div className="relative mb-3">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search state, code, zone…"
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-sm"
            />
          </div>
          <div className="space-y-1.5 max-h-96 overflow-auto">
            {filtered.map((s) => (
              <button
                key={s.code}
                type="button"
                onClick={() => setUsState(s.code)}
                className={`w-full text-left p-2.5 rounded-xl border transition-colors ${
                  usState === s.code
                    ? 'border-soft-blue bg-blue-50/50'
                    : 'border-slate-100 hover:border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="text-sm font-medium text-slate-800">
                    {s.name} <span className="text-slate-400 font-normal">({s.code})</span>
                  </div>
                  <span className="text-[10px] font-bold text-soft-blue">{s.abbr}</span>
                </div>
                <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                  {s.timezone}
                  {s.next_send_at
                    ? ` · ${s.local_time || formatHourMinute(s.local_hour)} → ${formatDateTime(s.next_send_at)}`
                    : ''}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 font-semibold text-slate-800">
          Scheduled campaigns
        </div>
        <div className="divide-y divide-slate-50">
          {campaigns
            .filter((c) => c.status === 'scheduled' || c.schedule_at)
            .map((c) => {
              const st = US_STATE_TIMEZONES.find((s) => s.timezone === c.timezone);
              const hourLabel =
                c.target_send_hour != null
                  ? formatHourMinute(c.target_send_hour, 0)
                  : 'dynamic';
              return (
                <div key={c.id} className="px-5 py-3 flex items-center justify-between gap-3">
                  <div>
                    <div className="font-medium text-slate-800">{c.name}</div>
                    <div className="text-xs text-slate-400">
                      {st ? `${st.name} (${st.code}) · ${st.abbr}` : c.timezone} · ~{hourLabel} local ·{' '}
                      {formatDateTime(c.schedule_at)} · {c.throttle_ms || INSTANT_DISPATCH_GAP_MS}ms pace
                    </div>
                  </div>
                  <StatusBadge status={c.status} />
                </div>
              );
            })}
          {campaigns.filter((c) => c.status === 'scheduled' || c.schedule_at).length === 0 && (
            <div className="px-5 py-10 text-center text-sm text-slate-400">No scheduled campaigns yet</div>
          )}
        </div>
      </div>
    </div>
  );
}
