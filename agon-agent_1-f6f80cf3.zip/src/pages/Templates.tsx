import { useEffect, useState } from 'react';
import { Plus, Trash2, Save } from 'lucide-react';
import { api } from '../lib/api';
import type { Template } from '../lib/types';
import LoadingState, { EmptyState } from '../components/LoadingState';

const empty = { name: '', subject: '', body: '', category: 'general' };

export default function Templates() {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(empty);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const load = async () => {
    try {
      setError('');
      setTemplates(await api.getTemplates());
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const save = async () => {
    if (!form.name || !form.subject || !form.body) {
      setError('All fields are required');
      return;
    }
    setSaving(true);
    setError('');
    try {
      if (editingId) {
        await api.updateTemplate({ id: editingId, ...form });
      } else {
        await api.createTemplate(form);
      }
      setForm(empty);
      setEditingId(null);
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id: number) => {
    if (!confirm('Delete template?')) return;
    await api.deleteTemplate(id);
    await load();
  };

  if (loading) return <LoadingState />;

  return (
    <div className="max-w-6xl space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight text-slate-850">Templates</h1>
        <p className="text-sm text-slate-500 mt-1">Reusable proposals with dynamic field mapping.</p>
      </div>

      {error && (
        <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div>
      )}

      <div className="grid lg:grid-cols-5 gap-5">
        <div className="lg:col-span-2 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm space-y-3">
          <div className="flex items-center gap-2 font-semibold text-slate-800">
            {editingId ? <Save className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
            {editingId ? 'Edit template' : 'New template'}
          </div>
          <input
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="Template name"
            className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm"
          />
          <input
            value={form.category}
            onChange={(e) => setForm({ ...form, category: e.target.value })}
            placeholder="Category"
            className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm"
          />
          <input
            value={form.subject}
            onChange={(e) => setForm({ ...form, subject: e.target.value })}
            placeholder="Subject"
            className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm"
          />
          <textarea
            value={form.body}
            onChange={(e) => setForm({ ...form, body: e.target.value })}
            placeholder="Body with {{first_name}}, {{company}}…"
            rows={10}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm font-mono"
          />
          <div className="flex gap-2">
            <button
              onClick={save}
              disabled={saving}
              className="flex-1 py-2.5 rounded-xl bg-soft-blue text-white text-sm font-semibold disabled:opacity-50"
            >
              {saving ? 'Saving…' : editingId ? 'Update' : 'Create'}
            </button>
            {editingId && (
              <button
                onClick={() => {
                  setEditingId(null);
                  setForm(empty);
                }}
                className="px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600"
              >
                Cancel
              </button>
            )}
          </div>
        </div>

        <div className="lg:col-span-3 space-y-3">
          {templates.length === 0 ? (
            <EmptyState title="No templates" description="Save your best-performing proposals for one-click reuse." />
          ) : (
            templates.map((t) => (
              <div key={t.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="font-semibold text-slate-850">{t.name}</div>
                    <div className="text-xs text-slate-400 uppercase tracking-wide mt-0.5">{t.category}</div>
                    <div className="text-sm text-slate-600 mt-2">{t.subject}</div>
                    <pre className="mt-2 text-xs text-slate-500 whitespace-pre-wrap font-sans line-clamp-4">{t.body}</pre>
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => {
                        setEditingId(t.id);
                        setForm({
                          name: t.name,
                          subject: t.subject,
                          body: t.body,
                          category: t.category,
                        });
                      }}
                      className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => remove(t.id)}
                      className="h-8 w-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-rose-600"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
