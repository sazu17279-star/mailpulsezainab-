import { useState } from 'react';
import { Sparkles, Copy, Check, ArrowRight } from 'lucide-react';
import { api } from '../lib/api';

export default function AIOptimizer() {
  const [text, setText] = useState('');
  const [businessType, setBusinessType] = useState('saas');
  const [goal, setGoal] = useState('proposal');
  const [tone, setTone] = useState('professional');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<Awaited<ReturnType<typeof api.optimize>> | null>(null);
  const [copied, setCopied] = useState('');

  const run = async () => {
    setError('');
    setLoading(true);
    try {
      const res = await api.optimize({
        text,
        business_type: businessType,
        goal,
        tone,
      });
      setResult(res);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Optimization failed');
    } finally {
      setLoading(false);
    }
  };

  const copy = async (value: string, key: string) => {
    await navigator.clipboard.writeText(value);
    setCopied(key);
    setTimeout(() => setCopied(''), 1500);
  };

  return (
    <div className="max-w-6xl space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight text-slate-850 flex items-center gap-2">
          <Sparkles className="h-7 w-7 text-soft-blue" />
          AI Proposal Optimizer
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Transform raw copy into high-converting proposals and subject lines — anti-spam compliant.
        </p>
      </div>

      {error && (
        <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div>
      )}

      <div className="grid lg:grid-cols-2 gap-5">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm space-y-4">
          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="text-[11px] font-semibold uppercase text-slate-400">Business</label>
              <select
                value={businessType}
                onChange={(e) => setBusinessType(e.target.value)}
                className="mt-1 w-full px-2 py-2 rounded-lg border border-slate-200 text-sm"
              >
                {['saas', 'agency', 'consulting', 'ecommerce', 'startup', 'enterprise', 'general'].map((b) => (
                  <option key={b} value={b}>{b}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-[11px] font-semibold uppercase text-slate-400">Goal</label>
              <select
                value={goal}
                onChange={(e) => setGoal(e.target.value)}
                className="mt-1 w-full px-2 py-2 rounded-lg border border-slate-200 text-sm"
              >
                {['proposal', 'followup', 'intro'].map((b) => (
                  <option key={b} value={b}>{b}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-[11px] font-semibold uppercase text-slate-400">Tone</label>
              <select
                value={tone}
                onChange={(e) => setTone(e.target.value)}
                className="mt-1 w-full px-2 py-2 rounded-lg border border-slate-200 text-sm"
              >
                {['professional', 'friendly', 'direct'].map((b) => (
                  <option key={b} value={b}>{b}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold uppercase tracking-wide text-slate-400">Raw draft</label>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={14}
              placeholder="Paste your rough proposal, notes, or email draft here…"
              className="mt-1.5 w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm leading-relaxed focus:outline-none focus:ring-2 focus:ring-soft-blue/30"
            />
          </div>

          <button
            onClick={run}
            disabled={loading || text.trim().length < 10}
            className="w-full py-3 rounded-xl bg-soft-blue text-white text-sm font-semibold shadow-lg shadow-blue-500/25 hover:bg-soft-blue-dim disabled:opacity-50 inline-flex items-center justify-center gap-2"
          >
            <Sparkles className="h-4 w-4" />
            {loading ? 'Optimizing…' : 'Optimize proposal & subjects'}
          </button>
        </div>

        <div className="space-y-4">
          {!result ? (
            <div className="rounded-2xl border border-dashed border-slate-300 bg-white/60 p-10 text-center text-slate-400 text-sm">
              Optimized copy and scored subject lines will appear here.
            </div>
          ) : (
            <>
              <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-slate-800">Optimized body</h3>
                  <button
                    onClick={() => copy(result.optimized_body, 'body')}
                    className="text-xs font-semibold text-soft-blue inline-flex items-center gap-1"
                  >
                    {copied === 'body' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                    Copy
                  </button>
                </div>
                <pre className="text-sm text-slate-700 whitespace-pre-wrap font-sans leading-relaxed bg-slate-50 rounded-xl p-4 border border-slate-100 max-h-72 overflow-auto">
                  {result.optimized_body}
                </pre>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <h3 className="font-semibold text-slate-800 mb-3">Subject line scores</h3>
                <div className="space-y-2">
                  {result.subjects.map((s, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-3 p-3 rounded-xl border border-slate-100 hover:border-soft-blue/30"
                    >
                      <div className="h-10 w-10 rounded-lg bg-soft-blue/10 text-soft-blue flex items-center justify-center font-mono text-sm font-bold shrink-0">
                        {s.score}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-slate-800 truncate">{s.subject}</div>
                        <div className="text-[11px] text-slate-400">{s.reason}</div>
                      </div>
                      <button
                        onClick={() => copy(s.subject, `s${i}`)}
                        className="text-slate-400 hover:text-soft-blue"
                      >
                        {copied === `s${i}` ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <h3 className="font-semibold text-slate-800 mb-2">Analysis</h3>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2 rounded-lg bg-slate-50">Words: {String(result.analysis.original_words)} → {String(result.analysis.optimized_words)}</div>
                  <div className="p-2 rounded-lg bg-slate-50">{String(result.analysis.compliance)}</div>
                  <div className="p-2 rounded-lg bg-slate-50 col-span-2">{String(result.analysis.readability)}</div>
                </div>
                <ul className="mt-3 space-y-1.5">
                  {result.tips.map((tip, i) => (
                    <li key={i} className="text-xs text-slate-600 flex items-start gap-2">
                      <ArrowRight className="h-3 w-3 mt-0.5 text-soft-blue shrink-0" />
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
