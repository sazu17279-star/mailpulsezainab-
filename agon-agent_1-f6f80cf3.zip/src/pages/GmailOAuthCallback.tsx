import { useEffect, useState } from 'react';
import { completeGmailOAuthCallback } from '../lib/gmail';

/**
 * Fallback React route if static callback HTML is not hit.
 * Completes OAuth without embedding Google in an iframe.
 */
export default function GmailOAuthCallback() {
  const [status, setStatus] = useState('Completing Gmail sign-in…');

  useEffect(() => {
    try {
      completeGmailOAuthCallback();
      setStatus('Signed in. This window should close automatically.');
    } catch (e) {
      setStatus(e instanceof Error ? e.message : 'Sign-in failed');
    }
  }, []);

  return (
    <div className="min-h-screen gradient-mesh flex items-center justify-center p-6">
      <div className="max-w-sm w-full rounded-2xl border border-slate-200 bg-white p-8 shadow-lg text-center">
        <div className="mx-auto h-12 w-12 rounded-xl bg-soft-blue flex items-center justify-center text-white font-bold mb-4">
          MP
        </div>
        <h1 className="text-lg font-semibold text-slate-850">MailPulse</h1>
        <p className="mt-2 text-sm text-slate-500">{status}</p>
        <button
          type="button"
          onClick={() => window.close()}
          className="mt-6 px-4 py-2 rounded-xl bg-slate-850 text-white text-sm font-semibold"
        >
          Close window
        </button>
      </div>
    </div>
  );
}
