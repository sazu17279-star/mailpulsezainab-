import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sparkles, Users, FileText, Send, Wand2, Mail } from 'lucide-react';
import { api } from '../lib/api';
import type { Template } from '../lib/types';
import { parseBulkRecipients, loadSettings } from '../lib/storage';
import GmailAccountPicker from '../components/GmailAccountPicker';
import { getActiveGmailEmail } from '../lib/gmail';

export default function Composer() {
  const navigate = useNavigate();
  const settings = loadSettings();
  const [name, setName] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState(
    `Hi {{first_name}},\n\nI wanted to share a short proposal for {{company}}.\n\nWe help teams improve results with a focused, measurable approach.\n\nWould you be open to a 15-minute call this week?\n\nBest regards`
  );
  const [recipientsText, setRecipientsText] = useState('');
  const [templates, setTemplates] = useState<Template[]>([]);
  const [throttle, setThrottle] = useState(10000);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [optimizing, setOptimizing] = useState(false);
  const [trackingOn, setTrackingOn] = useState(settings.trackingEnabled !== false);
  const [senderEmail, setSenderEmail] = useState(getActiveGmailEmail());

  useEffect(() => {
    api.getTemplates().then(setTemplates).catch(() => {});
  }, []);

  const parsed = parseBulkRecipients(recipientsText);

  const applyTemplate = (t: Template) => {
    setSubject(t.subject);
    setBody(t.body);
    if (!name) setName(t.name);
  };

  const optimize = async () => {
    setOptimizing(true);
    setError('');
    try {
      const res = await api.optimize({ text: body, business_type: 'general', goal: 'proposal', tone: 'professional' });
      setBody(res.optimized_body);
      setSubject(res.best_subject);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Optimize failed');
    } finally {
      setOptimizing(false);
    }
  };

  const submit = async (andSend: boolean) => {
    setError('');
    if (!name.trim() || !subject.trim() || !body.trim()) {
      setError('Name, subject, and body are required');
      return;
    }
    if (parsed.length === 0) {
      setError('Add at least one valid recipient email');
      return;
    }
    setSaving(true);
    try {
      const campaign = await api.createCampaign({
        name: name.trim(),
        subject: subject.trim(),
        body: body.trim(),
        status: 'draft',
        throttle_ms: throttle,
        timezone: settings.defaultTimezone,
        target_send_hour: settings.defaultSendHour,
      });
      await api.addRecipients(campaign.id, parsed);
      if (andSend) {
        navigate(`/campaigns/${campaign.id}`, { state: { autoSend: true } });
      } else {
        navigate(`/campaigns/${campaign.id}`);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to create campaign');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-6xl space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight text-slate-850">Compose campaign</h1>
        <p className="text-sm text-slate-500 mt-1">
          Paste recipients, personalize with {'{{tokens}}'}, and launch with invisible open tracking.
        </p>
      </div>

      {error && (
        <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div>
      )}

      <div className="grid lg:grid-cols-5 gap-5">
        <div className="lg:col-span-3 space-y-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm space-y-4">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wide text-slate-400">Campaign name</label>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Q2 outreach — agency leads"
                className="mt-1.5 w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-soft-blue/30"
              />
            </div>
            <div>
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold uppercase tracking-wide text-slate-400">Subject line</label>
                <button
                  type="button"
                  onClick={optimize}
                  disabled={optimizing}
                  className="text-xs font-semibold text-soft-blue inline-flex items-center gap-1"
                >
                  <Wand2 className="h-3.5 w-3.5" /> {optimizing ? 'Optimizing…' : 'AI optimize'}
                </button>
              </div>
              <input
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="{{first_name}}, quick idea for {{company}}"
                className="mt-1.5 w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-soft-blue/30"
              />
            </div>
            <div>
              <label className="text-xs font-semibold uppercase tracking-wide text-slate-400">Body</label>
              <textarea
                value={body}
                onChange={(e) => setBody(e.target.value)}
                rows={14}
                className="mt-1.5 w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm leading-relaxed focus:outline-none focus:ring-2 focus:ring-soft-blue/30 font-mono"
              />
              <div className="mt-2 flex flex-wrap gap-2 text-[11px]">
                {['{{first_name}}', '{{name}}', '{{company}}', '{{email}}'].map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setBody((b) => b + t)}
                    className="px-2 py-1 rounded-md bg-slate-100 text-slate-600 font-mono hover:bg-slate-200"
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex items-center gap-2 mb-2">
              <Users className="h-4 w-4 text-soft-blue" />
              <label className="text-sm font-semibold text-slate-800">Recipients (bulk paste)</label>
            </div>
            <p className="text-xs text-slate-400 mb-2">
              One per line or comma-separated. Supports <span className="font-mono">email</span>,{' '}
              <span className="font-mono">Name &lt;email&gt;</span>,{' '}
              <span className="font-mono">email, name, company</span>.
            </p>
            <textarea
              value={recipientsText}
              onChange={(e) => setRecipientsText(e.target.value)}
              rows={8}
              placeholder={`alex@acme.com, Alex Chen, Acme Inc\njordan@startup.io\nSam Lee <sam@agency.co>`}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-soft-blue/30"
            />
            <div className="mt-2 text-xs text-slate-500">
              <span className="font-semibold text-slate-700">{parsed.length}</span> valid unique emails detected
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm space-y-3">
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-soft-blue" />
              <h3 className="font-semibold text-slate-800">Gmail sender</h3>
            </div>
            <GmailAccountPicker
              compact
              label="Campaign sender"
              value={senderEmail}
              onChange={(email) => setSenderEmail(email)}
            />
            <label className="flex items-center gap-2 text-xs text-slate-600">
              <input
                type="checkbox"
                checked={trackingOn}
                onChange={(e) => setTrackingOn(e.target.checked)}
                className="rounded border-slate-300"
              />
              Watermark-free open & click tracking (default for dispatch)
            </label>
            <p className="text-[11px] text-slate-400">
              Campaigns send through the selected Gmail account with sequential throttling. No promotional footer is ever appended.
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex items-center gap-2 mb-3">
              <FileText className="h-4 w-4 text-slate-500" />
              <h3 className="font-semibold text-slate-800">Templates</h3>
            </div>
            <div className="space-y-2 max-h-64 overflow-auto">
              {templates.map((t) => (
                <button
                  key={t.id}
                  onClick={() => applyTemplate(t)}
                  className="w-full text-left p-3 rounded-xl border border-slate-100 hover:border-soft-blue/40 hover:bg-blue-50/40 transition-colors"
                >
                  <div className="text-sm font-medium text-slate-800">{t.name}</div>
                  <div className="text-xs text-slate-400 truncate">{t.subject}</div>
                  <div className="text-[10px] uppercase tracking-wide text-slate-400 mt-1">{t.category}</div>
                </button>
              ))}
              {templates.length === 0 && <div className="text-sm text-slate-400">No templates yet</div>}
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm space-y-3">
            <h3 className="font-semibold text-slate-800">Safe pacing (instant dispatch)</h3>
            <label className="text-xs text-slate-500">Gap between consecutive emails</label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min={10000}
                step={1000}
                value={throttle}
                onChange={(e) => setThrottle(Math.max(10000, Number(e.target.value) || 10000))}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm font-mono"
              />
              <span className="text-xs text-slate-500 whitespace-nowrap font-semibold">ms (min 10s)</span>
            </div>
            <p className="text-xs text-slate-400">
              Instant dispatch always waits at least <strong>10 seconds</strong> between sends for Gmail deliverability.
              Use the Scheduler for US state smart windows (not fixed 9 AM). Tracking pixels stay watermark-free.
            </p>
          </div>

          <div className="rounded-2xl border border-soft-blue/20 bg-gradient-to-br from-white to-blue-50/50 p-5 shadow-sm space-y-3">
            <div className="flex items-center gap-2 text-soft-blue">
              <Sparkles className="h-4 w-4" />
              <span className="text-sm font-semibold">AI-ready draft</span>
            </div>
            <p className="text-xs text-slate-500">
              Use AI Optimize to rewrite your proposal and generate high-open-rate subjects with anti-spam checks.
            </p>
            <div className="flex flex-col gap-2">
              <button
                onClick={() => submit(false)}
                disabled={saving}
                className="w-full py-2.5 rounded-xl border border-slate-200 bg-white text-sm font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-50"
              >
                Save draft
              </button>
              <button
                onClick={() => submit(true)}
                disabled={saving}
                className="w-full py-2.5 rounded-xl bg-soft-blue text-white text-sm font-semibold shadow-lg shadow-blue-500/25 hover:bg-soft-blue-dim disabled:opacity-50 inline-flex items-center justify-center gap-2"
              >
                <Send className="h-4 w-4" />
                {saving ? 'Creating…' : 'Create & open sender'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
