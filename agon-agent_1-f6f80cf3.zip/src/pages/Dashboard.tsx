import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Send,
  Eye,
  MousePointerClick,
  Users,
  TrendingUp,
  Plus,
  Activity,
} from 'lucide-react';
import { api } from '../lib/api';
import type { DashboardStats } from '../lib/types';
import StatCard from '../components/StatCard';
import StatusBadge from '../components/StatusBadge';
import LoadingState from '../components/LoadingState';
import { formatRelative } from '../lib/storage';

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      setError('');
      const data = await api.getStats();
      setStats(data);
      // Soft notice if API layer is offline but we still have a usable zero/live payload
      if ((data as { offline?: boolean }).offline) {
        setError('');
      }
    } catch (e) {
      // Never hard-block the UI — pristine zero-state always
      setStats({
        totals: {
          campaigns: 0,
          active_campaigns: 0,
          recipients: 0,
          sent: 0,
          opened: 0,
          clicked: 0,
          pending: 0,
          open_rate: 0,
          click_rate: 0,
          unread_notifications: 0,
        },
        chart: [],
        recent_events: [],
        campaigns: [],
      });
      setError('');
      console.warn('[dashboard]', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const id = setInterval(load, 12000);
    return () => clearInterval(id);
  }, []);

  if (loading) return <LoadingState label="Loading dashboard…" />;
  if (!stats) return null;

  const t = stats.totals;
  const maxChart = Math.max(1, ...stats.chart.map((c) => c.opens + c.clicks));

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-semibold tracking-tight text-slate-850">Dashboard</h1>
          <p className="text-slate-500 mt-1 text-sm">
            Live metrics only — everything starts at zero until you send and track real mail.
          </p>
        </div>
        <Link
          to="/composer"
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-soft-blue text-white text-sm font-semibold shadow-lg shadow-blue-500/25 hover:bg-soft-blue-dim transition-colors"
        >
          <Plus className="h-4 w-4" /> New campaign
        </Link>
      </div>

      {error && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900 flex flex-wrap items-center justify-between gap-2">
          <span>{error}</span>
          <button onClick={load} className="underline text-xs font-semibold shrink-0">
            Retry
          </button>
        </div>
      )}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
        <StatCard label="Sent" value={t.sent} sub={`${t.pending} pending`} icon={Send} />
        <StatCard
          label="Open rate"
          value={`${t.open_rate}%`}
          sub={`${t.opened} unique opens`}
          icon={Eye}
          accent="bg-sky-50 text-sky-600"
        />
        <StatCard
          label="Click rate"
          value={`${t.click_rate}%`}
          sub={`${t.clicked} clicked`}
          icon={MousePointerClick}
          accent="bg-emerald-50 text-emerald-600"
        />
        <StatCard
          label="Recipients"
          value={t.recipients}
          sub={`${t.campaigns} campaigns`}
          icon={Users}
          accent="bg-violet-50 text-violet-600"
        />
      </div>

      <div className="grid lg:grid-cols-5 gap-4">
        <div className="lg:col-span-3 rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="font-semibold text-slate-800">Engagement trend</h2>
              <p className="text-xs text-slate-400 mt-0.5">Opens & clicks · last 14 days</p>
            </div>
            <TrendingUp className="h-4 w-4 text-soft-blue" />
          </div>
          {stats.chart.length === 0 ? (
            <div className="h-40 flex flex-col items-center justify-center text-sm text-slate-400 gap-1">
              <span className="font-medium text-slate-500">0 opens · 0 clicks</span>
              <span className="text-xs">Chart fills as real tracking events arrive</span>
            </div>
          ) : (
            <div className="flex items-end gap-1.5 h-44">
              {stats.chart.map((c) => {
                const openH = (c.opens / maxChart) * 100;
                const clickH = (c.clicks / maxChart) * 100;
                return (
                  <div key={c.date} className="flex-1 flex flex-col items-center gap-1 group">
                    <div className="w-full flex items-end justify-center gap-0.5 h-36">
                      <div
                        className="chart-bar w-[40%] max-w-3 rounded-t bg-soft-blue/80 min-h-[2px]"
                        style={{ height: `${Math.max(openH, 2)}%` }}
                        title={`${c.opens} opens`}
                      />
                      <div
                        className="chart-bar w-[40%] max-w-3 rounded-t bg-emerald-400/90 min-h-[2px]"
                        style={{ height: `${Math.max(clickH, c.clicks ? 2 : 0)}%` }}
                        title={`${c.clicks} clicks`}
                      />
                    </div>
                    <div className="text-[9px] text-slate-400 font-mono">{c.date.slice(5)}</div>
                  </div>
                );
              })}
            </div>
          )}
          <div className="flex gap-4 mt-4 text-xs text-slate-500">
            <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-sm bg-soft-blue" /> Opens</span>
            <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-sm bg-emerald-400" /> Clicks</span>
          </div>
        </div>

        <div className="lg:col-span-2 rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-slate-800">Live activity</h2>
            <Activity className="h-4 w-4 text-slate-400" />
          </div>
          <div className="space-y-2 max-h-72 overflow-auto pr-1">
            {stats.recent_events.length === 0 && (
              <div className="text-sm text-slate-400 py-8 text-center space-y-1">
                <div className="font-medium text-slate-500">No activity yet</div>
                <div className="text-xs">Opens and clicks appear here in real time — nothing is pre-seeded.</div>
              </div>
            )}
            {stats.recent_events.map((e) => (
              <div key={e.id} className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-50">
                <span
                  className={`mt-1.5 h-2 w-2 rounded-full shrink-0 ${
                    e.event_type === 'click'
                      ? 'bg-emerald-500'
                      : e.event_type === 'open'
                        ? 'bg-soft-blue'
                        : 'bg-slate-300'
                  }`}
                />
                <div className="min-w-0 flex-1">
                  <div className="text-sm text-slate-700 capitalize">
                    {e.event_type}
                    {e.url ? (
                      <span className="text-slate-400 font-normal"> · link</span>
                    ) : null}
                  </div>
                  <div className="text-[11px] text-slate-400">{formatRelative(e.created_at)}</div>
                </div>
                <StatusBadge status={e.event_type} />
              </div>
            ))}
          </div>
          <Link to="/activity" className="block text-center text-xs font-semibold text-soft-blue mt-3 hover:underline">
            View full timeline
          </Link>
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200/80 bg-white shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <h2 className="font-semibold text-slate-800">Recent campaigns</h2>
          <Link to="/campaigns" className="text-xs font-semibold text-soft-blue">View all</Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-100">
                <th className="px-5 py-3 font-semibold">Campaign</th>
                <th className="px-3 py-3 font-semibold">Status</th>
                <th className="px-3 py-3 font-semibold">Sent</th>
                <th className="px-3 py-3 font-semibold">Opens</th>
                <th className="px-3 py-3 font-semibold">Clicks</th>
              </tr>
            </thead>
            <tbody>
              {stats.campaigns.map((c) => (
                <tr key={c.id} className="border-b border-slate-50 hover:bg-slate-50/80">
                  <td className="px-5 py-3">
                    <Link to={`/campaigns/${c.id}`} className="font-medium text-slate-800 hover:text-soft-blue">
                      {c.name}
                    </Link>
                    <div className="text-xs text-slate-400 truncate max-w-xs">{c.subject}</div>
                  </td>
                  <td className="px-3 py-3"><StatusBadge status={c.status} /></td>
                  <td className="px-3 py-3 font-mono text-slate-600">{c.sent_count || 0}</td>
                  <td className="px-3 py-3 font-mono text-slate-600">{c.open_count || 0}</td>
                  <td className="px-3 py-3 font-mono text-slate-600">{c.click_count || 0}</td>
                </tr>
              ))}
              {stats.campaigns.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-5 py-10 text-center text-slate-400">
                    <div className="font-medium text-slate-500">Clean slate — 0 campaigns</div>
                    <div className="text-xs mt-1">Compose a campaign to start tracking. No sample data is loaded.</div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
