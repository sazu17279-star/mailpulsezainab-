import { Shield, Lock, AppWindow, Chrome, CheckCircle2, ExternalLink, AlertTriangle } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function BrowserHelp() {
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  const isHttps = typeof window !== 'undefined' && window.location.protocol === 'https:';
  const isSecureContext =
    typeof window !== 'undefined' && (window.isSecureContext || window.location.hostname === 'localhost');

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight text-slate-850 flex items-center gap-2">
          <Shield className="h-7 w-7 text-soft-blue" />
          Open MailPulse safely
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Chrome’s “connection is not secure” panel is a browser privacy notice — not a MailPulse bug. Use the steps
          below so Gmail connect, popups, and tracking work cleanly.
        </p>
      </div>

      <div
        className={`rounded-2xl border p-5 ${
          isHttps && isSecureContext
            ? 'border-emerald-200 bg-emerald-50/60'
            : 'border-amber-200 bg-amber-50/70'
        }`}
      >
        <div className="flex items-start gap-3">
          {isHttps && isSecureContext ? (
            <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
          ) : (
            <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
          )}
          <div className="text-sm">
            <div className="font-semibold text-slate-800">This tab right now</div>
            <div className="text-slate-600 mt-1 font-mono text-xs break-all">{origin || '—'}</div>
            <ul className="mt-2 space-y-1 text-slate-600">
              <li>
                Protocol:{' '}
                <strong className={isHttps ? 'text-emerald-700' : 'text-amber-700'}>
                  {isHttps ? 'HTTPS (good)' : 'HTTP — use HTTPS instead'}
                </strong>
              </li>
              <li>
                Secure context:{' '}
                <strong className={isSecureContext ? 'text-emerald-700' : 'text-amber-700'}>
                  {isSecureContext ? 'Yes' : 'No — OAuth / clipboard may be limited'}
                </strong>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2 font-semibold text-slate-800">
          <Lock className="h-4 w-4 text-soft-blue" /> 1. Always open with HTTPS
        </div>
        <ol className="list-decimal pl-5 text-sm text-slate-600 space-y-2">
          <li>
            In the address bar, make sure the URL starts with <code className="bg-slate-100 px-1 rounded">https://</code>
            — never <code className="bg-slate-100 px-1 rounded">http://</code>.
          </li>
          <li>
            If Chrome shows a lock or “Not secure”, click the icon left of the URL → read the message.
          </li>
          <li>
            You can still use the site for testing. For Gmail OAuth, HTTPS + allowed pop-ups is what matters most.
          </li>
        </ol>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2 font-semibold text-slate-800">
          <AppWindow className="h-4 w-4 text-soft-blue" /> 2. Allow pop-ups (required for Connect Gmail)
        </div>
        <p className="text-sm text-slate-600">
          Your screenshot already shows <strong>Pop-ups and redirects → Allowed</strong>. Keep that on for this site.
        </p>
        <ol className="list-decimal pl-5 text-sm text-slate-600 space-y-2">
          <li>Click the tune / info icon left of the URL.</li>
          <li>Turn <strong>Pop-ups and redirects</strong> ON (Allowed).</li>
          <li>Reload the page, then click <strong>Connect Gmail</strong> again.</li>
        </ol>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2 font-semibold text-slate-800">
          <Chrome className="h-4 w-4 text-soft-blue" /> 3. Site settings (full path)
        </div>
        <ol className="list-decimal pl-5 text-sm text-slate-600 space-y-2">
          <li>
            Open{' '}
            <code className="bg-slate-100 px-1 rounded text-xs">chrome://settings/content/all</code>
          </li>
          <li>Search for your MailPulse host (e.g. the arcada.app domain).</li>
          <li>
            Set:
            <ul className="list-disc pl-5 mt-1 space-y-1">
              <li>Pop-ups → Allow</li>
              <li>Cookies → Allow</li>
              <li>JavaScript → Allow (default)</li>
              <li>Notifications → Allow (optional, for open/click alerts)</li>
            </ul>
          </li>
          <li>Close settings and hard-refresh: Ctrl+Shift+R (Windows) / Cmd+Shift+R (Mac).</li>
        </ol>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-3">
        <div className="font-semibold text-slate-800">What that red warning actually means</div>
        <p className="text-sm text-slate-600 leading-relaxed">
          Chrome is warning that the browser does not treat this origin as a fully trusted secure context (often
          temporary preview domains, custom hosts, or HTTP). It is <strong>not</strong> saying MailPulse is phishing.
          Do not enter bank passwords on random sites — but connecting <em>your own</em> Gmail via Google’s official
          popup OAuth is the normal Connect Gmail flow when popups are allowed.
        </p>
        <p className="text-sm text-slate-600">
          MailPulse never loads Google login inside an iframe (that causes “refused to connect”). Auth opens a
          standalone popup or the Chrome extension identity API.
        </p>
      </div>

      <div className="flex flex-wrap gap-3">
        <Link
          to="/settings"
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-soft-blue text-white text-sm font-semibold"
        >
          Go to Settings · Connect Gmail
        </Link>
        <Link
          to="/extension"
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm font-semibold text-slate-700"
        >
          Chrome extension guide
        </Link>
        <a
          href="/help/chrome.html"
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1 px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600"
        >
          Static help page <ExternalLink className="h-3.5 w-3.5" />
        </a>
      </div>
    </div>
  );
}
