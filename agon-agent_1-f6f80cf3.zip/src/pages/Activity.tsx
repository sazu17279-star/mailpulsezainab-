import { useEffect, useState } from 'react';
import { api } from '../lib/api';
import type { TrackingEvent, Campaign, Recipient } from '../lib/types';
import StatusBadge from '../components/StatusBadge';
import LoadingState, { EmptyState } from '../components/LoadingState';
import { formatDateTime } from '../lib/storage';
import { Filter } from 'lucide-react';

export default function Activity() {
  const [events, setEvents] = useState<TrackingEvent[]>([]);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [recipients, setRecipients] = useState<Recipient[]>([]);
  const [filter, setFilter] = useState<'all' | 'open' | 'click' | 'sent'>('all');
  const [campaignId, setCampaignId] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = async () => {
    try {
      setError('');
      const cid = campaignId ? Number(campaignId) : undefined;
      const [e, c, r] = await Promise.all([
        api.getEvents(cid, 200),
        api.getCampaigns(),
        api.getRecipients(cid),
      ]);
      setEvents(e);
      setCampaigns(c);
      setRecipients(r);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const t = setInterval(load, 10000);
    return () => clearInterval(t);
  }, [campaignId]);

  const campaignMap = Object.fromEntries(campaigns.map((c) => [c.id, c]));
  const recipientMap = Object.fromEntries(recipients.map((r) => [r.id, r]));

  const filtered = events.filter((e) => (filter === 'all' ? true : e.event_type === filter));

  if (loading) return <LoadingState label="Loading activity timeline…" />;

  return (
    <div className="max-w-5xl space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight text-slate-850">Activity log</h1>
        <p className="text-sm text-slate-500 mt-1">Exact open timestamps, view counts, and click history.</p>
      </div>

      {error && (
        <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div>
      )}

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Filter className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <select
            value={campaignId}
            onChange={(e) => setCampaignId(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm appearance-none"
          >
            <option value="">All campaigns</option>
            {campaigns.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
        <div className="flex gap-1 p-1 rounded-xl bg-white border border-slate-200">
          {(['all', 'sent', 'open', 'click'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize ${
                filter === f ? 'bg-slate-850 text-white' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <EmptyState title="No events" description="Opens and clicks will appear here in real time." />
      ) : (
        <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
          <div className="relative pl-8">
            <div className="absolute left-5 top-0 bottom-0 w-px bg-slate-200" />
            {filtered.map((e) => {
              const camp = campaignMap[e.campaign_id];
              const rec = recipientMap[e.recipient_id];
              return (
                <div key={e.id} className="relative py-4 pr-5 border-b border-slate-50 last:border-0">
                  <div
                    className={`absolute left-[14px] top-5 h-2.5 w-2.5 rounded-full ring-4 ring-white ${
                      e.event_type === 'click'
                        ? 'bg-emerald-500'
                        : e.event_type === 'open'
                          ? 'bg-soft-blue'
                          : 'bg-slate-300'
                    }`}
                  />
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <StatusBadge status={e.event_type} />
                        <span className="text-sm font-medium text-slate-800">
                          {rec ? `${rec.name} · ${rec.email}` : `Recipient #${e.recipient_id}`}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 mt-1">
                        {camp?.name || `Campaign #${e.campaign_id}`}
                        {e.url ? ` · ${e.url}` : ''}
                      </div>
                    </div>
                    <div className="text-xs font-mono text-slate-400 whitespace-nowrap">
                      {formatDateTime(e.created_at)}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
