import { useEffect, useState } from 'react';
import {
  Puzzle,
  Download,
  CheckCircle2,
  Bell,
  ToggleLeft,
  Mail,
  Shield,
  ExternalLink,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { loadSettings, saveSettings } from '../lib/storage';
import { pingExtension, setExtensionId, syncExtensionConfig } from '../lib/extensionBridge';

const steps = [
  {
    title: 'Download the MV3 package',
    body: 'Grab mailpulse-extension.zip and unzip it on your machine.',
  },
  {
    title: 'Load unpacked in Chrome',
    body: 'Open chrome://extensions → Developer mode → Load unpacked → select the unzipped folder.',
  },
  {
    title: 'Copy the Extension ID',
    body: 'Paste it below and save so the dashboard can sync API URL, accounts, and notification prefs.',
  },
  {
    title: 'Open Gmail compose',
    body: 'You’ll see the MailPulse bar with a one-click tracking toggle. Zero watermark pixels inject on send.',
  },
];

export default function ExtensionPage() {
  const [extensionId, setId] = useState('');
  const [status, setStatus] = useState('');
  const [online, setOnline] = useState(false);

  useEffect(() => {
    const s = loadSettings();
    setId(s.extensionId || '');
  }, []);

  const save = async () => {
    const settings = loadSettings();
    const next = { ...settings, extensionId };
    saveSettings(next);
    setExtensionId(extensionId);
    const ping = await pingExtension(extensionId);
    setOnline(ping.ok);
    const synced = ping.ok ? await syncExtensionConfig(extensionId) : false;
    setStatus(
      ping.ok
        ? `Connected${ping.version ? ` · v${ping.version}` : ''}${synced ? ' · config synced' : ''}`
        : 'Saved locally. If ping failed, reload the extension and ensure externally_connectable matches this origin.'
    );
  };

  return (
    <div className="max-w-4xl space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-semibold tracking-tight text-slate-850 flex items-center gap-2">
            <Puzzle className="h-7 w-7 text-soft-blue" />
            Chrome extension
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Native Gmail compose integration, multi-account sender, and real-time desktop open/click alerts.
            {' '}
            <a href="/help/chrome.html" className="text-soft-blue font-semibold hover:underline">
              Easy Chrome setup guide →
            </a>
          </p>
        </div>
        <a
          href="/mailpulse-extension.zip"
          download
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-soft-blue text-white text-sm font-semibold shadow-lg shadow-blue-500/25"
        >
          <Download className="h-4 w-4" /> Download .zip
        </a>
      </div>

      <div className="grid md:grid-cols-3 gap-3">
        {[
          { icon: ToggleLeft, t: 'Compose toggle', d: 'Enable/disable tracking in one click inside Gmail.' },
          { icon: Shield, t: 'Zero watermark', d: 'Invisible pixel only — no footer, no branding.' },
          { icon: Bell, t: 'Desktop alerts', d: 'Pop-ups the moment a recipient opens or clicks.' },
        ].map((f) => (
          <div key={f.t} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <f.icon className="h-5 w-5 text-soft-blue mb-2" />
            <div className="font-semibold text-slate-800 text-sm">{f.t}</div>
            <div className="text-xs text-slate-500 mt-1">{f.d}</div>
          </div>
        ))}
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="font-semibold text-slate-800 mb-4">Install steps</h2>
        <ol className="space-y-4">
          {steps.map((s, i) => (
            <li key={s.title} className="flex gap-3">
              <div className="h-7 w-7 rounded-lg bg-soft-blue/10 text-soft-blue text-sm font-bold flex items-center justify-center shrink-0">
                {i + 1}
              </div>
              <div>
                <div className="text-sm font-semibold text-slate-800">{s.title}</div>
                <div className="text-sm text-slate-500">{s.body}</div>
              </div>
            </li>
          ))}
        </ol>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-3">
        <h2 className="font-semibold text-slate-800">Link extension to this dashboard</h2>
        <p className="text-xs text-slate-500">
          Dashboard URL for the popup: <span className="font-mono text-slate-700">{window.location.origin}</span>
        </p>
        <input
          value={extensionId}
          onChange={(e) => setId(e.target.value.trim())}
          placeholder="Extension ID"
          className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm font-mono"
        />
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={save}
            className="px-4 py-2 rounded-xl bg-slate-850 text-white text-sm font-semibold"
          >
            Save & ping
          </button>
          {online && (
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-600">
              <CheckCircle2 className="h-3.5 w-3.5" /> Online
            </span>
          )}
          {status && <span className="text-xs text-slate-500">{status}</span>}
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-3">
        <div className="flex items-center gap-2 font-semibold text-slate-800">
          <Mail className="h-4 w-4 text-soft-blue" /> Gmail workflow
        </div>
        <ul className="text-sm text-slate-600 space-y-2 list-disc pl-5">
          <li>
            Connect Gmail under <Link to="/settings" className="text-soft-blue font-semibold">Settings</Link> or the
            extension popup — always a standalone popup / <code className="text-xs bg-slate-100 px-1 rounded">chrome.identity</code>, never an iframe.
          </li>
          <li>Pick the active sender on Compose / Campaign detail before sequential dispatch.</li>
          <li>In Gmail, toggle tracking on the MailPulse bar — Send injects a clean open pixel and wraps links.</li>
          <li>
            Extension service worker polls <code className="text-xs bg-slate-100 px-1 rounded">/api/extension-bridge</code> for
            instant desktop notifications and keeps tokens in <code className="text-xs bg-slate-100 px-1 rounded">chrome.storage.local</code>.
          </li>
        </ul>
        <a
          href="https://mail.google.com"
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1 text-sm font-semibold text-soft-blue"
        >
          Open Gmail <ExternalLink className="h-3.5 w-3.5" />
        </a>
      </div>
    </div>
  );
}
