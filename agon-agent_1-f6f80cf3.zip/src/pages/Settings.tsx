import { useEffect, useState } from 'react';
import { Save, Bell, Mail, Shield, Puzzle, Eye } from 'lucide-react';
import { Link } from 'react-router-dom';
import { AppSettings, DEFAULT_SETTINGS } from '../lib/types';
import { loadSettings, saveSettings } from '../lib/storage';
import GmailAccountPicker from '../components/GmailAccountPicker';
import {
  getActiveGmailAccount,
  loadGmailAccounts,
  removeGmailAccount,
  getActiveGmailEmail,
  MAX_GMAIL_ACCOUNTS,
  gmailAccountSlots,
} from '../lib/gmail';
import { setExtensionId, syncExtensionConfig, pingExtension } from '../lib/extensionBridge';

const TIMEZONES = [
  'UTC',
  'America/New_York',
  'America/Chicago',
  'America/Denver',
  'America/Los_Angeles',
  'Europe/London',
  'Europe/Paris',
  'Europe/Berlin',
  'Asia/Dubai',
  'Asia/Singapore',
  'Asia/Tokyo',
  'Australia/Sydney',
];

export default function Settings() {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [saved, setSaved] = useState(false);
  const [extStatus, setExtStatus] = useState('');
  const [accountsVersion, setAccountsVersion] = useState(0);
  const [resetting, setResetting] = useState(false);
  const [resetMsg, setResetMsg] = useState('');
  const slots = gmailAccountSlots();

  useEffect(() => {
    setSettings(loadSettings());
  }, []);

  const persist = async () => {
    const active = getActiveGmailAccount();
    const next = {
      ...settings,
      gmailConnected: loadGmailAccounts().length > 0,
      senderEmail: active?.email || settings.senderEmail,
      senderName: active?.name || settings.senderName,
    };
    saveSettings(next);
    setSettings(next);
    if (next.extensionId) {
      setExtensionId(next.extensionId);
      const ok = await syncExtensionConfig(next.extensionId);
      setExtStatus(ok ? 'Extension synced with dashboard URL & accounts' : 'Extension ID saved (open extension popup if sync failed)');
    }
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const requestNotifPermission = async () => {
    if (!('Notification' in window)) return;
    const perm = await Notification.requestPermission();
    if (perm === 'granted') {
      setSettings((s) => ({ ...s, desktopNotifications: true }));
      new Notification('MailPulse', {
        body: 'Desktop notifications enabled — you will see opens & clicks instantly.',
        icon: '/favicon.svg',
      });
    }
  };

  const testExt = async () => {
    if (!settings.extensionId) {
      setExtStatus('Paste your extension ID from chrome://extensions');
      return;
    }
    const res = await pingExtension(settings.extensionId);
    setExtStatus(res.ok ? `Extension online${res.version ? ` · v${res.version}` : ''}` : 'Not reachable — check ID & reload extension');
  };

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight text-slate-850">Settings</h1>
        <p className="text-sm text-slate-500 mt-1">
          Multi-account Gmail, Chrome extension bridge, and zero-watermark tracking preferences — stored locally.
        </p>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2 font-semibold text-slate-800">
          <Mail className="h-4 w-4 text-soft-blue" /> Connect Gmail
          <span className="text-xs font-mono font-normal text-slate-400">
            {slots.used}/{MAX_GMAIL_ACCOUNTS}
          </span>
        </div>
        <p className="text-sm text-slate-500">
          Connect up to {MAX_GMAIL_ACCOUNTS} Gmail accounts. Sign-in opens a same-origin window that redirects
          top-level to Google (never an iframe — avoids “refused to connect” / ERR_BLOCKED_BY_RESPONSE). Prefer the
          Chrome extension for the most reliable multi-account chrome.identity flow. Tokens stay per-account in local
          storage.
        </p>
        <div className="rounded-xl bg-slate-50 border border-slate-100 p-3 text-[11px] text-slate-500 font-mono break-all">
          Google Cloud → authorized redirect URI must include:
          <br />
          {typeof window !== 'undefined' ? `${window.location.origin}/oauth/gmail/callback/` : '/oauth/gmail/callback/'}
        </div>
        <GmailAccountPicker
          key={accountsVersion}
          label="Sender accounts"
          onChange={(email, acc) => {
            setSettings((s) => ({
              ...s,
              senderEmail: email || s.senderEmail,
              senderName: acc?.name || s.senderName,
              gmailConnected: true,
            }));
            setAccountsVersion((v) => v + 1);
          }}
        />
        {loadGmailAccounts().length > 0 && (
          <div className="flex flex-wrap gap-2">
            {loadGmailAccounts().map((a) => (
              <button
                key={a.email}
                type="button"
                onClick={() => {
                  removeGmailAccount(a.email);
                  setAccountsVersion((v) => v + 1);
                }}
                className="text-[11px] px-2 py-1 rounded-lg border border-slate-200 text-slate-500 hover:text-rose-600 hover:border-rose-200"
              >
                Remove {a.email}
              </button>
            ))}
          </div>
        )}
        <div className="text-xs text-slate-400">
          Active sender: <span className="font-mono text-slate-600">{getActiveGmailEmail() || 'none'}</span>
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2 font-semibold text-slate-800">
          <Puzzle className="h-4 w-4 text-soft-blue" /> Chrome extension
        </div>
        <p className="text-sm text-slate-500">
          The MV3 extension injects a tracking toggle into Gmail compose and delivers desktop open/click pop-ups.
        </p>
        <div className="flex flex-wrap gap-2">
          <a
            href="/mailpulse-extension.zip"
            download
            className="inline-flex items-center px-4 py-2 rounded-xl bg-slate-850 text-white text-sm font-semibold"
          >
            Download extension (.zip)
          </a>
          <Link
            to="/extension"
            className="inline-flex items-center px-4 py-2 rounded-xl border border-slate-200 text-sm font-semibold text-slate-700"
          >
            Install guide
          </Link>
        </div>
        <div>
          <label className="text-xs font-semibold uppercase text-slate-400">Extension ID</label>
          <input
            value={settings.extensionId}
            onChange={(e) => setSettings({ ...settings, extensionId: e.target.value.trim() })}
            placeholder="from chrome://extensions → MailPulse ID"
            className="mt-1 w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm font-mono"
          />
        </div>
        <div className="flex gap-2">
          <button type="button" onClick={testExt} className="text-sm font-semibold text-soft-blue">
            Test connection
          </button>
          {extStatus && <span className="text-xs text-slate-500">{extStatus}</span>}
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2 font-semibold text-slate-800">
          <Shield className="h-4 w-4 text-soft-blue" /> Sending & privacy
        </div>
        <label className="flex items-center gap-2 text-sm text-slate-600">
          <input
            type="checkbox"
            checked={settings.preferGmailSend}
            onChange={(e) => setSettings({ ...settings, preferGmailSend: e.target.checked })}
            className="rounded border-slate-300"
          />
          Prefer direct Gmail API send for campaigns (throttled, from selected account)
        </label>
        <label className="flex items-center gap-2 text-sm text-slate-600">
          <input
            type="checkbox"
            checked={settings.trackingEnabled}
            onChange={(e) => setSettings({ ...settings, trackingEnabled: e.target.checked })}
            className="rounded border-slate-300"
          />
          <Eye className="h-3.5 w-3.5" /> Default watermark-free open & click tracking ON
        </label>
        <div className="rounded-xl bg-slate-50 border border-slate-100 p-4 text-xs text-slate-500 leading-relaxed">
          Tracking pixels and click redirects never append promotional footers, brand signatures, or MailPulse
          watermarks. Only a 1×1 transparent image and rewritten links are injected when tracking is enabled.
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-semibold uppercase text-slate-400">Display name fallback</label>
            <input
              value={settings.senderName}
              onChange={(e) => setSettings({ ...settings, senderName: e.target.value })}
              className="mt-1 w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm"
            />
          </div>
          <div>
            <label className="text-xs font-semibold uppercase text-slate-400">
              Instant dispatch gap (ms, min 10000)
            </label>
            <input
              type="number"
              min={10000}
              step={1000}
              value={settings.throttleMs}
              onChange={(e) =>
                setSettings({
                  ...settings,
                  throttleMs: Math.max(10000, Number(e.target.value) || 10000),
                })
              }
              className="mt-1 w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm font-mono"
            />
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
        <div className="font-semibold text-slate-800">Scheduler defaults</div>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-semibold uppercase text-slate-400">Default timezone</label>
            <select
              value={settings.defaultTimezone}
              onChange={(e) => setSettings({ ...settings, defaultTimezone: e.target.value })}
              className="mt-1 w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm"
            >
              {TIMEZONES.map((tz) => (
                <option key={tz} value={tz}>{tz}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs font-semibold uppercase text-slate-400">Default custom send hour</label>
            <select
              value={settings.defaultSendHour}
              onChange={(e) => setSettings({ ...settings, defaultSendHour: Number(e.target.value) })}
              className="mt-1 w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm"
            >
              {[7, 8, 9, 10, 11, 12, 13, 14, 15, 16].map((h) => (
                <option key={h} value={h}>
                  {String(h).padStart(2, '0')}:00 local (custom window)
                </option>
              ))}
            </select>
            <p className="text-[11px] text-slate-400 mt-1">
              Used when the scheduler is set to Custom. Smart/morning/afternoon presets pick times dynamically.
            </p>
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-3">
        <div className="flex items-center gap-2 font-semibold text-slate-800">
          <Bell className="h-4 w-4 text-soft-blue" /> Real-time notifications
        </div>
        <label className="flex items-center gap-2 text-sm text-slate-600">
          <input
            type="checkbox"
            checked={settings.desktopNotifications}
            onChange={(e) => setSettings({ ...settings, desktopNotifications: e.target.checked })}
            className="rounded border-slate-300"
          />
          In-app toasts + browser desktop pop-ups on open/click
        </label>
        <button type="button" onClick={requestNotifPermission} className="text-sm font-semibold text-soft-blue">
          Enable browser desktop pop-ups
        </button>
      </div>

      <button
        onClick={persist}
        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-soft-blue text-white text-sm font-semibold shadow-lg shadow-blue-500/25"
      >
        <Save className="h-4 w-4" />
        {saved ? 'Saved to local storage' : 'Save settings'}
      </button>

      <div className="rounded-2xl border border-rose-100 bg-rose-50/40 p-6 space-y-3">
        <div className="font-semibold text-slate-800">Pure clean state</div>
        <p className="text-sm text-slate-500">
          Dashboard metrics start at zero with no sample campaigns or fake events. Use this only if you want to wipe
          all server-side campaigns, recipients, tracking events, notifications, and templates.
        </p>
        <button
          type="button"
          disabled={resetting}
          onClick={async () => {
            if (!confirm('Delete ALL campaigns, events, and templates? This cannot be undone.')) return;
            setResetting(true);
            setResetMsg('');
            try {
              const res = await fetch('/api/reset-data', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ confirm: 'RESET_ALL_DATA' }),
              });
              const data = await res.json();
              if (!res.ok) throw new Error(data.error || 'Reset failed');
              setResetMsg(data.message || 'Reset complete — zero state.');
            } catch (e) {
              setResetMsg(e instanceof Error ? e.message : 'Reset failed');
            } finally {
              setResetting(false);
            }
          }}
          className="px-4 py-2 rounded-xl border border-rose-200 bg-white text-sm font-semibold text-rose-700 hover:bg-rose-50 disabled:opacity-50"
        >
          {resetting ? 'Resetting…' : 'Wipe all tracking data'}
        </button>
        {resetMsg && <p className="text-xs text-slate-600">{resetMsg}</p>}
      </div>
    </div>
  );
}
