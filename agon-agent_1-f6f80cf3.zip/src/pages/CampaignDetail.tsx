import { useEffect, useRef, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  Play,
  Pause,
  Clock,
  Copy,
  ExternalLink,
  Eye,
  MousePointerClick,
  Mail,
  Zap,
} from 'lucide-react';
import { api } from '../lib/api';
import type { Campaign, Recipient, TrackingEvent } from '../lib/types';
import StatusBadge from '../components/StatusBadge';
import LoadingState from '../components/LoadingState';
import GmailAccountPicker from '../components/GmailAccountPicker';
import { formatDateTime, formatRelative, loadSettings } from '../lib/storage';
import { getValidAccessToken, getActiveGmailAccount } from '../lib/gmail';
import { INSTANT_DISPATCH_GAP_MS } from '../lib/usTimezones';

/** Precise wait — uses setTimeout chain for exact gap between sends */
function waitMs(ms: number, isActive: () => boolean): Promise<void> {
  return new Promise((resolve) => {
    const start = Date.now();
    const tick = () => {
      if (!isActive()) {
        resolve();
        return;
      }
      const elapsed = Date.now() - start;
      if (elapsed >= ms) {
        resolve();
        return;
      }
      setTimeout(tick, Math.min(250, ms - elapsed));
    };
    setTimeout(tick, Math.min(250, ms));
  });
}

export default function CampaignDetail() {
  const { id } = useParams();
  const campaignId = Number(id);
  const [campaign, setCampaign] = useState<Campaign | null>(null);
  const [recipients, setRecipients] = useState<Recipient[]>([]);
  const [events, setEvents] = useState<TrackingEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [useGmail, setUseGmail] = useState(loadSettings().preferGmailSend !== false);
  const [trackingOn, setTrackingOn] = useState(loadSettings().trackingEnabled !== false);
  const sendLoop = useRef(false);

  const load = async () => {
    try {
      setError('');
      const [c, r, e] = await Promise.all([
        api.getCampaign(campaignId),
        api.getRecipients(campaignId),
        api.getEvents(campaignId, 50),
      ]);
      setCampaign(c);
      setRecipients(r);
      setEvents(e);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!campaignId) return;
    load();
    const t = setInterval(load, 10000);
    return () => clearInterval(t);
  }, [campaignId]);

  const startSending = async () => {
    if (!campaign) return;
    setSending(true);
    setError('');
    sendLoop.current = true;

    // Persist 10s throttle on campaign for this instant run
    try {
      await api.updateCampaign({ id: campaign.id, throttle_ms: INSTANT_DISPATCH_GAP_MS });
    } catch {
      /* non-fatal */
    }

    const gapMs = INSTANT_DISPATCH_GAP_MS;
    const isActive = () => sendLoop.current;

    try {
      if (useGmail) {
        setMessage(
          `Instant dispatch via Gmail · strict ${gapMs / 1000}s gap between emails…`
        );
        let remaining = Infinity;
        let sentTotal = 0;
        while (sendLoop.current && remaining > 0) {
          const { account, token } = await getValidAccessToken();
          const result = await api.gmailSendBatch({
            access_token: token,
            campaign_id: campaign.id,
            batch_size: 1,
            tracking_enabled: trackingOn,
            from_name: account.name,
            from_email: account.email,
          });
          remaining = result.remaining;
          sentTotal += result.sent || 0;
          const failNote = result.failed ? ` · ${result.failed} failed` : '';
          setMessage(
            `Instant · ${account.email}: +${result.sent}${failNote} · total ${sentTotal} · ${result.remaining} left · next in ${gapMs / 1000}s`
          );
          await load();
          if (result.remaining > 0 && sendLoop.current) {
            await waitMs(gapMs, isActive);
          }
        }
        if (sendLoop.current) {
          setMessage(`Instant Gmail dispatch complete · ${sentTotal} sent · ${gapMs / 1000}s pacing`);
        }
      } else {
        setMessage(`Instant dispatch · strict ${gapMs / 1000}s gap between emails…`);
        let remaining = Infinity;
        let sentTotal = 0;
        while (sendLoop.current && remaining > 0) {
          const result = await api.sendBatch(campaign.id, 1);
          remaining = result.remaining;
          sentTotal += result.sent || 0;
          setMessage(
            `Instant: +${result.sent} · total ${sentTotal} · ${result.remaining} left · pacing ${gapMs / 1000}s`
          );
          await load();
          if (result.remaining > 0 && sendLoop.current) {
            await waitMs(gapMs, isActive);
          }
        }
        if (sendLoop.current) {
          setMessage(`Instant dispatch complete · ${sentTotal} sent · ${gapMs / 1000}s pacing`);
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Send failed');
    } finally {
      setSending(false);
      sendLoop.current = false;
    }
  };

  const pause = async () => {
    sendLoop.current = false;
    await api.pauseCampaign(campaignId);
    setMessage('Paused');
    setSending(false);
    load();
  };

  const simulateOpen = async (r: Recipient) => {
    await fetch(`/api/track-open?t=${r.tracking_token}`);
    setMessage(`Simulated open for ${r.email}`);
    load();
  };

  const copyPixel = (r: Recipient) => {
    const url = `${window.location.origin}/api/track-open?t=${r.tracking_token}`;
    navigator.clipboard.writeText(
      `<img src="${url}" width="1" height="1" alt="" style="display:none!important;width:1px!important;height:1px!important;border:0!important;" />`
    );
    setMessage('Invisible pixel HTML copied (zero watermark)');
  };

  if (loading) return <LoadingState />;
  if (!campaign) {
    return (
      <div className="text-slate-500">
        Campaign not found. <Link to="/campaigns" className="text-soft-blue">Back</Link>
      </div>
    );
  }

  const active = getActiveGmailAccount();

  return (
    <div className="max-w-6xl space-y-6">
      <div className="flex items-start gap-3">
        <Link
          to="/campaigns"
          className="mt-1 h-9 w-9 rounded-lg border border-slate-200 bg-white flex items-center justify-center text-slate-500 hover:text-slate-800"
        >
          <ArrowLeft className="h-4 w-4" />
        </Link>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-2xl font-semibold text-slate-850">{campaign.name}</h1>
            <StatusBadge status={campaign.status} />
          </div>
          <p className="text-sm text-slate-500 mt-1">{campaign.subject}</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          {!sending ? (
            <button
              onClick={startSending}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-soft-blue text-white text-sm font-semibold shadow-lg shadow-blue-500/20"
            >
              <Zap className="h-4 w-4" /> Instant dispatch
            </button>
          ) : (
            <button
              onClick={pause}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-500 text-white text-sm font-semibold"
            >
              <Pause className="h-4 w-4" /> Pause
            </button>
          )}
          <Link
            to="/scheduler"
            state={{ campaignId: campaign.id }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-200 bg-white text-sm font-semibold text-slate-700"
          >
            <Clock className="h-4 w-4" /> Schedule 9 AM
          </Link>
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm space-y-3">
        <div className="flex flex-col lg:flex-row lg:items-center gap-4">
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-800 shrink-0">
            <Mail className="h-4 w-4 text-soft-blue" /> Sender identity
          </div>
          <GmailAccountPicker compact />
          <div className="flex flex-wrap items-center gap-4 lg:ml-auto text-sm">
            <label className="inline-flex items-center gap-2 text-slate-600">
              <input
                type="checkbox"
                checked={useGmail}
                onChange={(e) => setUseGmail(e.target.checked)}
                className="rounded border-slate-300"
              />
              Direct Gmail API
            </label>
            <label className="inline-flex items-center gap-2 text-slate-600">
              <input
                type="checkbox"
                checked={trackingOn}
                onChange={(e) => setTrackingOn(e.target.checked)}
                className="rounded border-slate-300"
              />
              Watermark-free tracking
            </label>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 border-t border-slate-100 pt-3">
          <span className="inline-flex items-center gap-1.5 font-semibold text-slate-700">
            <Zap className="h-3.5 w-3.5 text-soft-blue" /> Instant mode
          </span>
          <span>
            Sends immediately one-by-one with a <strong className="text-slate-800">fixed {INSTANT_DISPATCH_GAP_MS / 1000}-second</strong> gap
            (deliverability-safe pacing).
          </span>
          <span className="text-slate-400">|</span>
          <span className="inline-flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5" /> Or schedule in a US state engagement window (smart peak / flexible hours)
          </span>
        </div>
      </div>
      {useGmail && !active && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
          Connect a Gmail account above (or in Settings) before sending via Gmail.
        </div>
      )}

      {message && (
        <div className="rounded-xl border border-sky-200 bg-sky-50 px-4 py-3 text-sm text-sky-800">{message}</div>
      )}
      {error && (
        <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { l: 'Recipients', v: recipients.length },
          { l: 'Sent', v: campaign.sent_count || 0 },
          { l: 'Opens', v: campaign.open_count || 0 },
          { l: 'Clicks', v: campaign.click_count || 0 },
        ].map((s) => (
          <div key={s.l} className="rounded-2xl border border-slate-200 bg-white p-4">
            <div className="text-[11px] uppercase tracking-wide text-slate-400 font-semibold">{s.l}</div>
            <div className="text-2xl font-semibold mt-1 font-mono text-slate-850">{s.v}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-5 gap-4">
        <div className="lg:col-span-3 rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100 font-semibold text-slate-800">Recipients</div>
          <div className="overflow-x-auto max-h-[420px]">
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-white">
                <tr className="text-left text-[11px] uppercase text-slate-400 border-b border-slate-100">
                  <th className="px-4 py-2 font-semibold">Contact</th>
                  <th className="px-3 py-2 font-semibold">Status</th>
                  <th className="px-3 py-2 font-semibold">Opens</th>
                  <th className="px-3 py-2 font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {recipients.map((r) => (
                  <tr key={r.id} className="border-b border-slate-50">
                    <td className="px-4 py-2.5">
                      <div className="font-medium text-slate-800">{r.name}</div>
                      <div className="text-xs text-slate-400">{r.email}</div>
                    </td>
                    <td className="px-3 py-2.5">
                      <StatusBadge status={r.status} />
                    </td>
                    <td className="px-3 py-2.5 font-mono text-slate-600">
                      {r.open_count}
                      {r.last_opened_at && (
                        <div className="text-[10px] text-slate-400">{formatRelative(r.last_opened_at)}</div>
                      )}
                    </td>
                    <td className="px-3 py-2.5">
                      <div className="flex gap-1">
                        <button
                          title="Simulate open"
                          onClick={() => simulateOpen(r)}
                          className="h-8 w-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-500 hover:text-soft-blue"
                        >
                          <Eye className="h-3.5 w-3.5" />
                        </button>
                        <button
                          title="Copy pixel"
                          onClick={() => copyPixel(r)}
                          className="h-8 w-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-500 hover:text-soft-blue"
                        >
                          <Copy className="h-3.5 w-3.5" />
                        </button>
                        <a
                          title="Test click redirect"
                          href={`/api/track-click?t=${r.tracking_token}&u=${encodeURIComponent('https://example.com')}`}
                          target="_blank"
                          rel="noreferrer"
                          className="h-8 w-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-500 hover:text-emerald-600"
                        >
                          <MousePointerClick className="h-3.5 w-3.5" />
                        </a>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <h3 className="font-semibold text-slate-800 mb-3">Email body</h3>
            <pre className="text-xs text-slate-600 whitespace-pre-wrap font-sans leading-relaxed max-h-48 overflow-auto bg-slate-50 rounded-xl p-3 border border-slate-100">
              {campaign.body}
            </pre>
            <div className="mt-3 text-[11px] text-slate-400">
              Pacing: {INSTANT_DISPATCH_GAP_MS / 1000}s gap · TZ: {campaign.timezone}
              {campaign.schedule_at ? ` · ${formatDateTime(campaign.schedule_at)}` : ''}
              {active ? ` · From ${active.email}` : ''}
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <h3 className="font-semibold text-slate-800 mb-3">Activity log</h3>
            <div className="space-y-2 max-h-64 overflow-auto">
              {events.map((e) => (
                <div key={e.id} className="flex gap-2 text-sm">
                  <StatusBadge status={e.event_type} />
                  <div className="min-w-0">
                    <div className="text-slate-600 truncate">
                      {e.event_type}
                      {e.url ? (
                        <a
                          href={e.url}
                          className="ml-1 text-soft-blue inline-flex items-center gap-0.5"
                          target="_blank"
                          rel="noreferrer"
                        >
                          link <ExternalLink className="h-3 w-3" />
                        </a>
                      ) : null}
                    </div>
                    <div className="text-[11px] text-slate-400">{formatDateTime(e.created_at)}</div>
                  </div>
                </div>
              ))}
              {events.length === 0 && <div className="text-sm text-slate-400">No events yet</div>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
