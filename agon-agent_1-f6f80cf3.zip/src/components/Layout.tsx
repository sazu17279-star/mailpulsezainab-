import { NavLink, Outlet } from 'react-router-dom';
import {
  LayoutDashboard,
  Send,
  FileText,
  Activity,
  Sparkles,
  Clock,
  Settings,
  Mail,
  Bell,
  Zap,
  Puzzle,
  Shield,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { api } from '../lib/api';
import type { Notification } from '../lib/types';
import { formatRelative, loadSeenNotificationIds, saveSeenNotificationIds, loadSettings } from '../lib/storage';
import { motion, AnimatePresence } from 'framer-motion';

const nav = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/campaigns', label: 'Campaigns', icon: Send },
  { to: '/composer', label: 'Compose', icon: Mail },
  { to: '/templates', label: 'Templates', icon: FileText },
  { to: '/activity', label: 'Activity', icon: Activity },
  { to: '/ai', label: 'AI Optimizer', icon: Sparkles },
  { to: '/scheduler', label: 'Scheduler', icon: Clock },
  { to: '/extension', label: 'Extension', icon: Puzzle },
  { to: '/help', label: 'Browser help', icon: Shield },
  { to: '/settings', label: 'Settings', icon: Settings },
];

export default function Layout() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showNotifs, setShowNotifs] = useState(false);
  const [toast, setToast] = useState<Notification | null>(null);

  const fetchNotifs = async () => {
    try {
      // Prefer enriched bridge payload (recipient + campaign) for desktop pop-ups
      let data: Notification[] = [];
      try {
        const bridge = await api.extensionBridge();
        data = bridge.notifications as Notification[];
      } catch {
        data = await api.getNotifications();
      }
      setNotifications(data);

      const settings = loadSettings();
      if (settings.desktopNotifications) {
        const seen = new Set(loadSeenNotificationIds());
        const fresh = data.filter((n) => !n.read && !seen.has(n.id));
        if (fresh.length > 0) {
          const latest = fresh[0] as Notification & {
            desktop_title?: string;
            desktop_body?: string;
            recipient_email?: string;
            campaign_name?: string;
          };
          setToast(latest);
          const ids = [...seen, ...fresh.map((n) => n.id)];
          saveSeenNotificationIds(ids);
          if ('Notification' in window && Notification.permission === 'granted') {
            const title = latest.desktop_title
              ? `MailPulse · ${latest.desktop_title}`
              : 'MailPulse';
            const body =
              latest.desktop_body ||
              [
                latest.recipient_email,
                latest.campaign_name,
                latest.message,
              ]
                .filter(Boolean)
                .join(' · ') ||
              latest.message;
            new Notification(title, {
              body,
              icon: '/favicon.svg',
              tag: `mp-${latest.id}`,
            });
          }
          setTimeout(() => setToast(null), 4500);
        }
      }
    } catch {
      /* silent */
    }
  };

  useEffect(() => {
    fetchNotifs();
    const id = setInterval(fetchNotifs, 8000);
    return () => clearInterval(id);
  }, []);

  const unread = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-full gradient-mesh flex">
      <aside className="hidden md:flex w-60 shrink-0 flex-col border-r border-slate-200/80 bg-slate-850 text-slate-100">
        <div className="px-5 py-6 flex items-center gap-3">
          <div className="h-9 w-9 rounded-xl bg-soft-blue flex items-center justify-center shadow-lg shadow-blue-500/30">
            <Zap className="h-5 w-5 text-white" strokeWidth={2.5} />
          </div>
          <div>
            <div className="font-semibold tracking-tight text-white">MailPulse</div>
            <div className="text-[11px] text-slate-400 font-medium">Tracking · Campaigns · AI</div>
          </div>
        </div>

        <nav className="flex-1 px-3 space-y-0.5">
          {nav.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-white/10 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-white/5'
                }`
              }
            >
              <item.icon className="h-4 w-4 shrink-0" />
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="p-4 m-3 rounded-xl bg-white/5 border border-white/10">
          <div className="text-[11px] uppercase tracking-wider text-slate-500 mb-1">Edition</div>
          <div className="text-sm font-medium text-slate-200">Advanced · Free Forever</div>
          <div className="text-xs text-slate-500 mt-1">Zero watermark · Unlimited tracking</div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-30 glass-panel px-4 md:px-8 py-3 flex items-center justify-between">
          <div className="md:hidden flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-soft-blue flex items-center justify-center">
              <Zap className="h-4 w-4 text-white" />
            </div>
            <span className="font-semibold text-slate-800">MailPulse</span>
          </div>
          <div className="hidden md:block text-sm text-slate-500">
            No sign-up · Local config · Invisible tracking
          </div>

          <div className="relative">
            <button
              onClick={() => setShowNotifs((v) => !v)}
              className="relative h-10 w-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-slate-600 hover:border-soft-blue/40 hover:text-soft-blue transition-colors"
            >
              <Bell className="h-4 w-4" />
              {unread > 0 && (
                <span className="absolute -top-1 -right-1 h-5 min-w-5 px-1 rounded-full bg-soft-blue text-white text-[10px] font-semibold flex items-center justify-center">
                  {unread > 9 ? '9+' : unread}
                </span>
              )}
            </button>

            <AnimatePresence>
              {showNotifs && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 8 }}
                  className="absolute right-0 mt-2 w-80 max-h-96 overflow-auto rounded-2xl bg-white border border-slate-200 shadow-xl shadow-slate-300/40"
                >
                  <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
                    <span className="text-sm font-semibold text-slate-800">Live alerts</span>
                    <button
                      className="text-xs text-soft-blue font-medium"
                      onClick={async () => {
                        await api.markAllNotificationsRead();
                        fetchNotifs();
                      }}
                    >
                      Mark all read
                    </button>
                  </div>
                  {notifications.length === 0 ? (
                    <div className="p-6 text-sm text-slate-400 text-center">No activity yet</div>
                  ) : (
                    notifications.slice(0, 15).map((n) => (
                      <button
                        key={n.id}
                        onClick={async () => {
                          if (!n.read) await api.markNotificationRead(n.id);
                          fetchNotifs();
                        }}
                        className={`w-full text-left px-4 py-3 border-b border-slate-50 hover:bg-slate-50 transition-colors ${
                          !n.read ? 'bg-blue-50/50' : ''
                        }`}
                      >
                        <div className="text-sm text-slate-700">{n.message}</div>
                        <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1.5">
                          <span className={`h-1.5 w-1.5 rounded-full ${n.type === 'click' ? 'bg-emerald-500' : 'bg-soft-blue'}`} />
                          {formatRelative(n.created_at)}
                        </div>
                      </button>
                    ))
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </header>

        {/* Mobile nav */}
        <div className="md:hidden flex gap-1 overflow-x-auto px-3 py-2 border-b border-slate-200/60 bg-white/70">
          {nav.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) =>
                `flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap ${
                  isActive ? 'bg-slate-850 text-white' : 'bg-white text-slate-600 border border-slate-200'
                }`
              }
            >
              <item.icon className="h-3.5 w-3.5" />
              {item.label}
            </NavLink>
          ))}
        </div>

        <main className="flex-1 p-4 md:p-8 overflow-auto">
          <Outlet />
        </main>
      </div>

      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 40, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: 20, x: '-50%' }}
            className="fixed bottom-6 left-1/2 z-50 flex items-start gap-3 px-4 py-3 rounded-2xl bg-slate-850 text-white shadow-2xl shadow-slate-900/30 max-w-sm"
          >
            <div className={`mt-0.5 h-2 w-2 rounded-full pulse-dot ${toast.type === 'click' ? 'bg-emerald-400' : 'bg-soft-blue'}`} />
            <div>
              <div className="text-xs font-semibold text-slate-300 uppercase tracking-wide">Live open</div>
              <div className="text-sm">{toast.message}</div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
