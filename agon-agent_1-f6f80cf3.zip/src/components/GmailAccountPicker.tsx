import { useEffect, useRef, useState } from 'react';
import { ChevronDown, Link2, Plus, RefreshCw, Check, Users, KeyRound } from 'lucide-react';
import type { GmailAccount } from '../lib/types';
import {
  connectGmailAccount,
  connectWithAccessToken,
  getActiveGmailEmail,
  loadGmailAccounts,
  setActiveGmailEmail,
  isGmailTokenValid,
  MAX_GMAIL_ACCOUNTS,
  gmailAccountSlots,
  canAddGmailAccount,
} from '../lib/gmail';

interface Props {
  value?: string | null;
  onChange?: (email: string | null, account: GmailAccount | null) => void;
  compact?: boolean;
  label?: string;
}

export default function GmailAccountPicker({ value, onChange, compact, label }: Props) {
  const [accounts, setAccounts] = useState<GmailAccount[]>([]);
  const [active, setActive] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [showPaste, setShowPaste] = useState(false);
  const [pasteToken, setPasteToken] = useState('');
  const rootRef = useRef<HTMLDivElement>(null);

  const refresh = () => {
    const list = loadGmailAccounts();
    setAccounts(list);
    const a = value ?? getActiveGmailEmail() ?? list[0]?.email ?? null;
    setActive(a);
  };

  useEffect(() => {
    refresh();
  }, [value]);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (!rootRef.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, [open]);

  const select = (email: string) => {
    setActiveGmailEmail(email);
    setActive(email);
    setOpen(false);
    const acc = loadGmailAccounts().find((a) => a.email === email) || null;
    onChange?.(email, acc);
  };

  const connect = async () => {
    setBusy(true);
    setError('');
    try {
      const acc = await connectGmailAccount({ forceConsent: true });
      refresh();
      select(acc.email);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Connect failed');
      setShowPaste(true);
    } finally {
      setBusy(false);
    }
  };

  const pasteConnect = async () => {
    setBusy(true);
    setError('');
    try {
      const acc = await connectWithAccessToken(pasteToken);
      setPasteToken('');
      setShowPaste(false);
      refresh();
      select(acc.email);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Invalid token');
    } finally {
      setBusy(false);
    }
  };

  const current = accounts.find((a) => a.email === active) || null;
  const slots = gmailAccountSlots();

  const pastePanel = showPaste && (
    <div className="mt-2 p-3 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
      <div className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
        <KeyRound className="h-3.5 w-3.5 text-soft-blue" />
        Paste Gmail access token
      </div>
      <p className="text-[11px] text-slate-500 leading-relaxed">
        Google Error 400 means this web domain is not registered on the OAuth client. Fastest fix:{' '}
        <strong>Chrome extension → Add account</strong>. Or create a token at{' '}
        <a
          className="text-soft-blue underline"
          href="https://developers.google.com/oauthplayground/"
          target="_blank"
          rel="noreferrer"
        >
          OAuth Playground
        </a>{' '}
        with scope <code className="bg-white px-1 rounded">gmail.send</code>, then paste it here.
      </p>
      <textarea
        value={pasteToken}
        onChange={(e) => setPasteToken(e.target.value)}
        rows={3}
        placeholder="ya29...."
        className="w-full px-2 py-1.5 rounded-lg border border-slate-200 text-xs font-mono"
      />
      <button
        type="button"
        onClick={pasteConnect}
        disabled={busy || pasteToken.trim().length < 20}
        className="w-full py-2 rounded-lg bg-slate-850 text-white text-xs font-semibold disabled:opacity-50"
      >
        {busy ? 'Validating…' : 'Save token & connect'}
      </button>
    </div>
  );

  const dropdown = (
    <div className="absolute z-50 mt-1 w-80 max-h-96 overflow-auto rounded-xl border border-slate-200 bg-white shadow-xl py-1 left-0">
      <div className="px-3 py-2 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white">
        <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">
          Gmail accounts
        </span>
        <span className="text-[11px] font-mono text-slate-500">
          {slots.used}/{slots.max}
        </span>
      </div>
      {accounts.length === 0 && (
        <div className="px-3 py-4 text-xs text-slate-400 text-center">No accounts connected yet</div>
      )}
      {accounts.map((a) => (
        <button
          key={a.email}
          type="button"
          onClick={() => select(a.email)}
          className="w-full flex items-center gap-2 px-3 py-2.5 text-left text-sm hover:bg-slate-50"
        >
          {a.picture ? (
            <img src={a.picture} alt="" className="h-7 w-7 rounded-full shrink-0" />
          ) : (
            <span className="h-7 w-7 rounded-full bg-slate-850 text-white text-[11px] flex items-center justify-center font-bold shrink-0">
              {a.email[0].toUpperCase()}
            </span>
          )}
          <span className="flex-1 min-w-0">
            <span className="block truncate font-medium text-slate-800">{a.name}</span>
            <span className="block truncate text-xs text-slate-400">{a.email}</span>
          </span>
          {a.email === active && <Check className="h-3.5 w-3.5 text-soft-blue shrink-0" />}
          {!isGmailTokenValid(a) && (
            <span className="text-[10px] text-amber-600 font-semibold shrink-0">re-auth</span>
          )}
        </button>
      ))}
      <button
        type="button"
        onClick={connect}
        disabled={busy}
        className="w-full flex items-center gap-2 px-3 py-2.5 text-sm font-semibold text-soft-blue border-t border-slate-100 disabled:opacity-50"
      >
        <Plus className="h-3.5 w-3.5" />
        {busy ? 'Connecting…' : canAddGmailAccount() ? `Add Gmail (${slots.remaining} left)` : 'Re-auth account'}
      </button>
      <button
        type="button"
        onClick={() => setShowPaste((v) => !v)}
        className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-slate-500 border-t border-slate-100"
      >
        <KeyRound className="h-3.5 w-3.5" /> Paste access token instead
      </button>
    </div>
  );

  if (compact) {
    return (
      <div className="space-y-1" ref={rootRef}>
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative">
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              className="inline-flex items-center gap-2 px-3 py-2 rounded-xl border border-slate-200 bg-white text-sm font-medium text-slate-700 hover:border-soft-blue/40 min-w-[200px]"
            >
              {current?.picture ? (
                <img src={current.picture} alt="" className="h-5 w-5 rounded-full" />
              ) : (
                <span className="h-5 w-5 rounded-full bg-soft-blue/15 text-soft-blue text-[10px] flex items-center justify-center font-bold">
                  {(current?.email || '?')[0].toUpperCase()}
                </span>
              )}
              <span className="flex-1 text-left max-w-[180px] truncate">
                {current?.email || 'Select Gmail sender'}
              </span>
              <span className="text-[10px] font-mono text-slate-400">
                {slots.used}/{slots.max}
              </span>
              <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
            </button>
            {open && dropdown}
          </div>
          {!current && (
            <button
              type="button"
              onClick={connect}
              disabled={busy}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-soft-blue text-white text-xs font-semibold"
            >
              <Link2 className="h-3.5 w-3.5" /> {busy ? '…' : 'Connect Gmail'}
            </button>
          )}
        </div>
        {error && (
          <div className="text-xs text-rose-700 bg-rose-50 border border-rose-100 rounded-lg px-3 py-2 whitespace-pre-wrap">
            {error}
          </div>
        )}
        {pastePanel}
      </div>
    );
  }

  return (
    <div className="space-y-3" ref={rootRef}>
      <div className="flex items-center justify-between gap-2">
        <div className="text-sm font-semibold text-slate-800 flex items-center gap-2">
          <Users className="h-4 w-4 text-soft-blue" />
          {label || 'Active Gmail sender'}
          <span className="text-[11px] font-mono font-normal text-slate-400">
            {slots.used}/{MAX_GMAIL_ACCOUNTS}
          </span>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setShowPaste((v) => !v)}
            className="inline-flex items-center gap-1 text-xs font-semibold text-slate-500"
          >
            <KeyRound className="h-3.5 w-3.5" /> Token
          </button>
          <button
            type="button"
            onClick={connect}
            disabled={busy}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-soft-blue disabled:opacity-40"
          >
            {busy ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
            {busy ? 'Connecting…' : 'Add account'}
          </button>
        </div>
      </div>

      {accounts.length === 0 ? (
        <button
          type="button"
          onClick={connect}
          disabled={busy}
          className="w-full py-8 rounded-xl border border-dashed border-slate-300 text-sm text-slate-500 hover:border-soft-blue/40 hover:text-soft-blue"
        >
          Connect Gmail to send from your inbox
          <span className="block text-[11px] mt-1 text-slate-400">
            Prefer Chrome extension Connect if web OAuth shows Error 400
          </span>
        </button>
      ) : (
        <div className="space-y-2">
          {accounts.map((a) => {
            const selected = a.email === active;
            const valid = isGmailTokenValid(a);
            return (
              <button
                key={a.email}
                type="button"
                onClick={() => select(a.email)}
                className={`w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-colors ${
                  selected
                    ? 'border-soft-blue bg-blue-50/50 ring-1 ring-soft-blue/20'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                {a.picture ? (
                  <img src={a.picture} alt="" className="h-9 w-9 rounded-full" />
                ) : (
                  <div className="h-9 w-9 rounded-full bg-slate-850 text-white flex items-center justify-center text-sm font-semibold">
                    {a.email[0].toUpperCase()}
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-slate-800 truncate">{a.name}</div>
                  <div className="text-xs text-slate-500 truncate">{a.email}</div>
                </div>
                <div className="text-right">
                  {selected && (
                    <span className="text-[10px] font-bold uppercase tracking-wide text-soft-blue">
                      Active
                    </span>
                  )}
                  <div
                    className={`text-[10px] font-semibold ${valid ? 'text-emerald-600' : 'text-amber-600'}`}
                  >
                    {valid ? 'Token ready' : 'Needs refresh'}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {error && (
        <div className="text-xs text-rose-700 bg-rose-50 border border-rose-100 rounded-lg px-3 py-2 whitespace-pre-wrap">
          {error}
        </div>
      )}

      {pastePanel}

      <p className="text-[11px] text-slate-400 leading-relaxed">
        Up to {MAX_GMAIL_ACCOUNTS} accounts. Each keeps its own token locally. Recommended path when Google shows
        Error 400: install the MailPulse extension and use <strong>Add account</strong> there.
      </p>
    </div>
  );
}
