export default function LoadingState({ label = 'Loading…' }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-3">
      <div className="h-9 w-9 rounded-full border-2 border-slate-200 border-t-soft-blue animate-spin" />
      <div className="text-sm text-slate-500">{label}</div>
    </div>
  );
}

export function EmptyState({ title, description }: { title: string; description: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-slate-300 bg-white/60 px-6 py-14 text-center">
      <div className="text-base font-semibold text-slate-700">{title}</div>
      <div className="mt-1 text-sm text-slate-500 max-w-md mx-auto">{description}</div>
    </div>
  );
}
