const styles: Record<string, string> = {
  draft: 'bg-slate-100 text-slate-600',
  scheduled: 'bg-violet-50 text-violet-700',
  sending: 'bg-amber-50 text-amber-700',
  active: 'bg-sky-50 text-sky-700',
  paused: 'bg-orange-50 text-orange-700',
  completed: 'bg-emerald-50 text-emerald-700',
  pending: 'bg-slate-100 text-slate-600',
  queued: 'bg-violet-50 text-violet-700',
  sent: 'bg-sky-50 text-sky-700',
  opened: 'bg-soft-blue/10 text-soft-blue-dim',
  clicked: 'bg-emerald-50 text-emerald-700',
  failed: 'bg-rose-50 text-rose-700',
};

export default function StatusBadge({ status }: { status: string }) {
  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-semibold uppercase tracking-wide ${
        styles[status] || 'bg-slate-100 text-slate-600'
      }`}
    >
      {status}
    </span>
  );
}
