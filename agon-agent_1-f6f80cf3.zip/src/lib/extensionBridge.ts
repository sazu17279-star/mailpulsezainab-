import { loadGmailAccounts, getActiveGmailEmail } from './gmail';
import { loadSettings } from './storage';

declare global {
  interface Window {
    chrome?: {
      runtime?: {
        sendMessage: (
          extensionId: string,
          message: unknown,
          responseCallback?: (response: unknown) => void
        ) => void;
        lastError?: { message?: string };
      };
    };
  }
}

export function getExtensionId(): string {
  const settings = loadSettings();
  return settings.extensionId || localStorage.getItem('mailpulse_extension_id') || '';
}

export function setExtensionId(id: string) {
  localStorage.setItem('mailpulse_extension_id', id);
}

export function pingExtension(extensionId: string): Promise<{ ok: boolean; version?: string }> {
  return new Promise((resolve) => {
    if (!extensionId || !window.chrome?.runtime?.sendMessage) {
      resolve({ ok: false });
      return;
    }
    try {
      window.chrome.runtime.sendMessage(extensionId, { type: 'PING' }, (response) => {
        if (window.chrome?.runtime?.lastError) {
          resolve({ ok: false });
          return;
        }
        const r = response as { ok?: boolean; version?: string } | undefined;
        resolve({ ok: Boolean(r?.ok), version: r?.version });
      });
    } catch {
      resolve({ ok: false });
    }
  });
}

export function syncExtensionConfig(extensionId?: string): Promise<boolean> {
  const id = extensionId || getExtensionId();
  if (!id || !window.chrome?.runtime?.sendMessage) return Promise.resolve(false);

  const settings = loadSettings();
  const accounts = loadGmailAccounts().map((a) => ({
    email: a.email,
    name: a.name,
    picture: a.picture,
    expiresAt: a.expiresAt,
  }));

  return new Promise((resolve) => {
    try {
      window.chrome!.runtime!.sendMessage(
        id,
        {
          type: 'SYNC_CONFIG',
          apiBase: window.location.origin,
          origin: window.location.origin,
          accounts,
          activeEmail: getActiveGmailEmail(),
          desktopNotifications: settings.desktopNotifications,
          trackingEnabled: settings.trackingEnabled !== false,
        },
        (response) => {
          if (window.chrome?.runtime?.lastError) {
            resolve(false);
            return;
          }
          const ok = Boolean((response as { ok?: boolean })?.ok);
          resolve(ok);
        }
      );
    } catch {
      resolve(false);
    }
  });
}
