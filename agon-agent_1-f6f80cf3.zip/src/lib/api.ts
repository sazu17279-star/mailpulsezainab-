import { directDb, ZERO_STATS } from './directDb';
import { isSupabaseBrowserConfigured } from './supabase';

function isApiUnavailable(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err);
  return (
    /\(404\)|\(405\)|\(502\)|\(503\)|timed out|Connection interrupted|Failed to fetch|NetworkError|not found/i.test(
      msg
    )
  );
}

async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const controller = new AbortController();
  const timeoutMs = 18_000;
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(url, {
      headers: { 'Content-Type': 'application/json', ...(options?.headers || {}) },
      ...options,
      signal: options?.signal || controller.signal,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
    return data as T;
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      throw new Error('Request timed out — the server took too long to respond. Please retry.');
    }
    if (err instanceof TypeError) {
      throw new Error(
        'Connection interrupted. Check your network or retry — the app will keep a clean zero-state if the API is waking up.'
      );
    }
    throw err;
  } finally {
    window.clearTimeout(timer);
  }
}

/**
 * Try serverless API first; on 404/network fall back to direct Supabase.
 * When both fail and `softZero` is provided, return that instead of throwing
 * (keeps the dashboard usable even if /api/* is missing on the host).
 */
async function withFallback<T>(
  apiCall: () => Promise<T>,
  fallback: () => Promise<T>,
  softZero?: T
): Promise<T> {
  try {
    return await apiCall();
  } catch (err) {
    if (!isApiUnavailable(err)) throw err;

    if (isSupabaseBrowserConfigured) {
      try {
        return await fallback();
      } catch {
        if (softZero !== undefined) return softZero;
        throw err;
      }
    }

    if (softZero !== undefined) return softZero;
    throw err;
  }
}

export const api = {
  getStats: () =>
    withFallback(
      () => request<import('./types').DashboardStats>('/api/stats'),
      async () => {
        try {
          return await directDb.getStats();
        } catch {
          return { ...ZERO_STATS };
        }
      },
      { ...ZERO_STATS }
    ),

  getCampaigns: () =>
    withFallback(
      () => request<import('./types').Campaign[]>('/api/campaigns'),
      () => directDb.getCampaigns(),
      []
    ),

  getCampaign: (id: number) =>
    withFallback(
      () => request<import('./types').Campaign>(`/api/campaigns?id=${id}`),
      () => directDb.getCampaign(id)
    ),

  createCampaign: (body: Partial<import('./types').Campaign>) =>
    withFallback(
      () =>
        request<import('./types').Campaign>('/api/campaigns', {
          method: 'POST',
          body: JSON.stringify(body),
        }),
      () => directDb.createCampaign(body)
    ),

  updateCampaign: (body: Partial<import('./types').Campaign> & { id: number }) =>
    withFallback(
      () =>
        request<import('./types').Campaign>('/api/campaigns', {
          method: 'PUT',
          body: JSON.stringify(body),
        }),
      () => directDb.updateCampaign(body)
    ),

  deleteCampaign: (id: number) =>
    withFallback(
      () =>
        request<{ ok: boolean }>('/api/campaigns', {
          method: 'DELETE',
          body: JSON.stringify({ id }),
        }),
      () => directDb.deleteCampaign(id)
    ),

  getRecipients: (campaignId?: number) =>
    withFallback(
      () =>
        request<import('./types').Recipient[]>(
          campaignId ? `/api/recipients?campaign_id=${campaignId}` : '/api/recipients'
        ),
      () => directDb.getRecipients(campaignId),
      []
    ),

  addRecipients: (
    campaign_id: number,
    recipients: { email: string; name?: string; company?: string }[]
  ) =>
    withFallback(
      () =>
        request<import('./types').Recipient[]>('/api/recipients', {
          method: 'POST',
          body: JSON.stringify({ campaign_id, recipients }),
        }),
      () => directDb.addRecipients(campaign_id, recipients)
    ),

  getEvents: (campaignId?: number, limit = 100) =>
    withFallback(
      () =>
        request<import('./types').TrackingEvent[]>(
          campaignId
            ? `/api/events?campaign_id=${campaignId}&limit=${limit}`
            : `/api/events?limit=${limit}`
        ),
      () => directDb.getEvents(campaignId, limit),
      []
    ),

  getTemplates: () =>
    withFallback(
      () => request<import('./types').Template[]>('/api/templates'),
      () => directDb.getTemplates(),
      []
    ),

  createTemplate: (body: Partial<import('./types').Template>) =>
    withFallback(
      () =>
        request<import('./types').Template>('/api/templates', {
          method: 'POST',
          body: JSON.stringify(body),
        }),
      () => directDb.createTemplate(body)
    ),

  updateTemplate: (body: Partial<import('./types').Template> & { id: number }) =>
    withFallback(
      () =>
        request<import('./types').Template>('/api/templates', {
          method: 'PUT',
          body: JSON.stringify(body),
        }),
      () => directDb.updateTemplate(body)
    ),

  deleteTemplate: (id: number) =>
    withFallback(
      () =>
        request<{ ok: boolean }>('/api/templates', {
          method: 'DELETE',
          body: JSON.stringify({ id }),
        }),
      () => directDb.deleteTemplate(id)
    ),

  getNotifications: (unreadOnly = false) =>
    withFallback(
      () =>
        request<import('./types').Notification[]>(
          `/api/notifications${unreadOnly ? '?unread_only=true' : ''}`
        ),
      () => directDb.getNotifications(unreadOnly),
      []
    ),

  markNotificationRead: (id: number) =>
    withFallback(
      () => request('/api/notifications', { method: 'PUT', body: JSON.stringify({ id }) }),
      () => directDb.markNotificationRead(id)
    ),

  markAllNotificationsRead: () =>
    withFallback(
      () =>
        request('/api/notifications', {
          method: 'PUT',
          body: JSON.stringify({ mark_all: true }),
        }),
      () => directDb.markAllNotificationsRead()
    ),

  sendBatch: (campaign_id: number, batch_size = 1) =>
    request<{
      ok: boolean;
      sent: number;
      remaining: number;
      status: string;
      throttle_ms: number;
      gap_seconds?: number;
      mode?: string;
    }>('/api/send', {
      method: 'POST',
      body: JSON.stringify({
        campaign_id,
        action: 'start',
        batch_size: 1,
        base_url: window.location.origin,
      }),
    }),

  pauseCampaign: (campaign_id: number) =>
    request('/api/send', {
      method: 'POST',
      body: JSON.stringify({ campaign_id, action: 'pause' }),
    }),

  scheduleCampaign: (body: {
    campaign_id: number;
    timezone?: string;
    us_state?: string;
    target_send_hour?: number;
    target_hour?: number;
    target_minute?: number;
    preset?: string;
    window_preset?: string;
    mode?: string;
    start_hour?: number;
    start_minute?: number;
    end_hour?: number;
    end_minute?: number;
    schedule_at?: string;
    throttle_ms?: number;
  }) =>
    request<{
      ok: boolean;
      message: string;
      scheduled_for: string;
      timezone: string;
      us_state?: string | null;
      state_name?: string | null;
      local_hour: number;
      local_minute?: number;
      local_time?: string;
      window?: {
        preset?: string;
        mode?: string;
        start?: string;
        end?: string;
      };
      throttle_ms?: number;
      instant_dispatch_gap_ms?: number;
      campaign: import('./types').Campaign;
    }>('/api/schedule', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  getScheduleZones: (opts?: {
    hour?: number;
    preset?: string;
    mode?: string;
    start_hour?: number;
    start_minute?: number;
    end_hour?: number;
    end_minute?: number;
    target_hour?: number;
    target_minute?: number;
  }) => {
    const q = new URLSearchParams();
    if (opts?.preset) q.set('preset', opts.preset);
    if (opts?.mode) q.set('mode', opts.mode);
    if (opts?.hour != null) q.set('hour', String(opts.hour));
    if (opts?.target_hour != null) q.set('target_hour', String(opts.target_hour));
    if (opts?.target_minute != null) q.set('target_minute', String(opts.target_minute));
    if (opts?.start_hour != null) q.set('start_hour', String(opts.start_hour));
    if (opts?.start_minute != null) q.set('start_minute', String(opts.start_minute));
    if (opts?.end_hour != null) q.set('end_hour', String(opts.end_hour));
    if (opts?.end_minute != null) q.set('end_minute', String(opts.end_minute));
    const qs = q.toString();
    return request<{
      zones: {
        timezone: string;
        offset_hours: number;
        next_send_at: string;
        label: string;
        local_time?: string;
      }[];
      us_states: {
        code: string;
        name: string;
        timezone: string;
        abbr: string;
        offset_hours: number;
        next_send_at: string;
        label: string;
        local_hour: number;
        local_minute?: number;
        local_time?: string;
        window_start?: string;
        window_end?: string;
      }[];
      presets?: {
        id: string;
        label: string;
        description: string;
        start_hour: number;
        start_minute: number;
        end_hour: number;
        end_minute: number;
        mode: string;
      }[];
      window?: {
        preset_id: string;
        start_hour: number;
        start_minute: number;
        end_hour: number;
        end_minute: number;
        mode: string;
        label: string;
      };
      default_hour: number;
      morning_window: string;
      instant_dispatch_gap_ms?: number;
    }>(`/api/schedule${qs ? `?${qs}` : ''}`);
  },

  optimize: (body: {
    text: string;
    business_type?: string;
    goal?: string;
    tone?: string;
  }) =>
    request<{
      optimized_body: string;
      subjects: { subject: string; score: number; reason: string }[];
      best_subject: string;
      analysis: Record<string, unknown>;
      tips: string[];
    }>('/api/optimize', { method: 'POST', body: JSON.stringify(body) }),

  gmailProfile: async (access_token: string) => {
    // Call Google directly — no server needed
    const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/profile', {
      headers: { Authorization: `Bearer ${access_token}` },
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data?.error?.message || 'Gmail profile failed');
    return data as { emailAddress: string };
  },

  gmailSendBatch: (body: {
    access_token: string;
    campaign_id: number;
    batch_size?: number;
    tracking_enabled?: boolean;
    from_name?: string;
    from_email?: string;
  }) =>
    request<{
      ok: boolean;
      via: string;
      from: string;
      sent: number;
      failed: number;
      remaining: number;
      status: string;
      throttle_ms: number;
      results: { email: string; ok: boolean; error?: string }[];
    }>('/api/gmail-send', {
      method: 'POST',
      body: JSON.stringify({
        ...body,
        mode: 'batch',
        base_url: window.location.origin,
      }),
    }),

  gmailSendSingle: (body: {
    access_token: string;
    to: string;
    subject: string;
    body?: string;
    html?: string;
    tracking_enabled?: boolean;
    from_name?: string;
    from_email?: string;
    campaign_id?: number;
  }) =>
    request<{
      ok: boolean;
      via: string;
      from: string;
      gmail_id: string;
      tracking: boolean;
      campaign_id: number | null;
    }>('/api/gmail-send', {
      method: 'POST',
      body: JSON.stringify({ ...body, base_url: window.location.origin }),
    }),

  prepareTracking: (body: {
    email: string;
    name?: string;
    subject?: string;
    body?: string;
    campaign_id?: number;
    campaign_name?: string;
  }) =>
    withFallback(
      () =>
        request<{
          ok: boolean;
          campaign_id: number;
          recipient_id: number;
          tracking_token: string;
          pixel_html: string;
          open_url: string;
          zero_watermark: boolean;
        }>('/api/track-prepare', {
          method: 'POST',
          body: JSON.stringify({ ...body, base_url: window.location.origin }),
        }),
      () => directDb.prepareTracking(body)
    ),

  extensionBridge: (since?: string) =>
    withFallback(
      () =>
        request<{
          ok: boolean;
          server_time: string;
          unread: number;
          notifications: (import('./types').Notification & {
            campaign_name?: string;
            recipient_email?: string;
            desktop_title?: string;
            desktop_body?: string;
          })[];
        }>(
          `/api/extension-bridge${since ? `?since=${encodeURIComponent(since)}` : '?limit=30'}`
        ),
      () => directDb.extensionBridge()
    ),

  resetAllData: () =>
    withFallback(
      () =>
        request<{ ok: boolean; message: string }>('/api/reset-data', {
          method: 'POST',
          body: JSON.stringify({ confirm: 'RESET_ALL_DATA' }),
        }),
      () => directDb.resetAllData()
    ),
};
