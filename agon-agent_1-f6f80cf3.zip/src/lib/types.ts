export type CampaignStatus =
  | 'draft'
  | 'scheduled'
  | 'sending'
  | 'paused'
  | 'completed'
  | 'active';

export type RecipientStatus =
  | 'pending'
  | 'queued'
  | 'sent'
  | 'opened'
  | 'clicked'
  | 'failed';

export interface Campaign {
  id: number;
  name: string;
  subject: string;
  body: string;
  status: CampaignStatus;
  schedule_at: string | null;
  timezone: string;
  throttle_ms: number;
  target_send_hour: number;
  recipient_count: number;
  sent_count: number;
  open_count: number;
  click_count: number;
  created_at: string;
  updated_at: string;
}

export interface Recipient {
  id: number;
  campaign_id: number;
  email: string;
  name: string;
  company: string;
  status: RecipientStatus;
  sent_at: string | null;
  open_count: number;
  click_count: number;
  last_opened_at: string | null;
  tracking_token: string;
}

export interface TrackingEvent {
  id: number;
  campaign_id: number;
  recipient_id: number;
  event_type: 'sent' | 'open' | 'click';
  url?: string | null;
  user_agent?: string | null;
  ip?: string | null;
  meta?: string | null;
  created_at: string;
}

export interface Template {
  id: number;
  name: string;
  subject: string;
  body: string;
  category: string;
  created_at: string;
}

export interface Notification {
  id: number;
  campaign_id: number;
  recipient_id: number | null;
  type: string;
  message: string;
  read: boolean;
  created_at: string;
}

export interface DashboardStats {
  totals: {
    campaigns: number;
    active_campaigns: number;
    recipients: number;
    sent: number;
    opened: number;
    clicked: number;
    pending: number;
    open_rate: number;
    click_rate: number;
    unread_notifications: number;
  };
  chart: { date: string; opens: number; clicks: number }[];
  recent_events: TrackingEvent[];
  campaigns: Campaign[];
}

export interface GmailAccount {
  email: string;
  name: string;
  picture: string;
  accessToken: string;
  expiresAt: number;
  connectedAt: string;
}

export interface AppSettings {
  senderName: string;
  senderEmail: string;
  gmailConnected: boolean;
  throttleMs: number;
  desktopNotifications: boolean;
  defaultTimezone: string;
  defaultSendHour: number;
  trackingEnabled: boolean;
  preferGmailSend: boolean;
  extensionId: string;
}

export const DEFAULT_SETTINGS: AppSettings = {
  senderName: 'MailPulse User',
  senderEmail: '',
  gmailConnected: false,
  /** Strict 10-second gap between consecutive bulk sends */
  throttleMs: 10000,
  desktopNotifications: true,
  defaultTimezone: 'America/Chicago',
  defaultSendHour: 9,
  trackingEnabled: true,
  preferGmailSend: true,
  extensionId: '',
};
