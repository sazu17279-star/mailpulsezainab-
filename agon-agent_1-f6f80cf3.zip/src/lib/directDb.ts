/**
 * Direct Supabase access from the browser when /api/* returns 404
 * (common in static-only previews). Uses the public anon key.
 * No mock/seed data — empty tables stay empty (true zero-state).
 */
import { getBrowserSupabase } from './supabase';
import type {
  Campaign,
  DashboardStats,
  Notification,
  Recipient,
  Template,
  TrackingEvent,
} from './types';

const ZERO_STATS: DashboardStats = {
  totals: {
    campaigns: 0,
    active_campaigns: 0,
    recipients: 0,
    sent: 0,
    opened: 0,
    clicked: 0,
    pending: 0,
    open_rate: 0,
    click_rate: 0,
    unread_notifications: 0,
  },
  chart: [],
  recent_events: [],
  campaigns: [],
};

function token() {
  const a = new Uint8Array(16);
  crypto.getRandomValues(a);
  return [...a].map((b) => b.toString(16).padStart(2, '0')).join('');
}

function sb() {
  const c = getBrowserSupabase();
  if (!c) throw new Error('Supabase browser client is not configured');
  return c;
}

export const directDb = {
  async getStats(): Promise<DashboardStats> {
    try {
      const client = sb();
      const [cRes, rRes, eRes, nRes] = await Promise.all([
        client.from('mp_campaigns').select('*').order('created_at', { ascending: false }),
        client.from('mp_recipients').select('*'),
        client
          .from('mp_tracking_events')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(200),
        client.from('mp_notifications').select('*').eq('read', false),
      ]);

      const campaigns = (cRes.data || []) as Campaign[];
      const recipients = (rRes.data || []) as Recipient[];
      const events = (eRes.data || []) as TrackingEvent[];
      const notifs = nRes.data || [];

      const sent = recipients.filter((r) =>
        ['sent', 'opened', 'clicked'].includes(r.status)
      ).length;
      const opened = recipients.filter((r) => (r.open_count || 0) > 0).length;
      const clicked = recipients.filter((r) => (r.click_count || 0) > 0).length;
      const pending = recipients.filter((r) =>
        ['pending', 'queued'].includes(r.status)
      ).length;
      const openRate = sent > 0 ? Math.round((opened / sent) * 1000) / 10 : 0;
      const clickRate = sent > 0 ? Math.round((clicked / sent) * 1000) / 10 : 0;

      const byDay: Record<string, { date: string; opens: number; clicks: number }> = {};
      for (const e of events) {
        const day = (e.created_at || '').slice(0, 10);
        if (!day) continue;
        if (!byDay[day]) byDay[day] = { date: day, opens: 0, clicks: 0 };
        if (e.event_type === 'open') byDay[day].opens += 1;
        if (e.event_type === 'click') byDay[day].clicks += 1;
      }

      return {
        totals: {
          campaigns: campaigns.length,
          active_campaigns: campaigns.filter((c) =>
            ['sending', 'scheduled', 'active'].includes(c.status)
          ).length,
          recipients: recipients.length,
          sent,
          opened,
          clicked,
          pending,
          open_rate: openRate,
          click_rate: clickRate,
          unread_notifications: notifs.length,
        },
        chart: Object.values(byDay)
          .sort((a, b) => a.date.localeCompare(b.date))
          .slice(-14),
        recent_events: events.slice(0, 20),
        campaigns: campaigns.slice(0, 8),
      };
    } catch {
      return { ...ZERO_STATS };
    }
  },

  async getCampaigns(): Promise<Campaign[]> {
    const { data, error } = await sb()
      .from('mp_campaigns')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw new Error(error.message);
    return (data || []) as Campaign[];
  },

  async getCampaign(id: number): Promise<Campaign> {
    const { data, error } = await sb().from('mp_campaigns').select('*').eq('id', id).single();
    if (error) throw new Error(error.message);
    return data as Campaign;
  },

  async createCampaign(body: Partial<Campaign>): Promise<Campaign> {
    const row = {
      name: body.name,
      subject: body.subject,
      body: body.body,
      status: body.status || 'draft',
      schedule_at: body.schedule_at || null,
      timezone: body.timezone || 'UTC',
      throttle_ms: body.throttle_ms ?? 3000,
      target_send_hour: body.target_send_hour ?? 9,
      recipient_count: 0,
      sent_count: 0,
      open_count: 0,
      click_count: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    const { data, error } = await sb().from('mp_campaigns').insert(row).select().single();
    if (error) throw new Error(error.message);
    return data as Campaign;
  },

  async updateCampaign(body: Partial<Campaign> & { id: number }): Promise<Campaign> {
    const { id, ...rest } = body;
    const { data, error } = await sb()
      .from('mp_campaigns')
      .update({ ...rest, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    if (error) throw new Error(error.message);
    return data as Campaign;
  },

  async deleteCampaign(id: number): Promise<{ ok: boolean }> {
    await sb().from('mp_tracking_events').delete().eq('campaign_id', id);
    await sb().from('mp_notifications').delete().eq('campaign_id', id);
    await sb().from('mp_recipients').delete().eq('campaign_id', id);
    const { error } = await sb().from('mp_campaigns').delete().eq('id', id);
    if (error) throw new Error(error.message);
    return { ok: true };
  },

  async getRecipients(campaignId?: number): Promise<Recipient[]> {
    let q = sb().from('mp_recipients').select('*').order('id', { ascending: true });
    if (campaignId) q = q.eq('campaign_id', campaignId);
    const { data, error } = await q;
    if (error) throw new Error(error.message);
    return (data || []) as Recipient[];
  },

  async addRecipients(
    campaign_id: number,
    recipients: { email: string; name?: string; company?: string }[]
  ): Promise<Recipient[]> {
    const rows = recipients
      .map((r) => {
        const email = (r.email || '').toString().trim().toLowerCase();
        if (!email.includes('@')) return null;
        return {
          campaign_id,
          email,
          name: r.name || email.split('@')[0],
          company: r.company || '',
          status: 'pending',
          open_count: 0,
          click_count: 0,
          tracking_token: token(),
        };
      })
      .filter(Boolean);
    if (!rows.length) throw new Error('No valid emails');
    const { data, error } = await sb().from('mp_recipients').insert(rows).select();
    if (error) throw new Error(error.message);
    await sb()
      .from('mp_campaigns')
      .update({ recipient_count: rows.length, updated_at: new Date().toISOString() })
      .eq('id', campaign_id);
    return (data || []) as Recipient[];
  },

  async getEvents(campaignId?: number, limit = 100): Promise<TrackingEvent[]> {
    let q = sb()
      .from('mp_tracking_events')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(limit);
    if (campaignId) q = q.eq('campaign_id', campaignId);
    const { data, error } = await q;
    if (error) throw new Error(error.message);
    return (data || []) as TrackingEvent[];
  },

  async getTemplates(): Promise<Template[]> {
    const { data, error } = await sb()
      .from('mp_templates')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw new Error(error.message);
    return (data || []) as Template[];
  },

  async createTemplate(body: Partial<Template>): Promise<Template> {
    const { data, error } = await sb()
      .from('mp_templates')
      .insert({
        name: body.name,
        subject: body.subject,
        body: body.body,
        category: body.category || 'general',
        created_at: new Date().toISOString(),
      })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return data as Template;
  },

  async updateTemplate(body: Partial<Template> & { id: number }): Promise<Template> {
    const { id, ...rest } = body;
    const { data, error } = await sb()
      .from('mp_templates')
      .update(rest)
      .eq('id', id)
      .select()
      .single();
    if (error) throw new Error(error.message);
    return data as Template;
  },

  async deleteTemplate(id: number): Promise<{ ok: boolean }> {
    const { error } = await sb().from('mp_templates').delete().eq('id', id);
    if (error) throw new Error(error.message);
    return { ok: true };
  },

  async getNotifications(unreadOnly = false): Promise<Notification[]> {
    let q = sb()
      .from('mp_notifications')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50);
    if (unreadOnly) q = q.eq('read', false);
    const { data, error } = await q;
    if (error) throw new Error(error.message);
    return (data || []) as Notification[];
  },

  async markNotificationRead(id: number) {
    const { data, error } = await sb()
      .from('mp_notifications')
      .update({ read: true })
      .eq('id', id)
      .select()
      .single();
    if (error) throw new Error(error.message);
    return data;
  },

  async markAllNotificationsRead() {
    const { error } = await sb().from('mp_notifications').update({ read: true }).eq('read', false);
    if (error) throw new Error(error.message);
    return { ok: true };
  },

  async extensionBridge() {
    const notes = await this.getNotifications(false);
    return {
      ok: true,
      server_time: new Date().toISOString(),
      unread: notes.filter((n) => !n.read).length,
      notifications: notes,
    };
  },

  async resetAllData() {
    const client = sb();
    for (const table of [
      'mp_notifications',
      'mp_tracking_events',
      'mp_recipients',
      'mp_campaigns',
      'mp_templates',
    ]) {
      await client.from(table).delete().gte('id', 0);
    }
    return { ok: true, message: 'All data wiped — zero state.' };
  },

  async prepareTracking(body: {
    email: string;
    name?: string;
    subject?: string;
    body?: string;
    campaign_id?: number;
    campaign_name?: string;
  }) {
    const tracking_token = token();
    let cid = body.campaign_id ? Number(body.campaign_id) : null;
    if (!cid) {
      const camp = await this.createCampaign({
        name: body.campaign_name || `Gmail · ${body.email}`,
        subject: body.subject || 'Tracked email',
        body: body.body || '',
        status: 'active',
      });
      cid = camp.id;
    }
    const { data: recipient, error } = await sb()
      .from('mp_recipients')
      .insert({
        campaign_id: cid,
        email: body.email.toLowerCase().trim(),
        name: body.name || body.email.split('@')[0],
        company: '',
        status: 'pending',
        open_count: 0,
        click_count: 0,
        tracking_token,
      })
      .select()
      .single();
    if (error) throw new Error(error.message);
    const origin = window.location.origin;
    const openUrl = `${origin}/api/track-open?t=${tracking_token}`;
    const pixel = `<img src="${openUrl}" width="1" height="1" alt="" style="display:none!important;width:1px!important;height:1px!important;border:0!important;opacity:0!important;" />`;
    return {
      ok: true,
      campaign_id: cid,
      recipient_id: recipient.id,
      tracking_token,
      open_url: openUrl,
      pixel_html: pixel,
      zero_watermark: true,
    };
  },
};

export { ZERO_STATS };
