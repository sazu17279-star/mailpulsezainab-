import { AppSettings, DEFAULT_SETTINGS } from './types';

const SETTINGS_KEY = 'mailpulse_settings_v1';
const SEEN_NOTIF_KEY = 'mailpulse_seen_notif_ids';

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return { ...DEFAULT_SETTINGS };
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export function saveSettings(settings: AppSettings) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

export function loadSeenNotificationIds(): number[] {
  try {
    return JSON.parse(localStorage.getItem(SEEN_NOTIF_KEY) || '[]');
  } catch {
    return [];
  }
}

export function saveSeenNotificationIds(ids: number[]) {
  localStorage.setItem(SEEN_NOTIF_KEY, JSON.stringify(ids.slice(-200)));
}

export function parseBulkRecipients(text: string): {
  email: string;
  name: string;
  company: string;
}[] {
  const lines = text
    .split(/[\n,;]+/)
    .map((l) => l.trim())
    .filter(Boolean);

  const seen = new Set<string>();
  const out: { email: string; name: string; company: string }[] = [];

  for (const line of lines) {
    // Formats: email | name <email> | name, email, company | email,name,company
    let email = '';
    let name = '';
    let company = '';

    const angle = line.match(/^(.*)<([^>]+@[^>]+)>$/);
    if (angle) {
      name = angle[1].trim().replace(/^"|"$/g, '');
      email = angle[2].trim().toLowerCase();
    } else if (line.includes('\t')) {
      const parts = line.split('\t').map((p) => p.trim());
      email = (parts.find((p) => p.includes('@')) || '').toLowerCase();
      name = parts[0]?.includes('@') ? parts[0].split('@')[0] : parts[0] || '';
      company = parts.find((p, i) => i > 0 && !p.includes('@')) || '';
    } else if (line.includes(',')) {
      const parts = line.split(',').map((p) => p.trim());
      const emailPart = parts.find((p) => p.includes('@')) || '';
      email = emailPart.toLowerCase();
      const others = parts.filter((p) => p !== emailPart);
      name = others[0] || email.split('@')[0];
      company = others[1] || '';
    } else if (line.includes('@')) {
      email = line.toLowerCase();
      name = email.split('@')[0];
    } else {
      continue;
    }

    if (!email.includes('@') || seen.has(email)) continue;
    seen.add(email);
    out.push({
      email,
      name: name || email.split('@')[0],
      company,
    });
  }

  return out;
}

export function personalize(text: string, vars: Record<string, string>) {
  return text.replace(/\{\{(\w+)\}\}/gi, (_, key: string) => {
    return vars[key.toLowerCase()] ?? vars[key] ?? `{{${key}}}`;
  });
}

export function formatRelative(iso: string | null | undefined) {
  if (!iso) return '—';
  const d = new Date(iso);
  const diff = Date.now() - d.getTime();
  const sec = Math.floor(diff / 1000);
  if (sec < 60) return 'just now';
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const day = Math.floor(hr / 24);
  if (day < 7) return `${day}d ago`;
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

export function formatDateTime(iso: string | null | undefined) {
  if (!iso) return '—';
  return new Date(iso).toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}
