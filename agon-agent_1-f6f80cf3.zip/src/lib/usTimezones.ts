/** US state → IANA timezone mapping (primary civil zone) */
export interface UsStateZone {
  code: string;
  name: string;
  timezone: string;
  abbr: string;
}

export const US_STATE_TIMEZONES: UsStateZone[] = [
  { code: 'AL', name: 'Alabama', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'AK', name: 'Alaska', timezone: 'America/Anchorage', abbr: 'AKT' },
  { code: 'AZ', name: 'Arizona', timezone: 'America/Phoenix', abbr: 'MST' },
  { code: 'AR', name: 'Arkansas', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'CA', name: 'California', timezone: 'America/Los_Angeles', abbr: 'PT' },
  { code: 'CO', name: 'Colorado', timezone: 'America/Denver', abbr: 'MT' },
  { code: 'CT', name: 'Connecticut', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'DE', name: 'Delaware', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'DC', name: 'District of Columbia', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'FL', name: 'Florida', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'GA', name: 'Georgia', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'HI', name: 'Hawaii', timezone: 'Pacific/Honolulu', abbr: 'HT' },
  { code: 'ID', name: 'Idaho', timezone: 'America/Boise', abbr: 'MT' },
  { code: 'IL', name: 'Illinois', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'IN', name: 'Indiana', timezone: 'America/Indiana/Indianapolis', abbr: 'ET' },
  { code: 'IA', name: 'Iowa', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'KS', name: 'Kansas', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'KY', name: 'Kentucky', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'LA', name: 'Louisiana', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'ME', name: 'Maine', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'MD', name: 'Maryland', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'MA', name: 'Massachusetts', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'MI', name: 'Michigan', timezone: 'America/Detroit', abbr: 'ET' },
  { code: 'MN', name: 'Minnesota', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'MS', name: 'Mississippi', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'MO', name: 'Missouri', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'MT', name: 'Montana', timezone: 'America/Denver', abbr: 'MT' },
  { code: 'NE', name: 'Nebraska', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'NV', name: 'Nevada', timezone: 'America/Los_Angeles', abbr: 'PT' },
  { code: 'NH', name: 'New Hampshire', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'NJ', name: 'New Jersey', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'NM', name: 'New Mexico', timezone: 'America/Denver', abbr: 'MT' },
  { code: 'NY', name: 'New York', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'NC', name: 'North Carolina', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'ND', name: 'North Dakota', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'OH', name: 'Ohio', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'OK', name: 'Oklahoma', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'OR', name: 'Oregon', timezone: 'America/Los_Angeles', abbr: 'PT' },
  { code: 'PA', name: 'Pennsylvania', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'RI', name: 'Rhode Island', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'SC', name: 'South Carolina', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'SD', name: 'South Dakota', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'TN', name: 'Tennessee', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'TX', name: 'Texas', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'UT', name: 'Utah', timezone: 'America/Denver', abbr: 'MT' },
  { code: 'VT', name: 'Vermont', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'VA', name: 'Virginia', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'WA', name: 'Washington', timezone: 'America/Los_Angeles', abbr: 'PT' },
  { code: 'WV', name: 'West Virginia', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'WI', name: 'Wisconsin', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'WY', name: 'Wyoming', timezone: 'America/Denver', abbr: 'MT' },
];

export const DEFAULT_US_STATE = 'TX';

export function findUsState(codeOrName: string): UsStateZone | undefined {
  const q = codeOrName.trim().toUpperCase();
  return US_STATE_TIMEZONES.find(
    (s) => s.code === q || s.name.toUpperCase() === q || s.timezone === codeOrName
  );
}

/** Strict 10-second gap between consecutive campaign emails (instant dispatch) */
export const INSTANT_DISPATCH_GAP_MS = 10_000;

/** Flexible engagement windows — not locked to 9:00 AM */
export type SchedulePresetId =
  | 'smart'
  | 'morning'
  | 'late_morning'
  | 'midday'
  | 'afternoon'
  | 'business'
  | 'custom';

export interface ScheduleWindowPreset {
  id: SchedulePresetId;
  label: string;
  description: string;
  start_hour: number;
  start_minute: number;
  end_hour: number;
  end_minute: number;
  mode: 'smart' | 'peak' | 'window' | 'next_available' | 'custom';
}

export const SCHEDULE_WINDOW_PRESETS: ScheduleWindowPreset[] = [
  {
    id: 'smart',
    label: 'Smart peak (auto)',
    description: 'Next high-engagement slot in the business day (morning or early afternoon)',
    start_hour: 9,
    start_minute: 0,
    end_hour: 16,
    end_minute: 0,
    mode: 'smart',
  },
  {
    id: 'morning',
    label: 'Morning window',
    description: 'Flexible 9:00–11:30 AM local',
    start_hour: 9,
    start_minute: 0,
    end_hour: 11,
    end_minute: 30,
    mode: 'window',
  },
  {
    id: 'late_morning',
    label: 'Late morning peak',
    description: '10:00–11:30 AM — strong open rates',
    start_hour: 10,
    start_minute: 0,
    end_hour: 11,
    end_minute: 30,
    mode: 'peak',
  },
  {
    id: 'midday',
    label: 'Midday',
    description: '11:00 AM–1:00 PM local',
    start_hour: 11,
    start_minute: 0,
    end_hour: 13,
    end_minute: 0,
    mode: 'window',
  },
  {
    id: 'afternoon',
    label: 'Afternoon',
    description: '1:00–4:00 PM local',
    start_hour: 13,
    start_minute: 0,
    end_hour: 16,
    end_minute: 0,
    mode: 'window',
  },
  {
    id: 'business',
    label: 'Full business day',
    description: '9:00 AM–5:00 PM — next available slot',
    start_hour: 9,
    start_minute: 0,
    end_hour: 17,
    end_minute: 0,
    mode: 'next_available',
  },
  {
    id: 'custom',
    label: 'Custom time',
    description: 'Pick an exact local hour and minute',
    start_hour: 9,
    start_minute: 0,
    end_hour: 17,
    end_minute: 0,
    mode: 'custom',
  },
];

export function formatHourMinute(hour: number, minute = 0) {
  return `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
}
