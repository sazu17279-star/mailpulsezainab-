import type { GmailAccount } from './types';

/** Hard cap: up to 10 simultaneous Gmail identities */
export const MAX_GMAIL_ACCOUNTS = 10;

const GMAIL_ACCOUNTS_KEY = 'mailpulse_gmail_accounts_v1';
const ACTIVE_GMAIL_KEY = 'mailpulse_active_gmail_v1';

function readExtensionId(): string {
  try {
    const raw = localStorage.getItem('mailpulse_settings_v1');
    if (raw) {
      const s = JSON.parse(raw) as { extensionId?: string };
      if (s.extensionId) return s.extensionId;
    }
  } catch {
    /* ignore */
  }
  return localStorage.getItem('mailpulse_extension_id') || '';
}

export const GMAIL_SCOPES = [
  'openid',
  'email',
  'profile',
  'https://www.googleapis.com/auth/gmail.send',
  'https://www.googleapis.com/auth/gmail.compose',
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/userinfo.profile',
].join(' ');

declare global {
  interface Window {
    chrome?: {
      runtime?: {
        sendMessage: (
          extensionId: string,
          message: unknown,
          responseCallback?: (response: unknown) => void
        ) => void;
        lastError?: { message?: string };
      };
    };
  }
}

function normalizeAccounts(list: GmailAccount[]): GmailAccount[] {
  const byEmail = new Map<string, GmailAccount>();
  for (const a of list) {
    if (!a?.email || !a.accessToken) continue;
    const email = a.email.toLowerCase().trim();
    byEmail.set(email, {
      ...a,
      email,
      accessToken: a.accessToken,
      expiresAt: Number(a.expiresAt) || 0,
      name: a.name || email.split('@')[0],
      picture: a.picture || '',
      connectedAt: a.connectedAt || new Date().toISOString(),
    });
  }
  return [...byEmail.values()].slice(0, MAX_GMAIL_ACCOUNTS);
}

export function loadGmailAccounts(): GmailAccount[] {
  try {
    const raw = localStorage.getItem(GMAIL_ACCOUNTS_KEY);
    if (!raw) return [];
    return normalizeAccounts(JSON.parse(raw) as GmailAccount[]);
  } catch {
    return [];
  }
}

export function saveGmailAccounts(accounts: GmailAccount[]) {
  const normalized = normalizeAccounts(accounts).slice(0, MAX_GMAIL_ACCOUNTS);
  localStorage.setItem(GMAIL_ACCOUNTS_KEY, JSON.stringify(normalized));
  try {
    localStorage.setItem(
      'mailpulse_extension_sync',
      JSON.stringify({
        accounts: normalized.map((a) => ({
          email: a.email,
          name: a.name,
          picture: a.picture,
          expiresAt: a.expiresAt,
        })),
        activeEmail: getActiveGmailEmail(),
        maxAccounts: MAX_GMAIL_ACCOUNTS,
        updatedAt: Date.now(),
      })
    );
  } catch {
    /* ignore */
  }
}

export function getActiveGmailEmail(): string | null {
  const email = localStorage.getItem(ACTIVE_GMAIL_KEY);
  return email ? email.toLowerCase() : null;
}

export function setActiveGmailEmail(email: string | null) {
  if (email) localStorage.setItem(ACTIVE_GMAIL_KEY, email.toLowerCase().trim());
  else localStorage.removeItem(ACTIVE_GMAIL_KEY);
}

export function getActiveGmailAccount(): GmailAccount | null {
  const accounts = loadGmailAccounts();
  const active = getActiveGmailEmail();
  if (active) {
    const found = accounts.find((a) => a.email === active);
    if (found) return found;
  }
  return accounts[0] || null;
}

export function removeGmailAccount(email: string) {
  const target = email.toLowerCase().trim();
  const next = loadGmailAccounts().filter((a) => a.email !== target);
  saveGmailAccounts(next);
  if (getActiveGmailEmail() === target) {
    setActiveGmailEmail(next[0]?.email || null);
  }
}

export function canAddGmailAccount(): boolean {
  return loadGmailAccounts().length < MAX_GMAIL_ACCOUNTS;
}

export function gmailAccountSlots(): { used: number; max: number; remaining: number } {
  const used = loadGmailAccounts().length;
  return { used, max: MAX_GMAIL_ACCOUNTS, remaining: Math.max(0, MAX_GMAIL_ACCOUNTS - used) };
}

function upsertAccount(account: GmailAccount): GmailAccount {
  const email = account.email.toLowerCase().trim();
  const existing = loadGmailAccounts();
  const isNew = !existing.some((a) => a.email === email);

  if (isNew && existing.length >= MAX_GMAIL_ACCOUNTS) {
    throw new Error(
      `Account limit reached (${MAX_GMAIL_ACCOUNTS}). Remove an account before connecting another.`
    );
  }

  const next = [
    { ...account, email, accessToken: account.accessToken },
    ...existing.filter((a) => a.email !== email),
  ].slice(0, MAX_GMAIL_ACCOUNTS);

  saveGmailAccounts(next);
  setActiveGmailEmail(email);
  return next.find((a) => a.email === email)!;
}

async function fetchUserInfo(accessToken: string) {
  const res = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(
      (err as { error_description?: string }).error_description ||
        'Invalid access token — it may lack userinfo scope or be expired'
    );
  }
  return res.json() as Promise<{ email: string; name?: string; picture?: string }>;
}

function buildAccountFromToken(
  accessToken: string,
  expiresIn: number,
  profile: { email: string; name?: string; picture?: string }
): GmailAccount {
  return {
    email: profile.email.toLowerCase().trim(),
    name: profile.name || profile.email.split('@')[0],
    picture: profile.picture || '',
    accessToken,
    expiresAt: Date.now() + Math.max(60, expiresIn - 60) * 1000,
    connectedAt: new Date().toISOString(),
  };
}

/** Import a raw Google OAuth access token (OAuth Playground / extension). */
export async function connectWithAccessToken(
  accessToken: string,
  expiresIn = 3600
): Promise<GmailAccount> {
  const token = accessToken.trim().replace(/^Bearer\s+/i, '');
  if (!token || token.length < 20) {
    throw new Error('Paste a valid Google access token');
  }
  const profile = await fetchUserInfo(token);
  return upsertAccount(buildAccountFromToken(token, expiresIn, profile));
}

/**
 * Chrome extension path — chrome.identity / launchWebAuthFlow in the service worker.
 * This is the most reliable multi-account path (no Google Cloud redirect URI for web needed).
 */
function connectViaExtension(): Promise<GmailAccount | null> {
  const extensionId = readExtensionId();
  if (!extensionId || !window.chrome?.runtime?.sendMessage) {
    return Promise.resolve(null);
  }

  return new Promise((resolve) => {
    const timer = window.setTimeout(() => resolve(null), 12_000);
    try {
      window.chrome!.runtime!.sendMessage(
        extensionId,
        {
          type: 'CONNECT_GMAIL',
          forceAccountPicker: true,
          maxAccounts: MAX_GMAIL_ACCOUNTS,
        },
        (response) => {
          window.clearTimeout(timer);
          if (window.chrome?.runtime?.lastError) {
            resolve(null);
            return;
          }
          const r = response as
            | { ok?: boolean; account?: GmailAccount; error?: string }
            | undefined;
          if (r?.ok && r.account?.email && r.account.accessToken) {
            try {
              resolve(upsertAccount(r.account));
            } catch {
              resolve(null);
            }
            return;
          }
          resolve(null);
        }
      );
    } catch {
      window.clearTimeout(timer);
      resolve(null);
    }
  });
}

/**
 * Design Arena OAuth proxy — uses the already-registered redirect URI
 * (VITE_GOOGLE_AUTH_PROXY). Opens a real popup, never an iframe.
 *
 * Note: the proxy may only return an id_token for Supabase login. If we
 * receive an access_token with Gmail scopes, we use it; otherwise we fall
 * through so the user can paste a token or use the extension.
 */
function connectViaDesignArenaProxy(): Promise<GmailAccount> {
  const clientId = (
    (import.meta.env.VITE_GOOGLE_CLIENT_ID as string | undefined) ||
    '1065078894672-rmp5kp8vfjns5rn9kp5psfp16g691043.apps.googleusercontent.com'
  ).trim();

  const redirectUri = (
    (import.meta.env.VITE_GOOGLE_AUTH_PROXY as string | undefined) ||
    'https://designarena.ai/auth/google/callback'
  ).trim();

  const supabaseUrl = (import.meta.env.VITE_SUPABASE_URL as string | undefined) || '';
  const supabaseAnonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined) || '';

  const state = btoa(
    JSON.stringify({
      origin: window.location.origin,
      appName: 'MailPulse Gmail',
      purpose: 'gmail_send',
      supabaseUrl,
      supabaseAnonKey,
    })
  );

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: GMAIL_SCOPES,
    prompt: 'consent select_account',
    access_type: 'offline',
    include_granted_scopes: 'true',
    state,
  });

  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;

  const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
  const opened = window.open(
    authUrl,
    'mailpulse-google-auth',
    isMobile ? '' : 'width=520,height=720,popup=yes'
  );

  if (!opened) {
    return Promise.reject(
      new Error(
        'Popup blocked. Allow popups for this site, or use “Paste access token” / Chrome extension Connect.'
      )
    );
  }
  const popupWin: Window = opened;

  return new Promise((resolve, reject) => {
    let settled = false;

    const finish = async (accessToken: string, expiresIn = 3600) => {
      if (settled) return;
      settled = true;
      cleanup();
      try {
        const profile = await fetchUserInfo(accessToken);
        resolve(upsertAccount(buildAccountFromToken(accessToken, expiresIn, profile)));
      } catch (e) {
        reject(
          e instanceof Error
            ? e
            : new Error(
                'Got a token but it cannot call Gmail/userinfo. Use the Chrome extension or paste a Gmail API token from OAuth Playground.'
              )
        );
      }
    };

    const fail = (msg: string) => {
      if (settled) return;
      settled = true;
      cleanup();
      reject(new Error(msg));
    };

    const onMessage = (event: MessageEvent) => {
      const data = event.data;
      if (!data || typeof data !== 'object') return;

      if (data.type === 'google-auth-denied') {
        fail('Google sign-in was cancelled.');
        return;
      }

      if (data.type === 'google-auth-success') {
        if (data.access_token) {
          void finish(String(data.access_token), Number(data.expires_in) || 3600);
          return;
        }
        fail(
          'Sign-in returned an ID token only (no Gmail access token). Install the MailPulse Chrome extension and click Connect there, or paste a Gmail access token from Google OAuth Playground (scope: gmail.send).'
        );
        return;
      }

      if (data.type === 'mailpulse-gmail-oauth' && data.access_token) {
        void finish(String(data.access_token), Number(data.expires_in) || 3600);
      }
    };

    const pollClosed = window.setInterval(() => {
      try {
        if (popupWin.closed && !settled) {
          window.setTimeout(() => {
            if (!settled) {
              fail(
                'Sign-in window closed. If you saw Google Error 400, the web OAuth client is not authorized for this domain — use the Chrome extension Connect button (recommended) or paste a token.'
              );
            }
          }, 600);
        }
      } catch {
        /* ignore */
      }
    }, 500);

    const timeout = window.setTimeout(() => {
      fail('Gmail sign-in timed out. Try the Chrome extension Connect button instead.');
    }, 5 * 60 * 1000);

    function cleanup() {
      window.clearInterval(pollClosed);
      window.clearTimeout(timeout);
      window.removeEventListener('message', onMessage);
      try {
        if (!popupWin.closed) popupWin.close();
      } catch {
        /* ignore */
      }
    }

    window.addEventListener('message', onMessage);
    try {
      popupWin.focus();
    } catch {
      /* ignore */
    }
  });
}

/**
 * Connect Gmail (max 10 accounts).
 * Order:
 *  1) Chrome extension chrome.identity (best)
 *  2) Design Arena registered OAuth proxy popup
 * Throws with clear recovery steps if both fail.
 */
export async function connectGmailAccount(_opts?: {
  forceConsent?: boolean;
}): Promise<GmailAccount> {
  const viaExt = await connectViaExtension();
  if (viaExt) return viaExt;

  try {
    return await connectViaDesignArenaProxy();
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'Connect failed';
    throw new Error(
      `${msg}\n\nWhat works right now:\n` +
        `1) Install MailPulse extension → popup → Add account (chrome.identity)\n` +
        `2) Or paste a Gmail access token (OAuth Playground, scope gmail.send)\n` +
        `3) Open this app in a normal Chrome tab (not a locked preview iframe)`
    );
  }
}

export async function reauthGmailAccount(_email: string): Promise<GmailAccount> {
  return connectGmailAccount({ forceConsent: true });
}

export async function ensureFreshToken(account: GmailAccount): Promise<GmailAccount> {
  if (account.accessToken && account.expiresAt > Date.now() + 30_000) {
    return account;
  }
  const refreshed = await connectGmailAccount({ forceConsent: true });
  if (refreshed.email === account.email) return refreshed;
  const still = loadGmailAccounts().find((a) => a.email === account.email);
  if (still && isGmailTokenValid(still)) return still;
  throw new Error(
    `Token expired for ${account.email}. Re-connect that account (extension or paste token).`
  );
}

export async function getValidAccessToken(
  email?: string
): Promise<{ account: GmailAccount; token: string }> {
  const accounts = loadGmailAccounts();
  let account = email
    ? accounts.find((a) => a.email === email.toLowerCase().trim()) || null
    : getActiveGmailAccount();

  if (!account) {
    account = await connectGmailAccount({ forceConsent: true });
  } else if (account.expiresAt <= Date.now() + 30_000) {
    account = await ensureFreshToken(account);
  }

  if (!account.accessToken) throw new Error('No Gmail access token for selected account');
  const verified = loadGmailAccounts().find((a) => a.email === account!.email);
  if (!verified || verified.accessToken !== account.accessToken) {
    throw new Error('Token mismatch — re-connect the selected Gmail account');
  }

  return { account: verified, token: verified.accessToken };
}

export function isGmailTokenValid(account: GmailAccount | null | undefined): boolean {
  return Boolean(account?.accessToken && account.expiresAt > Date.now());
}

/** Legacy callback helpers kept so existing routes don't crash */
export function completeGmailOAuthCallback(): boolean {
  return false;
}

export async function consumePendingOAuth(): Promise<GmailAccount | null> {
  return null;
}
