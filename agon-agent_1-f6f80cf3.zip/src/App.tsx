import { useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Campaigns from './pages/Campaigns';
import CampaignDetail from './pages/CampaignDetail';
import Composer from './pages/Composer';
import Templates from './pages/Templates';
import Activity from './pages/Activity';
import AIOptimizer from './pages/AIOptimizer';
import Scheduler from './pages/Scheduler';
import Settings from './pages/Settings';
import ExtensionPage from './pages/Extension';
import GmailOAuthCallback from './pages/GmailOAuthCallback';
import BrowserHelp from './pages/BrowserHelp';
import { consumePendingOAuth } from './lib/gmail';

function PendingOAuthBootstrap() {
  useEffect(() => {
    consumePendingOAuth().catch(() => {});
  }, []);
  return null;
}

export default function App() {
  return (
    <BrowserRouter>
      <PendingOAuthBootstrap />
      <Routes>
        {/* Standalone OAuth popup callback — no app chrome, never iframe Google */}
        <Route path="/oauth/gmail/callback" element={<GmailOAuthCallback />} />
        <Route element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="campaigns" element={<Campaigns />} />
          <Route path="campaigns/:id" element={<CampaignDetail />} />
          <Route path="composer" element={<Composer />} />
          <Route path="templates" element={<Templates />} />
          <Route path="activity" element={<Activity />} />
          <Route path="ai" element={<AIOptimizer />} />
          <Route path="scheduler" element={<Scheduler />} />
          <Route path="extension" element={<ExtensionPage />} />
          <Route path="help" element={<BrowserHelp />} />
          <Route path="settings" element={<Settings />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
