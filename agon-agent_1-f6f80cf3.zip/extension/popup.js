const $ = (id) => document.getElementById(id);
const MAX = 10;

async function getConfig() {
  const res = await chrome.runtime.sendMessage({ type: 'GET_CONFIG' });
  return res.config || {};
}

function setSwitch(el, on) {
  el.classList.toggle('on', on);
  el.setAttribute('aria-pressed', on ? 'true' : 'false');
}

async function loadFeed(apiBase) {
  const feed = $('feed');
  if (!apiBase) {
    feed.innerHTML = '<div class="hint">Set dashboard URL to load alerts.</div>';
    return;
  }
  try {
    const res = await fetch(`${apiBase.replace(/\/$/, '')}/api/extension-bridge?limit=8`);
    const data = await res.json();
    const items = data.notifications || [];
    if (!items.length) {
      feed.innerHTML =
        '<div class="hint">No activity yet — 0 opens / 0 clicks until real events arrive.</div>';
      return;
    }
    feed.innerHTML = items
      .map(
        (n) => `
      <div class="feed-item">
        <strong><span class="dot ${n.type === 'click' ? 'click' : 'open'}"></span>${n.desktop_title || n.type}</strong>
        ${(n.recipient_email || n.message || '').replace(/</g, '&lt;')}<br/>
        <span style="color:#94a3b8">${n.campaign_name || ''} · ${new Date(n.created_at).toLocaleString()}</span>
      </div>`
      )
      .join('');
  } catch {
    feed.innerHTML = '<div class="hint">Could not reach dashboard API.</div>';
  }
}

async function listAccounts() {
  const res = await chrome.runtime.sendMessage({ type: 'LIST_GMAIL' });
  return {
    accounts: res?.accounts || [],
    activeEmail: res?.activeEmail || null,
    max: res?.maxAccounts || MAX,
  };
}

function fillAccounts(accounts, activeEmail, max) {
  const sel = $('accountSelect');
  const list = accounts || [];
  if (!list.length) {
    sel.innerHTML = '<option value="">No accounts — click Connect</option>';
  } else {
    sel.innerHTML = list
      .map((a) => {
        const email = typeof a === 'string' ? a : a.email;
        return `<option value="${email}">${email}</option>`;
      })
      .join('');
    if (activeEmail) sel.value = activeEmail;
  }
  $('accountCount').textContent = `${list.length}/${max}`;
}

async function connectGmail() {
  const res = await chrome.runtime.sendMessage({
    type: 'CONNECT_GMAIL',
    forceAccountPicker: true,
  });
  if (!res?.ok || !res.account) {
    throw new Error(res?.error || 'Gmail connection failed');
  }
  return res.account;
}

async function init() {
  const config = await getConfig();
  $('apiBase').value = config.apiBase || '';
  setSwitch($('trackToggle'), config.trackingEnabled !== false);
  setSwitch($('notifToggle'), config.desktopNotifications !== false);

  const listed = await listAccounts();
  fillAccounts(listed.accounts, listed.activeEmail || config.activeEmail, listed.max);
  await loadFeed(config.apiBase);

  $('trackToggle').onclick = async () => {
    const next = !$('trackToggle').classList.contains('on');
    setSwitch($('trackToggle'), next);
    await chrome.runtime.sendMessage({ type: 'SET_TRACKING_STATE', enabled: next });
  };

  $('notifToggle').onclick = async () => {
    const next = !$('notifToggle').classList.contains('on');
    setSwitch($('notifToggle'), next);
    await chrome.runtime.sendMessage({
      type: 'SET_CONFIG',
      config: { desktopNotifications: next },
    });
  };

  $('saveBtn').onclick = async () => {
    const apiBase = $('apiBase').value.trim().replace(/\/$/, '');
    const activeEmail = $('accountSelect').value || null;
    await chrome.runtime.sendMessage({
      type: 'SET_CONFIG',
      config: {
        apiBase,
        activeEmail,
        trackingEnabled: $('trackToggle').classList.contains('on'),
        desktopNotifications: $('notifToggle').classList.contains('on'),
      },
    });
    if (activeEmail) {
      await chrome.runtime.sendMessage({ type: 'SET_ACTIVE_GMAIL', email: activeEmail });
    }
    $('saveBtn').textContent = 'Saved';
    setTimeout(() => ($('saveBtn').textContent = 'Save & sync'), 1200);
    await loadFeed(apiBase);
  };

  $('connectGmail').onclick = async () => {
    const btn = $('connectGmail');
    try {
      btn.textContent = '…';
      btn.disabled = true;
      const acc = await connectGmail();
      const listed2 = await listAccounts();
      fillAccounts(listed2.accounts, acc.email, listed2.max);
      $('detected').textContent = `Connected: ${acc.email} (${listed2.accounts.length}/${listed2.max}) · token isolated`;
      btn.textContent = 'Connected';
      setTimeout(() => {
        btn.textContent = 'Add account';
        btn.disabled = false;
      }, 1500);
    } catch (e) {
      alert(e.message || 'Connect failed');
      btn.textContent = 'Add account';
      btn.disabled = false;
    }
  };

  $('removeAccount').onclick = async () => {
    const email = $('accountSelect').value;
    if (!email) return;
    if (!confirm(`Disconnect ${email}?`)) return;
    await chrome.runtime.sendMessage({ type: 'REMOVE_GMAIL', email });
    const listed2 = await listAccounts();
    fillAccounts(listed2.accounts, listed2.activeEmail, listed2.max);
    $('detected').textContent = `Removed ${email}`;
  };

  $('openDash').onclick = async () => {
    const cfg = await getConfig();
    const url = cfg.apiBase || 'https://mail.google.com';
    chrome.tabs.create({ url });
  };

  $('pollBtn').onclick = async () => {
    await chrome.runtime.sendMessage({ type: 'POLL_NOW' });
    const cfg = await getConfig();
    await loadFeed(cfg.apiBase);
  };

  $('accountSelect').onchange = async () => {
    const email = $('accountSelect').value;
    await chrome.runtime.sendMessage({ type: 'SET_ACTIVE_GMAIL', email });
  };
}

init();
