/**
 * MailPulse MV3 service worker
 * - chrome.identity Gmail auth (no iframe / GIS)
 * - Polls tracking backend for open/click events
 * - Desktop notifications + web app bridge
 */

const POLL_ALARM = 'mailpulse-poll';
const SEEN_KEY = 'seenNotificationIds';
const CONFIG_KEY = 'mailpulseConfig';
const GMAIL_STORE_KEY = 'gmailAccounts';
const GMAIL_TOKENS_KEY = 'gmailTokens';
const MAX_GMAIL_ACCOUNTS = 10;

const GMAIL_SCOPES = [
  'openid',
  'email',
  'profile',
  'https://www.googleapis.com/auth/gmail.send',
  'https://www.googleapis.com/auth/gmail.compose',
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/userinfo.profile',
].join(' ');

async function getConfig() {
  const data = await chrome.storage.sync.get(CONFIG_KEY);
  return (
    data[CONFIG_KEY] || {
      apiBase: '',
      trackingEnabled: true,
      desktopNotifications: true,
      pollSeconds: 8,
      activeEmail: null,
      accounts: [],
    }
  );
}

async function setConfig(partial) {
  const cur = await getConfig();
  const next = { ...cur, ...partial };
  await chrome.storage.sync.set({ [CONFIG_KEY]: next });
  return next;
}

async function getSeen() {
  const data = await chrome.storage.local.get(SEEN_KEY);
  return new Set(data[SEEN_KEY] || []);
}

async function addSeen(ids) {
  const seen = await getSeen();
  ids.forEach((id) => seen.add(id));
  const arr = [...seen].slice(-300);
  await chrome.storage.local.set({ [SEEN_KEY]: arr });
}

function resolveApiBase(config) {
  if (config.apiBase) return config.apiBase.replace(/\/$/, '');
  return '';
}

function getAuthToken(interactive) {
  return new Promise((resolve, reject) => {
    try {
      chrome.identity.getAuthToken({ interactive: Boolean(interactive) }, (token) => {
        if (chrome.runtime.lastError || !token) {
          reject(new Error(chrome.runtime.lastError?.message || 'Gmail authorization failed'));
          return;
        }
        resolve(token);
      });
    } catch (e) {
      reject(e instanceof Error ? e : new Error('chrome.identity unavailable'));
    }
  });
}

function removeCachedAuthToken(token) {
  return new Promise((resolve) => {
    if (!token) {
      resolve();
      return;
    }
    try {
      chrome.identity.removeCachedAuthToken({ token }, () => resolve());
    } catch {
      resolve();
    }
  });
}

async function fetchProfile(accessToken) {
  const res = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.error_description || `Profile fetch failed (${res.status})`);
  }
  return res.json();
}

async function loadGmailStore() {
  const data = await chrome.storage.local.get([GMAIL_STORE_KEY, GMAIL_TOKENS_KEY]);
  return {
    accounts: data[GMAIL_STORE_KEY] || [],
    tokens: data[GMAIL_TOKENS_KEY] || {},
  };
}

async function saveGmailAccount(account) {
  const email = String(account.email || '')
    .toLowerCase()
    .trim();
  if (!email || !account.accessToken) {
    throw new Error('Invalid account payload');
  }

  const { accounts, tokens } = await loadGmailStore();
  const isNew = !accounts.some((a) => a.email === email);
  if (isNew && accounts.length >= MAX_GMAIL_ACCOUNTS) {
    throw new Error(
      `Account limit reached (${MAX_GMAIL_ACCOUNTS}). Remove an account before connecting another.`
    );
  }

  // Token map is keyed ONLY by email — never shared across identities
  const nextTokens = { ...tokens };
  nextTokens[email] = {
    token: account.accessToken,
    expiresAt: account.expiresAt,
    updatedAt: Date.now(),
  };

  // Drop orphan token keys not in account list (isolation hygiene)
  const nextAccounts = [
    {
      email,
      name: account.name,
      picture: account.picture || '',
      expiresAt: account.expiresAt,
      connectedAt: account.connectedAt || new Date().toISOString(),
    },
    ...accounts.filter((a) => a.email !== email),
  ].slice(0, MAX_GMAIL_ACCOUNTS);

  const allowed = new Set(nextAccounts.map((a) => a.email));
  for (const key of Object.keys(nextTokens)) {
    if (!allowed.has(key)) delete nextTokens[key];
  }

  await chrome.storage.local.set({
    [GMAIL_STORE_KEY]: nextAccounts,
    [GMAIL_TOKENS_KEY]: nextTokens,
  });

  await setConfig({
    accounts: nextAccounts,
    activeEmail: email,
    maxAccounts: MAX_GMAIL_ACCOUNTS,
  });

  return {
    ...account,
    email,
    accessToken: nextTokens[email].token,
  };
}

function parseTokenFromRedirect(url) {
  const hash = url.includes('#') ? url.split('#')[1] : '';
  const query = url.includes('?') && !url.includes('#') ? url.split('?')[1] : '';
  const params = new URLSearchParams(hash || query);
  const error = params.get('error');
  if (error) {
    throw new Error(params.get('error_description') || error);
  }
  const accessToken = params.get('access_token');
  if (!accessToken) throw new Error('No access token in OAuth response');
  const expiresIn = Number(params.get('expires_in') || 3600);
  return { accessToken, expiresIn };
}

/**
 * Multi-account OAuth via launchWebAuthFlow (account picker each time).
 * Avoids single-account lock-in of getAuthToken cache.
 * Never embeds Google UI in an iframe.
 */
function launchWebAuthFlow() {
  const manifest = chrome.runtime.getManifest();
  const clientId = manifest.oauth2?.client_id;
  if (!clientId) {
    return Promise.reject(new Error('oauth2.client_id missing in manifest'));
  }

  const redirectUri = chrome.identity.getRedirectURL();
  const params = new URLSearchParams({
    client_id: clientId,
    response_type: 'token',
    redirect_uri: redirectUri,
    scope: GMAIL_SCOPES,
    prompt: 'select_account consent',
    include_granted_scopes: 'true',
  });
  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;

  return new Promise((resolve, reject) => {
    chrome.identity.launchWebAuthFlow({ url: authUrl, interactive: true }, (responseUrl) => {
      if (chrome.runtime.lastError || !responseUrl) {
        reject(new Error(chrome.runtime.lastError?.message || 'Gmail authorization cancelled'));
        return;
      }
      try {
        resolve(parseTokenFromRedirect(responseUrl));
      } catch (e) {
        reject(e instanceof Error ? e : new Error('Failed to parse OAuth response'));
      }
    });
  });
}

/**
 * Connect Gmail — prefers launchWebAuthFlow for true multi-account (up to 10).
 * Falls back to getAuthToken if web auth flow is unavailable.
 */
async function connectGmailIdentity(options = {}) {
  const { forceAccountPicker = true } = options;
  const { accounts } = await loadGmailStore();
  if (accounts.length >= MAX_GMAIL_ACCOUNTS && forceAccountPicker) {
    // Still allow re-auth of an existing identity via picker; upsert enforces cap for new emails
  }

  let accessToken;
  let expiresIn = 3600;

  try {
    const result = await launchWebAuthFlow();
    accessToken = result.accessToken;
    expiresIn = result.expiresIn;
  } catch (webErr) {
    // Fallback: chrome.identity.getAuthToken (single Chrome profile account)
    if (forceAccountPicker) {
      try {
        const cached = await getAuthToken(false).catch(() => null);
        if (cached) await removeCachedAuthToken(cached);
      } catch {
        /* ignore */
      }
    }
    try {
      accessToken = await getAuthToken(true);
    } catch (e) {
      throw new Error(
        (webErr instanceof Error ? webErr.message : 'Auth failed') +
          ' · ' +
          (e instanceof Error ? e.message : 'getAuthToken failed')
      );
    }
  }

  const profile = await fetchProfile(accessToken);
  if (!profile?.email) {
    throw new Error('Google did not return an email for this account');
  }

  const account = {
    email: String(profile.email).toLowerCase().trim(),
    name: profile.name || profile.email.split('@')[0],
    picture: profile.picture || '',
    accessToken,
    expiresAt: Date.now() + Math.max(60, expiresIn - 60) * 1000,
    connectedAt: new Date().toISOString(),
  };

  return saveGmailAccount(account);
}

/**
 * Return token ONLY for the requested email — no cross-account leakage.
 */
async function getStoredToken(email) {
  const { tokens, accounts } = await loadGmailStore();
  const cfg = await getConfig();
  const target = (email || cfg.activeEmail || accounts[0]?.email || '').toLowerCase().trim();
  if (!target) return null;

  const entry = tokens[target];
  if (!entry?.token) return null;

  // Expired: do not return another account's token
  if (entry.expiresAt && entry.expiresAt <= Date.now() + 30_000) {
    return null;
  }

  const meta = accounts.find((a) => a.email === target) || { email: target, name: target };
  return {
    email: target,
    name: meta.name || target,
    picture: meta.picture || '',
    accessToken: entry.token,
    expiresAt: entry.expiresAt || Date.now() + 3600_000,
    connectedAt: meta.connectedAt || new Date().toISOString(),
  };
}

async function removeGmailAccount(email) {
  const target = String(email || '')
    .toLowerCase()
    .trim();
  const { accounts, tokens } = await loadGmailStore();
  const nextAccounts = accounts.filter((a) => a.email !== target);
  const nextTokens = { ...tokens };
  delete nextTokens[target];
  await chrome.storage.local.set({
    [GMAIL_STORE_KEY]: nextAccounts,
    [GMAIL_TOKENS_KEY]: nextTokens,
  });
  const cfg = await getConfig();
  const activeEmail =
    cfg.activeEmail === target ? nextAccounts[0]?.email || null : cfg.activeEmail;
  await setConfig({ accounts: nextAccounts, activeEmail });
  return { accounts: nextAccounts, activeEmail };
}

async function pollNotifications() {
  const config = await getConfig();
  if (!config.desktopNotifications) return;

  const base = resolveApiBase(config);
  if (!base) return;

  try {
    const res = await fetch(`${base}/api/extension-bridge?limit=20`, {
      headers: { 'X-MailPulse-Extension': '1' },
    });
    if (!res.ok) return;
    const data = await res.json();
    const list = data.notifications || [];
    const seen = await getSeen();
    const fresh = list.filter((n) => !seen.has(n.id));

    for (const n of fresh) {
      const title = n.desktop_title || (n.type === 'click' ? 'Link clicked' : 'Email opened');
      const message =
        n.desktop_body ||
        `${n.recipient_email || n.recipient_name || 'Recipient'} · ${n.campaign_name || 'Campaign'}`;

      await chrome.notifications.create(`mp-${n.id}`, {
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: `MailPulse · ${title}`,
        message,
        priority: 2,
        requireInteraction: true,
        contextMessage: new Date(n.created_at).toLocaleString(),
      });
    }

    if (fresh.length) {
      await addSeen(fresh.map((n) => n.id));
      const unread = data.unread || fresh.length;
      await chrome.action.setBadgeText({ text: unread > 0 ? String(Math.min(unread, 99)) : '' });
      await chrome.action.setBadgeBackgroundColor({ color: '#5b8def' });

      try {
        await fetch(`${base}/api/extension-bridge`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'ack', ids: fresh.map((n) => n.id) }),
        });
      } catch {
        /* offline ok */
      }
    }
  } catch (err) {
    console.warn('[MailPulse] poll failed', err);
  }
}

function schedulePoll(seconds = 8) {
  chrome.alarms.create(POLL_ALARM, { periodInMinutes: 1 });
  kickFastPoll(seconds);
}

let fastTimer = null;
function kickFastPoll(seconds = 8) {
  if (fastTimer) clearTimeout(fastTimer);
  const tick = async () => {
    await pollNotifications();
    fastTimer = setTimeout(tick, Math.max(4, seconds) * 1000);
  };
  tick();
}

chrome.runtime.onInstalled.addListener(async () => {
  schedulePoll(8);
  await setConfig({ trackingEnabled: true, desktopNotifications: true });
});

chrome.runtime.onStartup.addListener(() => schedulePoll(8));

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === POLL_ALARM) pollNotifications();
});

chrome.notifications.onClicked.addListener((id) => {
  chrome.notifications.clear(id);
  getConfig().then((cfg) => {
    const base = resolveApiBase(cfg);
    if (base) chrome.tabs.create({ url: `${base}/activity` });
  });
});

async function handleMessage(msg) {
  if (msg?.type === 'GET_CONFIG') {
    const config = await getConfig();
    const { accounts } = await loadGmailStore();
    return { ok: true, config: { ...config, accounts: accounts.length ? accounts : config.accounts } };
  }

  if (msg?.type === 'SET_CONFIG') {
    const config = await setConfig(msg.config || {});
    if (msg.config?.pollSeconds) kickFastPoll(msg.config.pollSeconds);
    return { ok: true, config };
  }

  if (msg?.type === 'POLL_NOW') {
    await pollNotifications();
    return { ok: true };
  }

  if (msg?.type === 'GET_TRACKING_STATE') {
    const config = await getConfig();
    return { ok: true, trackingEnabled: config.trackingEnabled !== false };
  }

  if (msg?.type === 'SET_TRACKING_STATE') {
    const config = await setConfig({ trackingEnabled: Boolean(msg.enabled) });
    const tabs = await chrome.tabs.query({ url: 'https://mail.google.com/*' });
    for (const t of tabs) {
      if (t.id) {
        chrome.tabs
          .sendMessage(t.id, { type: 'TRACKING_STATE', enabled: config.trackingEnabled })
          .catch(() => {});
      }
    }
    return { ok: true, trackingEnabled: config.trackingEnabled };
  }

  if (msg?.type === 'CONNECT_GMAIL') {
    try {
      const account = await connectGmailIdentity({
        forceAccountPicker: msg.forceAccountPicker !== false,
      });
      return { ok: true, account, maxAccounts: MAX_GMAIL_ACCOUNTS };
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : 'Connect failed' };
    }
  }

  if (msg?.type === 'REMOVE_GMAIL') {
    try {
      const result = await removeGmailAccount(msg.email);
      return { ok: true, ...result, maxAccounts: MAX_GMAIL_ACCOUNTS };
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : 'Remove failed' };
    }
  }

  if (msg?.type === 'LIST_GMAIL') {
    const { accounts } = await loadGmailStore();
    const cfg = await getConfig();
    return {
      ok: true,
      accounts,
      activeEmail: cfg.activeEmail,
      maxAccounts: MAX_GMAIL_ACCOUNTS,
    };
  }

  if (msg?.type === 'SET_ACTIVE_GMAIL') {
    const email = String(msg.email || '')
      .toLowerCase()
      .trim();
    const { accounts } = await loadGmailStore();
    if (email && !accounts.some((a) => a.email === email)) {
      return { ok: false, error: 'Account not connected' };
    }
    await setConfig({ activeEmail: email || null });
    return { ok: true, activeEmail: email || null };
  }

  if (msg?.type === 'GET_GMAIL_TOKEN') {
    try {
      // Strict: only the requested email's token (no silent swap to another account)
      let account = await getStoredToken(msg.email);
      if (!account && msg.interactive) {
        account = await connectGmailIdentity({ forceAccountPicker: true });
        if (msg.email && account.email !== String(msg.email).toLowerCase()) {
          // User picked a different account — store it, but report clearly
          return {
            ok: true,
            account,
            token: account.accessToken,
            note: 'Connected a different account than requested',
          };
        }
      }
      if (!account) {
        return { ok: false, error: 'No token for selected account — reconnect it' };
      }
      return { ok: true, account, token: account.accessToken };
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : 'Token unavailable' };
    }
  }

  if (msg?.type === 'PREPARE_TRACKING') {
    const config = await getConfig();
    const base = resolveApiBase(config);
    if (!base) return { ok: false, error: 'Set API base URL in extension popup' };
    const res = await fetch(`${base}/api/track-prepare`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...msg.payload, base_url: base }),
    });
    const data = await res.json();
    return { ok: res.ok, ...data };
  }

  if (msg?.type === 'GMAIL_SEND') {
    const config = await getConfig();
    const base = resolveApiBase(config);
    if (!base) return { ok: false, error: 'Set API base URL in extension popup' };

    let accessToken = msg.payload?.access_token;
    if (!accessToken) {
      const account = await getStoredToken(msg.payload?.from_email || config.activeEmail);
      if (!account) return { ok: false, error: 'Connect Gmail first' };
      accessToken = account.accessToken;
      msg.payload = {
        ...msg.payload,
        access_token: accessToken,
        from_email: msg.payload?.from_email || account.email,
        from_name: msg.payload?.from_name || account.name,
      };
    }

    const res = await fetch(`${base}/api/gmail-send`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...msg.payload, base_url: base }),
    });
    const data = await res.json();
    return { ok: res.ok, ...data };
  }

  if (msg?.type === 'DESKTOP_NOTIFY') {
    await chrome.notifications.create(`mp-manual-${Date.now()}`, {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: msg.title || 'MailPulse',
      message: msg.message || '',
      priority: 2,
      requireInteraction: true,
    });
    return { ok: true };
  }

  return { ok: false, error: 'unknown message' };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  handleMessage(msg)
    .then(sendResponse)
    .catch((e) => sendResponse({ ok: false, error: e.message || 'error' }));
  return true;
});

// External messages from MailPulse web dashboard
chrome.runtime.onMessageExternal.addListener((msg, _sender, sendResponse) => {
  (async () => {
    if (msg?.type === 'SYNC_CONFIG') {
      const config = await setConfig({
        apiBase: msg.apiBase || msg.origin,
        accounts: msg.accounts || undefined,
        activeEmail: msg.activeEmail || null,
        desktopNotifications: msg.desktopNotifications !== false,
        trackingEnabled: msg.trackingEnabled !== false,
      });
      kickFastPoll(6);
      sendResponse({ ok: true, config, extensionId: chrome.runtime.id });
      return;
    }
    if (msg?.type === 'CONNECT_GMAIL') {
      try {
        const account = await connectGmailIdentity({
          forceAccountPicker: msg.forceAccountPicker !== false,
        });
        sendResponse({ ok: true, account, extensionId: chrome.runtime.id });
      } catch (e) {
        sendResponse({ ok: false, error: e instanceof Error ? e.message : 'Connect failed' });
      }
      return;
    }
    if (msg?.type === 'GET_GMAIL_TOKEN') {
      try {
        const account = await getStoredToken(msg.email);
        if (!account) {
          sendResponse({ ok: false, error: 'No stored Gmail token' });
          return;
        }
        sendResponse({ ok: true, account, token: account.accessToken });
      } catch (e) {
        sendResponse({ ok: false, error: e instanceof Error ? e.message : 'Token error' });
      }
      return;
    }
    if (msg?.type === 'PING') {
      sendResponse({
        ok: true,
        extensionId: chrome.runtime.id,
        version: chrome.runtime.getManifest().version,
      });
      return;
    }
    sendResponse({ ok: false });
  })();
  return true;
});

chrome.tabs.onActivated.addListener(async () => {
  kickFastPoll(8);
});

schedulePoll(8);
console.log('[MailPulse] background ready (chrome.identity auth)');
