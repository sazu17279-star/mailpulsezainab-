# MailPulse Chrome Extension (MV3) v1.3

## Files
- `manifest.json` — Manifest V3
- `background.js` — service worker (desktop alerts, multi-account auth, bridge)
- `content.js` + `content.css` — Gmail compose toolbar (tracking toggle + sender switcher)
- `popup.html` / `popup.js` / `popup.css` — extension popup
- `icons/` — 16 / 48 / 128

## Load unpacked
1. `chrome://extensions` → Developer mode ON  
2. **Load unpacked** → select this folder  
3. Popup → set dashboard URL → **Save & sync**  
4. **Add account** (up to 10 Gmail accounts)  
5. Open Gmail Compose → MailPulse bar appears  

## Auth (no iframe)
Uses `chrome.identity.launchWebAuthFlow` / `getAuthToken` only.  
Tokens stored per-email in `chrome.storage.local` (`gmailTokens`, `gmailAccounts`).

## OAuth client
Google Cloud → OAuth client type **Chrome Extension** → item ID = your Extension ID.
