/**
 * Injects MailPulse tracking toggle + multi-account sender switcher into Gmail compose.
 * Zero-watermark pixel injection on send when tracking is enabled.
 */
(function () {
  const ROOT_ATTR = 'data-mailpulse-bar';
  let trackingEnabled = true;
  let lastAccounts = [];
  let connectedAccounts = [];
  let activeSender = '';

  function loadConnectedAccounts() {
    chrome.runtime.sendMessage({ type: 'LIST_GMAIL' }, (res) => {
      if (res?.ok) {
        connectedAccounts = res.accounts || [];
        activeSender = res.activeEmail || connectedAccounts[0]?.email || '';
        paintAll();
      }
    });
  }

  chrome.runtime.sendMessage({ type: 'GET_TRACKING_STATE' }, (res) => {
    if (res?.ok) trackingEnabled = res.trackingEnabled !== false;
    loadConnectedAccounts();
    paintAll();
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'TRACKING_STATE') {
      trackingEnabled = Boolean(msg.enabled);
      paintAll();
    }
  });

  function detectGmailAccounts() {
    const emails = new Set();
    // Account switcher / avatar menu
    document.querySelectorAll('[data-email]').forEach((el) => {
      const e = el.getAttribute('data-email');
      if (e && e.includes('@')) emails.add(e.toLowerCase());
    });
    document.querySelectorAll('a[aria-label*="@"]').forEach((a) => {
      const m = (a.getAttribute('aria-label') || '').match(/[\w.+-]+@[\w.-]+\.[a-z]{2,}/i);
      if (m) emails.add(m[0].toLowerCase());
    });
    // Title / profile node
    const profile = document.querySelector('a[href*="SignOutOptions"], a[aria-label*="Google Account"]');
    if (profile) {
      const m = (profile.getAttribute('aria-label') || profile.textContent || '').match(
        /[\w.+-]+@[\w.-]+\.[a-z]{2,}/i
      );
      if (m) emails.add(m[0].toLowerCase());
    }
    lastAccounts = [...emails];
    return lastAccounts;
  }

  function findComposeWindows() {
    // Gmail compose dialogs
    const nodes = [
      ...document.querySelectorAll('div[role="dialog"]'),
      ...document.querySelectorAll('.nH.Hd'),
      ...document.querySelectorAll('.AD'),
    ];
    return nodes.filter((n) => {
      if (n.querySelector(`[${ROOT_ATTR}]`)) return true;
      // has To field + body
      const hasBody = n.querySelector('[aria-label="Message Body"], div[contenteditable="true"][role="textbox"], div[g_editable="true"]');
      const hasTo = n.querySelector('textarea[name="to"], input[peoplekit-id], div[aria-label*="To"]');
      return Boolean(hasBody && (hasTo || n.querySelector('[name="subjectbox"]')));
    });
  }

  function getComposeMeta(win) {
    const subjectEl = win.querySelector('input[name="subjectbox"]');
    const subject = subjectEl ? subjectEl.value : '';

    let to = '';
    const toInput = win.querySelector('textarea[name="to"]');
    if (toInput) to = toInput.value;
    if (!to) {
      const chips = [...win.querySelectorAll('[data-hovercard-id], [email], span[email]')]
        .map((el) => el.getAttribute('email') || el.getAttribute('data-hovercard-id') || '')
        .filter((e) => e.includes('@'));
      to = chips[0] || '';
    }
    if (!to) {
      const aria = win.querySelector('[aria-label^="To"]');
      const m = (aria?.textContent || '').match(/[\w.+-]+@[\w.-]+\.[a-z]{2,}/i);
      if (m) to = m[0];
    }

    const bodyEl =
      win.querySelector('div[aria-label="Message Body"]') ||
      win.querySelector('div[contenteditable="true"][role="textbox"]') ||
      win.querySelector('div[g_editable="true"]');

    return { subject, to, bodyEl, subjectEl };
  }

  function ensureBar(win) {
    let bar = win.querySelector(`[${ROOT_ATTR}]`);
    if (bar) return bar;

    const toolbar =
      win.querySelector('.btC') ||
      win.querySelector('table.iN') ||
      win.querySelector('[role="dialog"] .gU') ||
      win.querySelector('.aDh') ||
      null;

    bar = document.createElement('div');
    bar.setAttribute(ROOT_ATTR, '1');
    bar.className = 'mp-track-bar';
    bar.innerHTML = `
      <div class="mp-track-inner">
        <span class="mp-logo">MP</span>
        <span class="mp-label">MailPulse</span>
        <label class="mp-sender-wrap" title="Campaign / compose sender (up to 10)">
          <span class="mp-sender-lbl">From</span>
          <select class="mp-sender" aria-label="Select Gmail sender"></select>
        </label>
        <button type="button" class="mp-toggle" aria-pressed="true">
          <span class="mp-knob"></span>
          <span class="mp-toggle-text">Tracking on</span>
        </button>
        <span class="mp-meta">Zero watermark</span>
        <button type="button" class="mp-inject" title="Inject invisible open pixel">Inject pixel</button>
      </div>
    `;

    if (toolbar && toolbar.parentElement) {
      toolbar.parentElement.insertBefore(bar, toolbar);
    } else {
      win.insertBefore(bar, win.firstChild);
    }

    const toggle = bar.querySelector('.mp-toggle');
    const injectBtn = bar.querySelector('.mp-inject');
    const senderSel = bar.querySelector('.mp-sender');

    const syncToggleUi = () => {
      toggle.setAttribute('aria-pressed', trackingEnabled ? 'true' : 'false');
      toggle.classList.toggle('off', !trackingEnabled);
      toggle.querySelector('.mp-toggle-text').textContent = trackingEnabled ? 'Tracking on' : 'Tracking off';
    };
    syncToggleUi();
    fillSenderSelect(senderSel);

    toggle.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      trackingEnabled = !trackingEnabled;
      chrome.runtime.sendMessage({ type: 'SET_TRACKING_STATE', enabled: trackingEnabled });
      syncToggleUi();
    });

    senderSel.addEventListener('change', (e) => {
      e.stopPropagation();
      activeSender = senderSel.value;
      chrome.runtime.sendMessage({ type: 'SET_ACTIVE_GMAIL', email: activeSender });
    });
    // Prevent Gmail from stealing focus/keys
    senderSel.addEventListener('mousedown', (e) => e.stopPropagation());
    senderSel.addEventListener('click', (e) => e.stopPropagation());

    injectBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      await injectTracking(win, true);
    });

    // Hook Send buttons
    hookSendButtons(win);

    return bar;
  }

  function fillSenderSelect(sel) {
    if (!sel) return;
    const opts = connectedAccounts.length
      ? connectedAccounts
      : lastAccounts.map((email) => ({ email }));
    if (!opts.length) {
      sel.innerHTML = '<option value="">Connect in extension</option>';
      return;
    }
    sel.innerHTML = opts
      .map((a) => {
        const email = a.email || a;
        const selected = email === activeSender ? ' selected' : '';
        return `<option value="${email}"${selected}>${email}</option>`;
      })
      .join('');
    if (activeSender) sel.value = activeSender;
  }

  function hookSendButtons(win) {
    if (win.dataset.mpSendHooked) return;
    win.dataset.mpSendHooked = '1';

    win.addEventListener(
      'click',
      async (e) => {
        const btn = e.target.closest('[role="button"], button');
        if (!btn) return;
        const label = (btn.getAttribute('aria-label') || btn.dataset.tooltip || btn.textContent || '').toLowerCase();
        const isSend =
          label.includes('send') &&
          !label.includes('send later') &&
          !label.includes('schedule');
        if (!isSend) return;
        if (!trackingEnabled) return;

        // Inject before Gmail processes send
        try {
          await injectTracking(win, false);
        } catch (err) {
          console.warn('[MailPulse] inject failed', err);
        }
      },
      true
    );
  }

  function rewriteLinks(bodyEl, wrapFn) {
    const anchors = bodyEl.querySelectorAll('a[href]');
    anchors.forEach((a) => {
      const href = a.getAttribute('href');
      if (!href || !/^https?:/i.test(href)) return;
      if (href.includes('/api/track-click')) return;
      a.setAttribute('href', wrapFn(href));
      a.setAttribute('data-mp-tracked', '1');
    });
  }

  async function injectTracking(win, manual) {
    if (!trackingEnabled && !manual) return;

    const { subject, to, bodyEl } = getComposeMeta(win);
    if (!bodyEl) {
      flash(win, 'Compose body not found');
      return;
    }

    // Avoid double pixel
    if (bodyEl.querySelector('img[src*="/api/track-open"]')) {
      if (manual) flash(win, 'Tracking already injected');
      return;
    }

    const emailMatch = (to || '').match(/[\w.+-]+@[\w.-]+\.[a-z]{2,}/i);
    const email = emailMatch ? emailMatch[0] : '';
    if (!email) {
      flash(win, 'Add a recipient first');
      return;
    }

    const payload = {
      email,
      name: email.split('@')[0],
      subject: subject || 'Gmail message',
      body: bodyEl.innerText || '',
      campaign_name: `Gmail · ${subject || email}`,
    };

    const res = await chrome.runtime.sendMessage({ type: 'PREPARE_TRACKING', payload });
    if (!res?.ok) {
      flash(win, res?.error || 'Tracking prepare failed — set dashboard URL in popup');
      return;
    }

    // Inject invisible pixel at end of body — NO watermark / footer / branding
    const holder = document.createElement('div');
    holder.style.cssText = 'display:none;line-height:0;height:0;overflow:hidden;';
    holder.setAttribute('data-mp-pixel', res.tracking_token);
    holder.innerHTML = res.pixel_html;
    bodyEl.appendChild(holder);

    const base = res.open_url.split('/api/track-open')[0];
    rewriteLinks(bodyEl, (url) => `${base}/api/track-click?t=${res.tracking_token}&u=${encodeURIComponent(url)}`);

    flash(win, 'Invisible tracking enabled');

    // Mark recipient as sent shortly after (Gmail will send the message)
    setTimeout(() => {
      chrome.runtime.sendMessage({
        type: 'DESKTOP_NOTIFY',
        title: 'Tracking armed',
        message: `Watching opens for ${email}`,
      });
    }, 400);
  }

  function flash(win, text) {
    const bar = win.querySelector(`[${ROOT_ATTR}]`);
    if (!bar) return;
    let tip = bar.querySelector('.mp-flash');
    if (!tip) {
      tip = document.createElement('span');
      tip.className = 'mp-flash';
      bar.querySelector('.mp-track-inner')?.appendChild(tip);
    }
    tip.textContent = text;
    tip.classList.add('show');
    setTimeout(() => tip.classList.remove('show'), 2200);
  }

  function paintAll() {
    detectGmailAccounts();
    const wins = findComposeWindows();
    wins.forEach((w) => {
      const bar = ensureBar(w);
      const toggle = bar.querySelector('.mp-toggle');
      if (toggle) {
        toggle.setAttribute('aria-pressed', trackingEnabled ? 'true' : 'false');
        toggle.classList.toggle('off', !trackingEnabled);
        const t = toggle.querySelector('.mp-toggle-text');
        if (t) t.textContent = trackingEnabled ? 'Tracking on' : 'Tracking off';
      }
      fillSenderSelect(bar.querySelector('.mp-sender'));
    });
  }

  const obs = new MutationObserver(() => {
    paintAll();
  });
  obs.observe(document.documentElement, { childList: true, subtree: true });

  setInterval(() => {
    detectGmailAccounts();
    paintAll();
  }, 2000);

  // Expose accounts for popup via runtime
  chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
    if (msg?.type === 'DETECT_GMAIL_ACCOUNTS') {
      sendResponse({ ok: true, accounts: detectGmailAccounts() });
      return true;
    }
  });

  console.log('[MailPulse] Gmail content script ready');
})();
