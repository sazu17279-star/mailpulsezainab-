/**
 * Edge middleware — HTTPS upgrade only.
 * Do NOT set X-Frame-Options here (breaks Design Arena / preview iframes).
 */
export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|assets/).*)'],
};

export default function middleware(request) {
  try {
    const url = new URL(request.url);
    const host = request.headers.get('host') || url.host;
    const proto =
      request.headers.get('x-forwarded-proto') ||
      request.headers.get('x-forwarded-protocol') ||
      url.protocol.replace(':', '');

    if (
      proto === 'http' &&
      host &&
      !host.startsWith('localhost') &&
      !host.startsWith('127.0.0.1')
    ) {
      return Response.redirect(`https://${host}${url.pathname}${url.search}`, 308);
    }
  } catch {
    /* pass through */
  }
  return;
}
