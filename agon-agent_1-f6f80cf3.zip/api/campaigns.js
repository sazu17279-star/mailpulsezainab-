import supabase, { isDbConfigured } from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'Content-Type, Authorization, X-MailPulse-Extension, X-Requested-With'
  );
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      if (!isDbConfigured || supabase.__fallback) {
        return res.status(200).json(req.query.id ? null : []);
      }
      const { id } = req.query;
      if (id) {
        const { data, error } = await supabase
          .from('mp_campaigns')
          .select('*')
          .eq('id', id)
          .maybeSingle();
        if (error) {
          console.error('campaigns get one:', error.message);
          return res.status(200).json(null);
        }
        return res.status(200).json(data);
      }
      const { data, error } = await supabase
        .from('mp_campaigns')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) {
        console.error('campaigns list:', error.message);
        return res.status(200).json([]);
      }
      return res.status(200).json(data || []);
    }

    if (req.method === 'POST') {
      const {
        name,
        subject,
        body,
        status = 'draft',
        schedule_at = null,
        timezone = 'UTC',
        throttle_ms = 10000,
        target_send_hour = 9,
      } = req.body || {};

      if (!name || !subject || !body) {
        return res.status(400).json({ error: 'name, subject, and body are required' });
      }

      const { data, error } = await supabase
        .from('mp_campaigns')
        .insert({
          name,
          subject,
          body,
          status,
          schedule_at,
          timezone,
          throttle_ms,
          target_send_hour,
        })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, ...updates } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });

      const allowed = [
        'name',
        'subject',
        'body',
        'status',
        'schedule_at',
        'timezone',
        'throttle_ms',
        'target_send_hour',
        'sent_count',
        'open_count',
        'click_count',
      ];
      const payload = {};
      for (const key of allowed) {
        if (updates[key] !== undefined) payload[key] = updates[key];
      }
      payload.updated_at = new Date().toISOString();

      const { data, error } = await supabase
        .from('mp_campaigns')
        .update(payload)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });

      await supabase.from('mp_tracking_events').delete().eq('campaign_id', id);
      await supabase.from('mp_notifications').delete().eq('campaign_id', id);
      await supabase.from('mp_recipients').delete().eq('campaign_id', id);
      const { error } = await supabase.from('mp_campaigns').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('campaigns API error:', err);
    if (req.method === 'GET') {
      return res.status(200).json(req.query?.id ? null : []);
    }
    if (!res.headersSent) {
      return res.status(500).json({ error: err?.message || 'Campaigns error', ok: false });
    }
  }
}
