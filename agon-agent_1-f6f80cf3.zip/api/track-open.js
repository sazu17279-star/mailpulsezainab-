import supabase, { isDbConfigured } from './db-client.js';
import { handleOptions, PIXEL_GIF } from './_http.js';

function sendPixel(res) {
  if (res.headersSent) return;
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Content-Type', 'image/gif');
  res.setHeader('Content-Length', PIXEL_GIF.length);
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  return res.status(200).end(PIXEL_GIF);
}

export default async function handler(req, res) {
  // Always CORS first
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  // Always return pixel — tracking side-effects must never drop the response
  try {
    const t = req.query?.t;
    if (t && isDbConfigured && !supabase.__fallback) {
      const { data: recipient } = await supabase
        .from('mp_recipients')
        .select('*')
        .eq('tracking_token', t)
        .maybeSingle();

      if (recipient) {
        const now = new Date().toISOString();
        const openCount = (recipient.open_count || 0) + 1;
        const nextStatus = recipient.status === 'clicked' ? 'clicked' : 'opened';

        await supabase
          .from('mp_recipients')
          .update({
            open_count: openCount,
            last_opened_at: now,
            status: nextStatus,
          })
          .eq('id', recipient.id);

        await supabase.from('mp_tracking_events').insert({
          campaign_id: recipient.campaign_id,
          recipient_id: recipient.id,
          event_type: 'open',
          user_agent: req.headers['user-agent'] || '',
          ip: (req.headers['x-forwarded-for'] || '').toString().split(',')[0] || '',
          meta: JSON.stringify({ view: openCount }),
        });

        const { data: camp } = await supabase
          .from('mp_campaigns')
          .select('open_count')
          .eq('id', recipient.campaign_id)
          .maybeSingle();
        if (camp) {
          await supabase
            .from('mp_campaigns')
            .update({ open_count: (camp.open_count || 0) + 1 })
            .eq('id', recipient.campaign_id);
        }

        await supabase.from('mp_notifications').insert({
          campaign_id: recipient.campaign_id,
          recipient_id: recipient.id,
          type: 'open',
          message: `${recipient.name || recipient.email} opened your email`,
          read: false,
        });
      }
    }
  } catch (err) {
    console.error('track-open error:', err);
  }

  return sendPixel(res);
}
