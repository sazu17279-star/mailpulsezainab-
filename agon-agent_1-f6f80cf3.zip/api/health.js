import { isDbConfigured } from './db-client.js';

/**
 * Lightweight health check — never depends on DB connectivity for 200.
 */
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') return res.status(204).end();

  return res.status(200).json({
    ok: true,
    service: 'mailpulse',
    time: new Date().toISOString(),
    db_configured: isDbConfigured,
    uptime_s: Math.round(process.uptime?.() || 0),
  });
}
