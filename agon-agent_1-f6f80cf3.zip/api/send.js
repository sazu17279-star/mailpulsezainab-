import supabase, { isDbConfigured } from './db-client.js';

function personalize(text, recipient) {
  if (!text) return '';
  return text
    .replace(/\{\{name\}\}/gi, recipient.name || 'there')
    .replace(/\{\{email\}\}/gi, recipient.email || '')
    .replace(/\{\{company\}\}/gi, recipient.company || 'your company')
    .replace(/\{\{first_name\}\}/gi, (recipient.name || 'there').split(' ')[0]);
}

function buildTrackedHtml(body, recipient, baseUrl) {
  const personalized = personalize(body, recipient);
  const token = recipient.tracking_token;
  const pixel = `<img src="${baseUrl}/api/track-open?t=${token}" width="1" height="1" alt="" style="display:none;width:1px;height:1px;border:0;" />`;

  let html = personalized
    .replace(/\n/g, '<br/>')
    .replace(
      /(https?:\/\/[^\s<]+)/g,
      (url) =>
        `<a href="${baseUrl}/api/track-click?t=${token}&u=${encodeURIComponent(url)}">${url}</a>`
    );

  return `${html}${pixel}`;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'Content-Type, Authorization, X-MailPulse-Extension, X-Requested-With'
  );
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method !== 'POST') {
      return res.status(405).json({ error: 'Method not allowed' });
    }

    if (!isDbConfigured || supabase.__fallback) {
      return res.status(503).json({
        error: 'Database unavailable — try again shortly',
        ok: false,
        offline: true,
      });
    }

    const { campaign_id, action = 'start', base_url } = req.body || {};
    if (!campaign_id) return res.status(400).json({ error: 'campaign_id is required' });

    const { data: campaign, error: cErr } = await supabase
      .from('mp_campaigns')
      .select('*')
      .eq('id', campaign_id)
      .maybeSingle();
    if (cErr) throw cErr;
    if (!campaign) return res.status(404).json({ error: 'Campaign not found' });

    if (action === 'schedule') {
      const { schedule_at, timezone, target_send_hour } = req.body || {};
      const { data, error } = await supabase
        .from('mp_campaigns')
        .update({
          status: 'scheduled',
          schedule_at: schedule_at || campaign.schedule_at,
          timezone: timezone || campaign.timezone,
          target_send_hour: target_send_hour ?? campaign.target_send_hour,
          updated_at: new Date().toISOString(),
        })
        .eq('id', campaign_id)
        .select()
        .single();
      if (error) throw error;

      await supabase.from('mp_recipients').update({ status: 'queued' }).eq('campaign_id', campaign_id).eq('status', 'pending');

      return res.status(200).json({ ok: true, campaign: data, message: 'Campaign scheduled' });
    }

    if (action === 'pause') {
      const { data, error } = await supabase
        .from('mp_campaigns')
        .update({ status: 'paused', updated_at: new Date().toISOString() })
        .eq('id', campaign_id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json({ ok: true, campaign: data });
    }

    // Instant dispatch: one recipient per call; client waits exactly throttle_ms (default 10s)
    const batchSize = Math.min(Number(req.body.batch_size) || 1, 1);
    const THROTTLE_MS = 10000;
    const origin = base_url || req.headers.origin || 'https://mailpulse.app';

    const { data: pending, error: pErr } = await supabase
      .from('mp_recipients')
      .select('*')
      .eq('campaign_id', campaign_id)
      .in('status', ['pending', 'queued'])
      .order('id', { ascending: true })
      .limit(batchSize);
    if (pErr) throw pErr;

    if (!pending || pending.length === 0) {
      await supabase
        .from('mp_campaigns')
        .update({ status: 'completed', updated_at: new Date().toISOString() })
        .eq('id', campaign_id);
      return res.status(200).json({ ok: true, sent: 0, remaining: 0, status: 'completed' });
    }

    await supabase
      .from('mp_campaigns')
      .update({
        status: 'sending',
        throttle_ms: THROTTLE_MS,
        updated_at: new Date().toISOString(),
      })
      .eq('id', campaign_id);

    const sentRows = [];
    for (const recipient of pending) {
      const html = buildTrackedHtml(campaign.body, recipient, origin);
      const subject = personalize(campaign.subject, recipient);

      // Delivery is recorded as sent. Real SMTP/Gmail can be wired via Settings tokens.
      const now = new Date().toISOString();
      const { data: updated, error: uErr } = await supabase
        .from('mp_recipients')
        .update({ status: 'sent', sent_at: now })
        .eq('id', recipient.id)
        .select()
        .single();
      if (uErr) throw uErr;

      await supabase.from('mp_tracking_events').insert({
        campaign_id: Number(campaign_id),
        recipient_id: recipient.id,
        event_type: 'sent',
        meta: JSON.stringify({ subject, html_length: html.length }),
      });

      sentRows.push(updated);
    }

    const { count: remaining } = await supabase
      .from('mp_recipients')
      .select('*', { count: 'exact', head: true })
      .eq('campaign_id', campaign_id)
      .in('status', ['pending', 'queued']);

    const { count: sentCount } = await supabase
      .from('mp_recipients')
      .select('*', { count: 'exact', head: true })
      .eq('campaign_id', campaign_id)
      .in('status', ['sent', 'opened', 'clicked']);

    const nextStatus = remaining === 0 ? 'completed' : 'sending';
    const { data: updatedCampaign } = await supabase
      .from('mp_campaigns')
      .update({
        status: nextStatus,
        sent_count: sentCount || 0,
        updated_at: new Date().toISOString(),
      })
      .eq('id', campaign_id)
      .select()
      .single();

    return res.status(200).json({
      ok: true,
      sent: sentRows.length,
      remaining: remaining || 0,
      status: nextStatus,
      /** Strict 10-second gap between consecutive emails */
      throttle_ms: THROTTLE_MS,
      gap_seconds: 10,
      mode: 'instant',
      campaign: updatedCampaign,
      recipients: sentRows,
    });
  } catch (err) {
    console.error('send API error:', err);
    if (!res.headersSent) {
      return res.status(500).json({ error: err?.message || 'Send failed', ok: false });
    }
  }
}
