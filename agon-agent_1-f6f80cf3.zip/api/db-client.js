import { createClient } from '@supabase/supabase-js';
import { triggerRestore } from './db-wake.js';

const url = (process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.VITE_SUPABASE_URL || '').trim();
const key = (
  process.env.SUPABASE_SERVICE_ROLE_KEY ||
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  process.env.VITE_SUPABASE_ANON_KEY ||
  ''
).trim();

export const isDbConfigured = Boolean(url && key && /^https?:\/\//i.test(url));

/**
 * Minimal chainable stub so handlers never crash when env is missing.
 * Mimics supabase-js thenable query builder enough for our routes.
 */
function createFallbackClient(reason = 'Database not configured') {
  const result = (data = null) =>
    Promise.resolve({
      data,
      error: null,
      count: Array.isArray(data) ? data.length : data == null ? 0 : 1,
      status: 200,
      statusText: 'OK',
    });

  const emptyList = () => result([]);
  const emptyOne = () => result(null);

  const builder = {
    select() {
      return builder;
    },
    insert() {
      return builder;
    },
    update() {
      return builder;
    },
    delete() {
      return builder;
    },
    upsert() {
      return builder;
    },
    eq() {
      return builder;
    },
    neq() {
      return builder;
    },
    gt() {
      return builder;
    },
    gte() {
      return builder;
    },
    lt() {
      return builder;
    },
    lte() {
      return builder;
    },
    like() {
      return builder;
    },
    ilike() {
      return builder;
    },
    is() {
      return builder;
    },
    in() {
      return builder;
    },
    order() {
      return builder;
    },
    limit() {
      return builder;
    },
    range() {
      return builder;
    },
    single() {
      return emptyOne();
    },
    maybeSingle() {
      return emptyOne();
    },
    then(resolve, reject) {
      return emptyList().then(resolve, reject);
    },
    catch(reject) {
      return emptyList().catch(reject);
    },
  };

  return {
    __fallback: true,
    __reason: reason,
    from() {
      return builder;
    },
    auth: {
      getUser: async () => ({ data: { user: null }, error: { message: reason } }),
    },
    storage: {
      from() {
        return {
          upload: async () => ({ data: null, error: { message: reason } }),
          getPublicUrl: () => ({ data: { publicUrl: '' } }),
        };
      },
    },
  };
}

let supabase;

if (isDbConfigured) {
  try {
    supabase = createClient(url, key, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: {
        fetch: async (input, options) => {
          try {
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 12_000);
            const res = await fetch(input, {
              ...options,
              signal: options?.signal || controller.signal,
            });
            clearTimeout(timeout);
            if (!res.ok && res.status >= 500) {
              try {
                triggerRestore();
              } catch {
                /* ignore */
              }
            }
            return res;
          } catch (err) {
            try {
              triggerRestore();
            } catch {
              /* ignore */
            }
            // Return a synthetic Response so callers get a soft error instead of socket drop
            return new Response(
              JSON.stringify({
                message: err?.message || 'Upstream database connection failed',
                code: 'CONNECTION_ERROR',
              }),
              {
                status: 503,
                headers: { 'Content-Type': 'application/json' },
              }
            );
          }
        },
      },
    });
  } catch (err) {
    console.error('[db-client] Failed to init Supabase:', err?.message || err);
    supabase = createFallbackClient(err?.message || 'Supabase init failed');
  }
} else {
  console.warn(
    '[db-client] Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY — using zero-state fallback'
  );
  supabase = createFallbackClient('Database environment variables are not configured');
}

export default supabase;

/** Helper: never throw — returns { data, error, offline } */
export async function safeQuery(promiseFactory) {
  if (!isDbConfigured || supabase.__fallback) {
    return { data: null, error: null, offline: true };
  }
  try {
    const out = await promiseFactory(supabase);
    return { data: out?.data ?? null, error: out?.error ?? null, offline: false };
  } catch (err) {
    console.error('[db-client] query error:', err?.message || err);
    return { data: null, error: err, offline: true };
  }
}
