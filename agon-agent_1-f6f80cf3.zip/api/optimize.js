export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method !== 'POST') {
      return res.status(405).json({ error: 'Method not allowed' });
    }

    const {
      text = '',
      business_type = 'general',
      goal = 'proposal',
      tone = 'professional',
    } = req.body || {};

    if (!text || text.trim().length < 10) {
      return res.status(400).json({ error: 'Please provide at least a short draft (10+ characters)' });
    }

    const cleaned = text
      .replace(/\r\n/g, '\n')
      .replace(/[ \t]+/g, ' ')
      .replace(/\n{3,}/g, '\n\n')
      .trim();

    const spamWords = [
      'free money',
      'act now',
      'limited time',
      '!!!',
      'click here now',
      'guarantee',
      'no obligation',
      'winner',
      'congratulations you',
      'cash bonus',
    ];
    const foundSpam = spamWords.filter((w) => cleaned.toLowerCase().includes(w));

    const bizHooks = {
      saas: 'scalable growth and product-led outcomes',
      agency: 'measurable pipeline and brand lift',
      consulting: 'clear ROI and executive-ready recommendations',
      ecommerce: 'conversion rate and average order value',
      startup: 'traction, speed-to-value, and lean execution',
      enterprise: 'risk reduction, compliance, and stakeholder alignment',
      general: 'tangible business outcomes',
    };

    const hook = bizHooks[business_type] || bizHooks.general;
    const firstNameToken = '{{first_name}}';
    const companyToken = '{{company}}';

    const openers = {
      professional: `Hi ${firstNameToken},\n\nI reviewed how ${companyToken} approaches ${hook}, and saw a clear opportunity to improve results without adding operational noise.`,
      friendly: `Hi ${firstNameToken},\n\nHope you're doing well. I've been looking at how teams like ${companyToken} unlock ${hook}, and wanted to share a concise idea.`,
      direct: `${firstNameToken} — quick note on improving ${hook} at ${companyToken}.`,
    };

    const closer = {
      proposal:
        'If useful, I can send a short one-page plan tailored to your current priorities. Would a 15-minute call this week work?',
      followup:
        'Happy to share a brief teardown with concrete next steps — does later this week work for a quick sync?',
      intro:
        'Open to a short intro call if this direction is relevant. Either way, wishing you strong results this quarter.',
    }[goal] || 'Would you be open to a brief conversation this week?';

    // Extract value lines from original draft
    const sentences = cleaned
      .split(/(?<=[.!?])\s+/)
      .map((s) => s.trim())
      .filter((s) => s.length > 20)
      .slice(0, 5);

    const bodyCore =
      sentences.length > 0
        ? sentences
            .map((s) => {
              let line = s.replace(/^(hey|hi|hello)[^,]*,?\s*/i, '');
              if (!/[.!?]$/.test(line)) line += '.';
              return line.charAt(0).toUpperCase() + line.slice(1);
            })
            .join(' ')
        : cleaned;

    const optimizedBody = [
      openers[tone] || openers.professional,
      '',
      bodyCore,
      '',
      `Specifically, the approach focuses on ${hook} with clear milestones, transparent reporting, and zero fluff.`,
      '',
      closer,
      '',
      'Best regards',
    ].join('\n');

    const subjectSeeds = [
      `${firstNameToken}, quick idea for ${companyToken}`,
      `Improving ${hook.split(' ')[0]} at ${companyToken}`,
      `A practical plan for ${companyToken}`,
      `${companyToken}: 15-min walkthrough?`,
      `Thoughts on ${companyToken}'s next quarter`,
    ];

    // Score subjects for open-rate heuristics
    const subjects = subjectSeeds.map((s, i) => {
      let score = 72 + i * 2;
      if (s.includes(firstNameToken)) score += 8;
      if (s.includes(companyToken)) score += 6;
      if (s.length >= 28 && s.length <= 52) score += 7;
      if (/free|!!!|guarantee/i.test(s)) score -= 25;
      if (s.endsWith('?')) score += 4;
      return {
        subject: s,
        score: Math.min(98, score),
        reason:
          score >= 85
            ? 'Personalized, concise, curiosity-driven'
            : 'Solid baseline — consider adding specificity',
      };
    });

    subjects.sort((a, b) => b.score - a.score);

    const tips = [
      'Lead with the recipient outcome, not your company bio.',
      'Keep the first screen under 90 words for mobile readers.',
      'One clear CTA beats multiple competing asks.',
      'Personalize with {{first_name}} and {{company}} tokens.',
      'Avoid spam triggers: excessive punctuation, ALL CAPS, and hard sell phrases.',
    ];
    if (foundSpam.length) {
      tips.unshift(`Removed/flagged spam-risk phrases: ${foundSpam.join(', ')}`);
    }

    const readability =
      cleaned.split(/\s+/).length < 180
        ? 'Good length for cold outreach'
        : 'Consider shortening — long proposals lower reply rates';

    return res.status(200).json({
      optimized_body: optimizedBody,
      subjects: subjects.slice(0, 5),
      best_subject: subjects[0].subject,
      analysis: {
        original_words: cleaned.split(/\s+/).filter(Boolean).length,
        optimized_words: optimizedBody.split(/\s+/).filter(Boolean).length,
        spam_flags: foundSpam,
        readability,
        compliance: foundSpam.length === 0 ? 'Anti-spam compliant' : 'Needs cleanup',
        business_type,
        tone,
        goal,
      },
      tips,
    });
  } catch (err) {
    console.error('optimize API error:', err);
    if (!res.headersSent) {
      return res.status(500).json({ error: err?.message || 'Optimize failed', ok: false });
    }
  }
}
