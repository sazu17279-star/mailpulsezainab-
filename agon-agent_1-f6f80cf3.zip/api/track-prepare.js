import crypto from 'crypto';
import supabase, { isDbConfigured } from './db-client.js';
import { handleOptions, ok, fail } from './_http.js';

export default async function handler(req, res) {
  if (handleOptions(req, res, 'POST, OPTIONS')) return;

  try {
    if (req.method !== 'POST') return fail(res, 'Method not allowed', 405);

    const {
      email,
      name = '',
      company = '',
      subject = 'Tracked email',
      body = '',
      campaign_id,
      campaign_name,
      base_url,
    } = req.body || {};

    if (!email || !String(email).includes('@')) {
      return fail(res, 'Valid email required', 400);
    }

    const origin = base_url || req.headers.origin || '';
    const tracking_token = crypto.randomBytes(16).toString('hex');

    // Offline / missing DB: still return a usable pixel URL for local testing
    if (!isDbConfigured || supabase.__fallback) {
      const openUrl = `${origin}/api/track-open?t=${tracking_token}`;
      const pixelHtml = `<img src="${openUrl}" width="1" height="1" alt="" style="display:none!important;width:1px!important;height:1px!important;border:0!important;opacity:0!important;" />`;
      return ok(
        res,
        {
          ok: true,
          campaign_id: null,
          recipient_id: null,
          tracking_token,
          open_url: openUrl,
          pixel_html: pixelHtml,
          inject_snippet: pixelHtml,
          wrap_link: true,
          wrapLinkExample: `${origin}/api/track-click?t=${tracking_token}&u=${encodeURIComponent('https://example.com')}`,
          zero_watermark: true,
          offline: true,
          warning: 'Database offline — token issued locally only',
        },
        201
      );
    }

    let cid = campaign_id ? Number(campaign_id) : null;
    if (!cid) {
      const { data: camp, error } = await supabase
        .from('mp_campaigns')
        .insert({
          name: campaign_name || `Gmail compose · ${email}`,
          subject,
          body,
          status: 'active',
          timezone: 'UTC',
          throttle_ms: 10000,
          target_send_hour: 9,
          recipient_count: 1,
          sent_count: 0,
          open_count: 0,
          click_count: 0,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })
        .select()
        .single();
      if (error) throw error;
      cid = camp.id;
    }

    const { data: recipient, error: rErr } = await supabase
      .from('mp_recipients')
      .insert({
        campaign_id: cid,
        email: String(email).trim().toLowerCase(),
        name: name || String(email).split('@')[0],
        company: company || '',
        status: 'pending',
        open_count: 0,
        click_count: 0,
        tracking_token,
      })
      .select()
      .single();
    if (rErr) throw rErr;

    const openUrl = `${origin}/api/track-open?t=${tracking_token}`;
    const pixelHtml = `<img src="${openUrl}" width="1" height="1" alt="" style="display:none!important;width:1px!important;height:1px!important;border:0!important;opacity:0!important;" />`;

    return ok(
      res,
      {
        ok: true,
        campaign_id: cid,
        recipient_id: recipient.id,
        tracking_token,
        open_url: openUrl,
        pixel_html: pixelHtml,
        inject_snippet: pixelHtml,
        wrap_link: true,
        wrapLinkExample: `${origin}/api/track-click?t=${tracking_token}&u=${encodeURIComponent('https://example.com')}`,
        zero_watermark: true,
      },
      201
    );
  } catch (err) {
    console.error('track-prepare error:', err);
    return fail(res, err);
  }
}
