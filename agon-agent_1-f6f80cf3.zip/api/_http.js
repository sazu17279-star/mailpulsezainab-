/**
 * Shared HTTP helpers for Vercel serverless routes.
 * Keeps CORS consistent and prevents double-send / unhandled crashes.
 */

export function setCors(res, methods = 'GET, POST, PUT, DELETE, OPTIONS') {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', methods);
  res.setHeader(
    'Access-Control-Allow-Headers',
    'Content-Type, Authorization, X-MailPulse-Extension, X-Requested-With'
  );
  res.setHeader('Access-Control-Max-Age', '86400');
  res.setHeader('Cache-Control', 'no-store');
  // Avoid buffering issues in some previews
  res.setHeader('Connection', 'keep-alive');
}

export function handleOptions(req, res, methods) {
  setCors(res, methods);
  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return true;
  }
  return false;
}

export function ok(res, data, status = 200) {
  if (res.headersSent) return;
  return res.status(status).json(data);
}

export function fail(res, err, status = 500) {
  if (res.headersSent) return;
  const message =
    typeof err === 'string'
      ? err
      : err?.message || err?.error_description || 'Internal server error';
  console.error('[api]', message);
  return res.status(status).json({
    error: message,
    ok: false,
  });
}

/** Zero-state payloads when DB is offline — keeps UI alive */
export const ZERO_STATS = {
  totals: {
    campaigns: 0,
    active_campaigns: 0,
    recipients: 0,
    sent: 0,
    opened: 0,
    clicked: 0,
    pending: 0,
    open_rate: 0,
    click_rate: 0,
    unread_notifications: 0,
  },
  chart: [],
  recent_events: [],
  campaigns: [],
  offline: true,
};

export const PIXEL_GIF = Buffer.from(
  'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
  'base64'
);
