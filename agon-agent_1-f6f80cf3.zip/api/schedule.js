import supabase from './db-client.js';

/** US states → IANA timezone (primary civil time for that state) */
export const US_STATE_TIMEZONES = [
  { code: 'AL', name: 'Alabama', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'AK', name: 'Alaska', timezone: 'America/Anchorage', abbr: 'AKT' },
  { code: 'AZ', name: 'Arizona', timezone: 'America/Phoenix', abbr: 'MST' },
  { code: 'AR', name: 'Arkansas', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'CA', name: 'California', timezone: 'America/Los_Angeles', abbr: 'PT' },
  { code: 'CO', name: 'Colorado', timezone: 'America/Denver', abbr: 'MT' },
  { code: 'CT', name: 'Connecticut', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'DE', name: 'Delaware', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'DC', name: 'District of Columbia', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'FL', name: 'Florida', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'GA', name: 'Georgia', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'HI', name: 'Hawaii', timezone: 'Pacific/Honolulu', abbr: 'HT' },
  { code: 'ID', name: 'Idaho', timezone: 'America/Boise', abbr: 'MT' },
  { code: 'IL', name: 'Illinois', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'IN', name: 'Indiana', timezone: 'America/Indiana/Indianapolis', abbr: 'ET' },
  { code: 'IA', name: 'Iowa', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'KS', name: 'Kansas', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'KY', name: 'Kentucky', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'LA', name: 'Louisiana', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'ME', name: 'Maine', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'MD', name: 'Maryland', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'MA', name: 'Massachusetts', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'MI', name: 'Michigan', timezone: 'America/Detroit', abbr: 'ET' },
  { code: 'MN', name: 'Minnesota', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'MS', name: 'Mississippi', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'MO', name: 'Missouri', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'MT', name: 'Montana', timezone: 'America/Denver', abbr: 'MT' },
  { code: 'NE', name: 'Nebraska', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'NV', name: 'Nevada', timezone: 'America/Los_Angeles', abbr: 'PT' },
  { code: 'NH', name: 'New Hampshire', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'NJ', name: 'New Jersey', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'NM', name: 'New Mexico', timezone: 'America/Denver', abbr: 'MT' },
  { code: 'NY', name: 'New York', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'NC', name: 'North Carolina', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'ND', name: 'North Dakota', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'OH', name: 'Ohio', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'OK', name: 'Oklahoma', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'OR', name: 'Oregon', timezone: 'America/Los_Angeles', abbr: 'PT' },
  { code: 'PA', name: 'Pennsylvania', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'RI', name: 'Rhode Island', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'SC', name: 'South Carolina', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'SD', name: 'South Dakota', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'TN', name: 'Tennessee', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'TX', name: 'Texas', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'UT', name: 'Utah', timezone: 'America/Denver', abbr: 'MT' },
  { code: 'VT', name: 'Vermont', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'VA', name: 'Virginia', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'WA', name: 'Washington', timezone: 'America/Los_Angeles', abbr: 'PT' },
  { code: 'WV', name: 'West Virginia', timezone: 'America/New_York', abbr: 'ET' },
  { code: 'WI', name: 'Wisconsin', timezone: 'America/Chicago', abbr: 'CT' },
  { code: 'WY', name: 'Wyoming', timezone: 'America/Denver', abbr: 'MT' },
];

const INTL_ZONES = [
  'UTC',
  'America/New_York',
  'America/Chicago',
  'America/Denver',
  'America/Los_Angeles',
  'America/Phoenix',
  'America/Anchorage',
  'Pacific/Honolulu',
  'Europe/London',
  'Europe/Paris',
  'Europe/Berlin',
  'Asia/Dubai',
  'Asia/Singapore',
  'Asia/Tokyo',
  'Australia/Sydney',
];

/** Engagement window presets (local recipient time) — not locked to 9:00 */
export const WINDOW_PRESETS = {
  smart: {
    id: 'smart',
    label: 'Smart peak (auto)',
    description: 'Picks the next high-engagement slot in the business day (morning or early afternoon)',
    start_hour: 9,
    start_minute: 0,
    end_hour: 16,
    end_minute: 0,
    mode: 'smart',
  },
  morning: {
    id: 'morning',
    label: 'Morning window',
    description: 'Flexible 9:00–11:30 AM local',
    start_hour: 9,
    start_minute: 0,
    end_hour: 11,
    end_minute: 30,
    mode: 'window',
  },
  late_morning: {
    id: 'late_morning',
    label: 'Late morning peak',
    description: '10:00–11:30 AM — strong open rates',
    start_hour: 10,
    start_minute: 0,
    end_hour: 11,
    end_minute: 30,
    mode: 'peak',
  },
  midday: {
    id: 'midday',
    label: 'Midday',
    description: '11:00 AM–1:00 PM local',
    start_hour: 11,
    start_minute: 0,
    end_hour: 13,
    end_minute: 0,
    mode: 'window',
  },
  afternoon: {
    id: 'afternoon',
    label: 'Afternoon',
    description: '1:00–4:00 PM local',
    start_hour: 13,
    start_minute: 0,
    end_hour: 16,
    end_minute: 0,
    mode: 'window',
  },
  business: {
    id: 'business',
    label: 'Full business day',
    description: '9:00 AM–5:00 PM — next available slot',
    start_hour: 9,
    start_minute: 0,
    end_hour: 17,
    end_minute: 0,
    mode: 'next_available',
  },
  custom: {
    id: 'custom',
    label: 'Custom time',
    description: 'Pick an exact local hour and minute',
    start_hour: 9,
    start_minute: 0,
    end_hour: 17,
    end_minute: 0,
    mode: 'custom',
  },
};

const INSTANT_DISPATCH_GAP_MS = 10_000;

/** High-engagement candidate minutes-from-midnight (US B2B heuristics) */
const PEAK_SLOTS = [
  9 * 60 + 30, // 9:30
  10 * 60, // 10:00
  10 * 60 + 30, // 10:30
  11 * 60, // 11:00
  14 * 60, // 14:00
  14 * 60 + 30, // 14:30
  15 * 60, // 15:00
];

function zonedParts(date, timeZone) {
  const dtf = new Intl.DateTimeFormat('en-US', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23',
  });
  const parts = Object.fromEntries(
    dtf
      .formatToParts(date)
      .filter((p) => p.type !== 'literal')
      .map((p) => [p.type, p.value])
  );
  return {
    year: Number(parts.year),
    month: Number(parts.month),
    day: Number(parts.day),
    hour: Number(parts.hour),
    minute: Number(parts.minute),
    second: Number(parts.second),
  };
}

function zonedWallTimeToUtc(year, month, day, hour, minute, second, timeZone) {
  let utc = Date.UTC(year, month - 1, day, hour, minute, second);
  for (let i = 0; i < 3; i++) {
    const asLocal = zonedParts(new Date(utc), timeZone);
    const asUtcMs = Date.UTC(
      asLocal.year,
      asLocal.month - 1,
      asLocal.day,
      asLocal.hour,
      asLocal.minute,
      asLocal.second
    );
    const wantedMs = Date.UTC(year, month - 1, day, hour, minute, second);
    utc += wantedMs - asUtcMs;
  }
  return new Date(utc);
}

function minutesOfDay(h, m = 0) {
  return Number(h) * 60 + Number(m || 0);
}

function formatHm(totalMinutes) {
  const h = Math.floor(totalMinutes / 60);
  const m = totalMinutes % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function nextCalendarDay(local, timeZone) {
  const noonLocal = zonedWallTimeToUtc(local.year, local.month, local.day, 12, 0, 0, timeZone);
  const next = new Date(noonLocal.getTime() + 24 * 3600 * 1000);
  return zonedParts(next, timeZone);
}

function wallToUtcOnDay(dayParts, hour, minute, timeZone) {
  return zonedWallTimeToUtc(dayParts.year, dayParts.month, dayParts.day, hour, minute, 0, timeZone);
}

/**
 * Compute the next send instant inside a flexible local window.
 * modes:
 *  - smart / peak: prefer peak engagement slots within the window
 *  - window / next_available: earliest future time in window (15-min grid if already inside)
 *  - custom: exact hour:minute (must fall in window when bounds provided)
 */
function computeNextSendAt(timeZone, options = {}) {
  const {
    mode = 'smart',
    start_hour = 9,
    start_minute = 0,
    end_hour = 11,
    end_minute = 30,
    target_hour,
    target_minute = 0,
  } = options;

  const now = new Date();
  const local = zonedParts(now, timeZone);
  const nowMins = minutesOfDay(local.hour, local.minute);
  const winStart = minutesOfDay(start_hour, start_minute);
  const winEnd = minutesOfDay(end_hour, end_minute);

  if (winEnd <= winStart) {
    throw new Error('window_end must be after window_start');
  }

  const buildCandidatesForDay = (dayParts, isToday) => {
    const candidates = [];

    if (mode === 'custom' && target_hour != null) {
      const tm = minutesOfDay(target_hour, target_minute);
      if (tm >= winStart && tm <= winEnd) {
        candidates.push(tm);
      } else {
        // Still allow exact custom even outside default preset bounds if user insists
        candidates.push(tm);
      }
      return candidates;
    }

    if (mode === 'smart' || mode === 'peak') {
      for (const slot of PEAK_SLOTS) {
        if (slot >= winStart && slot <= winEnd) candidates.push(slot);
      }
      // Always include window open as fallback
      if (!candidates.includes(winStart)) candidates.unshift(winStart);
      // Mid-window
      const mid = Math.floor((winStart + winEnd) / 2);
      if (!candidates.includes(mid)) candidates.push(mid);
    } else {
      // window / next_available: start, then 15-min steps
      for (let m = winStart; m <= winEnd; m += 15) {
        candidates.push(m);
      }
    }

    candidates.sort((a, b) => a - b);

    if (isToday) {
      // If currently inside window, next 15-min boundary (or now+2min for next_available)
      if (nowMins >= winStart && nowMins <= winEnd) {
        if (mode === 'next_available' || mode === 'window') {
          const rounded = Math.ceil((nowMins + 2) / 15) * 15;
          if (rounded <= winEnd) candidates.unshift(Math.min(rounded, winEnd));
          else return []; // no slot left today
        } else {
          // smart: next peak still ahead today
          return candidates.filter((c) => c > nowMins + 1);
        }
      }
      return candidates.filter((c) => c > nowMins);
    }
    return candidates;
  };

  // Try today, then next 7 days
  let day = local;
  for (let d = 0; d < 8; d++) {
    const isToday = d === 0;
    const slots = buildCandidatesForDay(day, isToday);
    for (const mins of slots) {
      const h = Math.floor(mins / 60);
      const m = mins % 60;
      const utc = wallToUtcOnDay(day, h, m, timeZone);
      if (utc.getTime() > now.getTime() + 30_000) {
        return {
          schedule_at: utc.toISOString(),
          local_hour: h,
          local_minute: m,
          local_time: formatHm(mins),
          window_start: formatHm(winStart),
          window_end: formatHm(winEnd),
          mode,
          day_offset: d,
        };
      }
    }
    day = nextCalendarDay(day, timeZone);
  }

  // Absolute fallback: tomorrow at window start
  const tomorrow = nextCalendarDay(local, timeZone);
  const fb = wallToUtcOnDay(tomorrow, start_hour, start_minute, timeZone);
  return {
    schedule_at: fb.toISOString(),
    local_hour: start_hour,
    local_minute: start_minute,
    local_time: formatHm(winStart),
    window_start: formatHm(winStart),
    window_end: formatHm(winEnd),
    mode,
    day_offset: 1,
  };
}

/** @deprecated path — kept as thin wrapper for simple hour queries */
function nextLocalMorning(timeZone, hour = 9) {
  const result = computeNextSendAt(timeZone, {
    mode: 'custom',
    start_hour: 0,
    start_minute: 0,
    end_hour: 23,
    end_minute: 59,
    target_hour: hour,
    target_minute: 0,
  });
  return result.schedule_at;
}

function resolveTimezone({ timezone, us_state, state }) {
  const code = (us_state || state || '').toString().toUpperCase().trim();
  if (code) {
    const hit = US_STATE_TIMEZONES.find((s) => s.code === code || s.name.toUpperCase() === code);
    if (hit) {
      return {
        timezone: hit.timezone,
        us_state: hit.code,
        state_name: hit.name,
        abbr: hit.abbr,
      };
    }
  }
  const tz = timezone || 'America/New_York';
  const fromState = US_STATE_TIMEZONES.find((s) => s.timezone === tz);
  return {
    timezone: tz,
    us_state: fromState?.code || null,
    state_name: fromState?.name || null,
    abbr: fromState?.abbr || null,
  };
}

function offsetHoursLabel(timeZone) {
  try {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone,
      timeZoneName: 'shortOffset',
    }).formatToParts(new Date());
    const name = parts.find((p) => p.type === 'timeZoneName')?.value || '';
    const m = name.match(/GMT([+-]\d+)/i) || name.match(/UTC([+-]\d+)/i);
    if (m) return Number(m[1]);
  } catch {
    /* ignore */
  }
  return 0;
}

function parseWindowFromQuery(query) {
  const presetId = query.preset || query.window || 'smart';
  const preset = WINDOW_PRESETS[presetId] || WINDOW_PRESETS.smart;

  const start_hour =
    query.start_hour != null ? Number(query.start_hour) : preset.start_hour;
  const start_minute =
    query.start_minute != null ? Number(query.start_minute) : preset.start_minute;
  const end_hour = query.end_hour != null ? Number(query.end_hour) : preset.end_hour;
  const end_minute =
    query.end_minute != null ? Number(query.end_minute) : preset.end_minute;
  const mode = query.mode || preset.mode;
  const target_hour =
    query.hour != null
      ? Number(query.hour)
      : query.target_hour != null
        ? Number(query.target_hour)
        : undefined;
  const target_minute =
    query.minute != null
      ? Number(query.minute)
      : query.target_minute != null
        ? Number(query.target_minute)
        : 0;

  return {
    preset_id: presetId,
    start_hour,
    start_minute,
    end_hour,
    end_minute,
    mode,
    target_hour,
    target_minute,
  };
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'Content-Type, Authorization, X-MailPulse-Extension, X-Requested-With'
  );
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const mode = req.query.mode_list || req.query.view || 'all'; // all | us | intl
      const win = parseWindowFromQuery(req.query);

      const computeForTz = (tz) =>
        computeNextSendAt(tz, {
          mode: win.mode,
          start_hour: win.start_hour,
          start_minute: win.start_minute,
          end_hour: win.end_hour,
          end_minute: win.end_minute,
          target_hour: win.target_hour,
          target_minute: win.target_minute,
        });

      const usStates = US_STATE_TIMEZONES.map((s) => {
        const next = computeForTz(s.timezone);
        return {
          code: s.code,
          name: s.name,
          timezone: s.timezone,
          abbr: s.abbr,
          offset_hours: offsetHoursLabel(s.timezone),
          next_send_at: next.schedule_at,
          local_time: next.local_time,
          local_hour: next.local_hour,
          local_minute: next.local_minute,
          window_start: next.window_start,
          window_end: next.window_end,
          label: `${s.name} (${s.code}) · ${s.abbr} · next ${next.local_time} local (${next.window_start}–${next.window_end})`,
        };
      });

      const zones = INTL_ZONES.map((tz) => {
        const next = computeForTz(tz);
        return {
          timezone: tz,
          offset_hours: offsetHoursLabel(tz),
          next_send_at: next.schedule_at,
          local_time: next.local_time,
          local_hour: next.local_hour,
          label: `${tz} → next ${next.local_time} local`,
        };
      });

      const payload = {
        presets: Object.values(WINDOW_PRESETS),
        window: {
          preset_id: win.preset_id,
          start_hour: win.start_hour,
          start_minute: win.start_minute,
          end_hour: win.end_hour,
          end_minute: win.end_minute,
          mode: win.mode,
          label: `${formatHm(minutesOfDay(win.start_hour, win.start_minute))}–${formatHm(
            minutesOfDay(win.end_hour, win.end_minute)
          )} local`,
        },
        instant_dispatch_gap_ms: INSTANT_DISPATCH_GAP_MS,
        // backward-compatible fields (no longer mean "fixed 9am")
        default_hour: win.target_hour ?? win.start_hour,
        morning_window: `${formatHm(minutesOfDay(win.start_hour, win.start_minute))}–${formatHm(
          minutesOfDay(win.end_hour, win.end_minute)
        )} local (flexible)`,
      };

      if (mode === 'us') {
        return res.status(200).json({ us_states: usStates, ...payload });
      }

      return res.status(200).json({
        zones,
        us_states: usStates,
        defaults: Object.fromEntries(INTL_ZONES.map((z) => [z, offsetHoursLabel(z)])),
        ...payload,
      });
    }

    if (req.method === 'POST') {
      const body = req.body || {};
      const {
        campaign_id,
        timezone: rawTz,
        us_state,
        state,
        schedule_at,
        // flexible window
        preset = 'smart',
        window_preset,
        mode: bodyMode,
        start_hour,
        start_minute = 0,
        end_hour,
        end_minute = 0,
        target_hour,
        target_minute = 0,
        // legacy
        target_send_hour,
        // pacing — keep 10s instant dispatch compatible
        throttle_ms = INSTANT_DISPATCH_GAP_MS,
      } = body;

      if (!campaign_id) return res.status(400).json({ error: 'campaign_id is required' });

      const resolved = resolveTimezone({ timezone: rawTz, us_state, state });
      const presetId = window_preset || preset || 'smart';
      const presetDef = WINDOW_PRESETS[presetId] || WINDOW_PRESETS.smart;

      const win = {
        mode: bodyMode || presetDef.mode,
        start_hour: start_hour != null ? Number(start_hour) : presetDef.start_hour,
        start_minute: start_minute != null ? Number(start_minute) : presetDef.start_minute,
        end_hour: end_hour != null ? Number(end_hour) : presetDef.end_hour,
        end_minute: end_minute != null ? Number(end_minute) : presetDef.end_minute,
        target_hour:
          target_hour != null
            ? Number(target_hour)
            : target_send_hour != null
              ? Number(target_send_hour)
              : undefined,
        target_minute: Number(target_minute) || 0,
      };

      // Custom mode without explicit hour → treat as smart inside custom bounds
      if (win.mode === 'custom' && win.target_hour == null) {
        win.mode = 'smart';
      }

      let computed;
      if (schedule_at) {
        const dt = new Date(schedule_at);
        if (Number.isNaN(dt.getTime())) {
          return res.status(400).json({ error: 'Invalid schedule_at' });
        }
        const local = zonedParts(dt, resolved.timezone);
        computed = {
          schedule_at: dt.toISOString(),
          local_hour: local.hour,
          local_minute: local.minute,
          local_time: formatHm(minutesOfDay(local.hour, local.minute)),
          window_start: formatHm(minutesOfDay(win.start_hour, win.start_minute)),
          window_end: formatHm(minutesOfDay(win.end_hour, win.end_minute)),
          mode: 'explicit',
          day_offset: 0,
        };
      } else {
        computed = computeNextSendAt(resolved.timezone, win);
      }

      const gap = Math.max(Number(throttle_ms) || INSTANT_DISPATCH_GAP_MS, 1000);

      let data = null;
      try {
        const upd = await supabase
          .from('mp_campaigns')
          .update({
            status: 'scheduled',
            timezone: resolved.timezone,
            // Store the *chosen* local hour (dynamic — not fixed 9)
            target_send_hour: computed.local_hour,
            schedule_at: computed.schedule_at,
            throttle_ms: gap,
            updated_at: new Date().toISOString(),
          })
          .eq('id', campaign_id)
          .select()
          .single();
        if (upd.error) throw upd.error;
        data = upd.data;

        await supabase
          .from('mp_recipients')
          .update({ status: 'queued' })
          .eq('campaign_id', campaign_id)
          .eq('status', 'pending');
      } catch (dbErr) {
        // Still return computed schedule so UI doesn't crash when DB is flaky
        console.error('schedule DB update soft-fail:', dbErr?.message || dbErr);
        data = {
          id: campaign_id,
          status: 'scheduled',
          timezone: resolved.timezone,
          target_send_hour: computed.local_hour,
          schedule_at: computed.schedule_at,
          throttle_ms: gap,
        };
      }

      const stateLabel = resolved.state_name
        ? `${resolved.state_name} (${resolved.us_state}) ${resolved.abbr}`
        : resolved.timezone;

      return res.status(200).json({
        ok: true,
        campaign: data,
        scheduled_for: computed.schedule_at,
        timezone: resolved.timezone,
        us_state: resolved.us_state,
        state_name: resolved.state_name,
        local_hour: computed.local_hour,
        local_minute: computed.local_minute,
        local_time: computed.local_time,
        window: {
          preset: presetId,
          mode: computed.mode,
          start: computed.window_start,
          end: computed.window_end,
        },
        throttle_ms: gap,
        instant_dispatch_gap_ms: INSTANT_DISPATCH_GAP_MS,
        message: `Held until ${computed.local_time} local in ${stateLabel} (window ${computed.window_start}–${computed.window_end}, ${computed.mode})`,
      });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('schedule API error:', err);
    if (!res.headersSent) {
      return res.status(500).json({ error: err?.message || 'Schedule failed', ok: false });
    }
  }
}
