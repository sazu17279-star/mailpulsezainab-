import supabase, { isDbConfigured } from './db-client.js';

function safeTarget(raw) {
  let target = raw || 'https://example.com';
  try {
    target = decodeURIComponent(target);
  } catch {
    /* keep */
  }
  if (!/^https?:\/\//i.test(target)) target = 'https://' + target;
  // Prevent open redirect to javascript:
  if (/^javascript:/i.test(target)) target = 'https://example.com';
  return target;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const t = req.query?.t;
  const target = safeTarget(req.query?.u);

  try {
    if (t && isDbConfigured && !supabase.__fallback) {
      const { data: recipient } = await supabase
        .from('mp_recipients')
        .select('*')
        .eq('tracking_token', t)
        .maybeSingle();

      if (recipient) {
        const clickCount = (recipient.click_count || 0) + 1;
        await supabase
          .from('mp_recipients')
          .update({
            click_count: clickCount,
            status: 'clicked',
            last_opened_at: recipient.last_opened_at || new Date().toISOString(),
          })
          .eq('id', recipient.id);

        await supabase.from('mp_tracking_events').insert({
          campaign_id: recipient.campaign_id,
          recipient_id: recipient.id,
          event_type: 'click',
          url: target,
          user_agent: req.headers['user-agent'] || '',
          ip: (req.headers['x-forwarded-for'] || '').toString().split(',')[0] || '',
          meta: JSON.stringify({ click: clickCount }),
        });

        const { data: camp } = await supabase
          .from('mp_campaigns')
          .select('click_count')
          .eq('id', recipient.campaign_id)
          .maybeSingle();
        if (camp) {
          await supabase
            .from('mp_campaigns')
            .update({ click_count: (camp.click_count || 0) + 1 })
            .eq('id', recipient.campaign_id);
        }

        await supabase.from('mp_notifications').insert({
          campaign_id: recipient.campaign_id,
          recipient_id: recipient.id,
          type: 'click',
          message: `${recipient.name || recipient.email} clicked a link`,
          read: false,
        });
      }
    }
  } catch (err) {
    console.error('track-click error:', err);
  }

  // Always redirect — never hang the client
  if (!res.headersSent) {
    res.writeHead(302, { Location: target });
    return res.end();
  }
}
