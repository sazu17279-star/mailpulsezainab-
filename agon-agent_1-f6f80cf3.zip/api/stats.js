import supabase, { isDbConfigured } from './db-client.js';
import { handleOptions, ok, fail, ZERO_STATS } from './_http.js';

export default async function handler(req, res) {
  if (handleOptions(req, res, 'GET, OPTIONS')) return;

  try {
    if (req.method !== 'GET') {
      return fail(res, 'Method not allowed', 405);
    }

    if (!isDbConfigured || supabase.__fallback) {
      return ok(res, ZERO_STATS);
    }

    const [campaignsRes, recipientsRes, eventsRes, notifRes] = await Promise.all([
      supabase.from('mp_campaigns').select('*'),
      supabase.from('mp_recipients').select('*'),
      supabase
        .from('mp_tracking_events')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(200),
      supabase.from('mp_notifications').select('*').eq('read', false),
    ]);

    // Soft-fail individual queries instead of crashing the whole dashboard
    const campaigns = campaignsRes.error ? [] : campaignsRes.data || [];
    const recipients = recipientsRes.error ? [] : recipientsRes.data || [];
    const events = eventsRes.error ? [] : eventsRes.data || [];
    const notifs = notifRes.error ? [] : notifRes.data || [];

    if (campaignsRes.error && recipientsRes.error) {
      return ok(res, { ...ZERO_STATS, offline: true, warning: campaignsRes.error.message });
    }

    const sent = recipients.filter((r) =>
      ['sent', 'opened', 'clicked'].includes(r.status)
    ).length;
    const opened = recipients.filter((r) => (r.open_count || 0) > 0).length;
    const clicked = recipients.filter((r) => (r.click_count || 0) > 0).length;
    const pending = recipients.filter((r) =>
      ['pending', 'queued'].includes(r.status)
    ).length;

    const openRate = sent > 0 ? Math.round((opened / sent) * 1000) / 10 : 0;
    const clickRate = sent > 0 ? Math.round((clicked / sent) * 1000) / 10 : 0;

    const byDay = {};
    for (const e of events) {
      const day = (e.created_at || '').slice(0, 10);
      if (!day) continue;
      if (!byDay[day]) byDay[day] = { date: day, opens: 0, clicks: 0 };
      if (e.event_type === 'open') byDay[day].opens += 1;
      if (e.event_type === 'click') byDay[day].clicks += 1;
    }

    const chart = Object.values(byDay)
      .sort((a, b) => a.date.localeCompare(b.date))
      .slice(-14);

    return ok(res, {
      totals: {
        campaigns: campaigns.length,
        active_campaigns: campaigns.filter((c) =>
          ['sending', 'scheduled', 'active'].includes(c.status)
        ).length,
        recipients: recipients.length,
        sent,
        opened,
        clicked,
        pending,
        open_rate: openRate,
        click_rate: clickRate,
        unread_notifications: notifs.length,
      },
      chart,
      recent_events: events.slice(0, 20),
      campaigns: campaigns.slice(0, 8),
      offline: false,
    });
  } catch (err) {
    console.error('stats API error:', err);
    // Never drop the connection with an uncaught throw — return zero-state
    return ok(res, { ...ZERO_STATS, offline: true, warning: err?.message || 'stats failed' });
  }
}
