import crypto from 'crypto';
import supabase from './db-client.js';

function personalize(text, recipient) {
  if (!text) return '';
  return text
    .replace(/\{\{name\}\}/gi, recipient.name || 'there')
    .replace(/\{\{email\}\}/gi, recipient.email || '')
    .replace(/\{\{company\}\}/gi, recipient.company || 'your company')
    .replace(/\{\{first_name\}\}/gi, (recipient.name || 'there').split(' ')[0]);
}

function buildTrackedHtml(body, recipient, baseUrl, trackingEnabled = true) {
  const personalized = personalize(body, recipient);
  let html = personalized.replace(/\n/g, '<br/>');

  if (!trackingEnabled) return html;

  const token = recipient.tracking_token;
  // Clean invisible pixel — zero watermark, zero footer, zero branding
  const pixel = `<img src="${baseUrl}/api/track-open?t=${token}" width="1" height="1" alt="" style="display:none!important;width:1px!important;height:1px!important;border:0!important;overflow:hidden!important;opacity:0!important;" />`;

  html = html.replace(/(https?:\/\/[^\s<]+)/g, (url) => {
    if (url.includes('/api/track-')) return url;
    return `<a href="${baseUrl}/api/track-click?t=${token}&u=${encodeURIComponent(url)}">${url}</a>`;
  });

  return `${html}${pixel}`;
}

function toBase64Url(str) {
  return Buffer.from(str, 'utf8')
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

function buildRawMessage({ from, to, subject, html, replyTo }) {
  const boundary = `mp_${Date.now()}_${Math.random().toString(36).slice(2)}`;
  const headers = [
    `From: ${from}`,
    `To: ${to}`,
    `Subject: =?UTF-8?B?${Buffer.from(subject, 'utf8').toString('base64')}?=`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
  ];
  if (replyTo) headers.push(`Reply-To: ${replyTo}`);

  const plain = html
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>');

  const mime = [
    headers.join('\r\n'),
    '',
    `--${boundary}`,
    'Content-Type: text/plain; charset="UTF-8"',
    'Content-Transfer-Encoding: 7bit',
    '',
    plain,
    '',
    `--${boundary}`,
    'Content-Type: text/html; charset="UTF-8"',
    'Content-Transfer-Encoding: 7bit',
    '',
    html,
    '',
    `--${boundary}--`,
  ].join('\r\n');

  return toBase64Url(mime);
}

async function gmailSend(accessToken, raw) {
  const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ raw }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = data?.error?.message || `Gmail API error (${res.status})`;
    throw new Error(msg);
  }
  return data;
}

async function gmailProfile(accessToken) {
  const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/profile', {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.error?.message || 'Failed to read Gmail profile');
  return data;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'Content-Type, Authorization, X-MailPulse-Extension, X-Requested-With'
  );
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '') || req.query.token;
      if (!token) return res.status(400).json({ error: 'Bearer token required' });
      const profile = await gmailProfile(token);
      return res.status(200).json({
        emailAddress: profile.emailAddress,
        messagesTotal: profile.messagesTotal,
        threadsTotal: profile.threadsTotal,
      });
    }

    if (req.method !== 'POST') {
      return res.status(405).json({ error: 'Method not allowed' });
    }

    const {
      access_token,
      campaign_id,
      recipient_id,
      to,
      subject,
      body,
      html,
      from_name,
      from_email,
      tracking_enabled = true,
      base_url,
      mode = 'single', // single | batch
      batch_size = 1,
    } = req.body || {};

    if (!access_token) {
      return res.status(400).json({ error: 'access_token is required for Gmail send' });
    }

    const origin = base_url || req.headers.origin || '';
    let profile;
    try {
      profile = await gmailProfile(access_token);
    } catch (e) {
      return res.status(401).json({
        error: 'Gmail token invalid or expired. Reconnect the account.',
        detail: e.message,
      });
    }

    const senderEmail = from_email || profile.emailAddress;
    const fromHeader = from_name ? `${from_name} <${senderEmail}>` : senderEmail;

    // Batch campaign send through Gmail
    if (mode === 'batch' || campaign_id) {
      if (!campaign_id) return res.status(400).json({ error: 'campaign_id required for batch' });

      const { data: campaign, error: cErr } = await supabase
        .from('mp_campaigns')
        .select('*')
        .eq('id', campaign_id)
        .single();
      if (cErr) throw cErr;

      const limit = Math.min(Number(batch_size) || 1, 5);
      const { data: pending, error: pErr } = await supabase
        .from('mp_recipients')
        .select('*')
        .eq('campaign_id', campaign_id)
        .in('status', ['pending', 'queued'])
        .order('id', { ascending: true })
        .limit(limit);
      if (pErr) throw pErr;

      if (!pending?.length) {
        await supabase
          .from('mp_campaigns')
          .update({ status: 'completed', updated_at: new Date().toISOString() })
          .eq('id', campaign_id);
        return res.status(200).json({ ok: true, sent: 0, remaining: 0, status: 'completed', via: 'gmail' });
      }

      await supabase
        .from('mp_campaigns')
        .update({ status: 'sending', updated_at: new Date().toISOString() })
        .eq('id', campaign_id);

      const results = [];
      for (const recipient of pending) {
        const subj = personalize(campaign.subject, recipient);
        const trackedHtml = buildTrackedHtml(campaign.body, recipient, origin, tracking_enabled !== false);
        const raw = buildRawMessage({
          from: fromHeader,
          to: `${recipient.name || ''} <${recipient.email}>`.trim(),
          subject: subj,
          html: trackedHtml,
        });

        try {
          const gmailRes = await gmailSend(access_token, raw);
          const now = new Date().toISOString();
          await supabase
            .from('mp_recipients')
            .update({ status: 'sent', sent_at: now })
            .eq('id', recipient.id);

          await supabase.from('mp_tracking_events').insert({
            campaign_id: Number(campaign_id),
            recipient_id: recipient.id,
            event_type: 'sent',
            meta: JSON.stringify({
              via: 'gmail',
              gmail_id: gmailRes.id,
              from: senderEmail,
              tracking: tracking_enabled !== false,
            }),
          });

          results.push({ email: recipient.email, ok: true, gmail_id: gmailRes.id });
        } catch (sendErr) {
          await supabase.from('mp_recipients').update({ status: 'failed' }).eq('id', recipient.id);
          await supabase.from('mp_tracking_events').insert({
            campaign_id: Number(campaign_id),
            recipient_id: recipient.id,
            event_type: 'sent',
            meta: JSON.stringify({ via: 'gmail', error: sendErr.message }),
          });
          results.push({ email: recipient.email, ok: false, error: sendErr.message });
        }
      }

      const { count: remaining } = await supabase
        .from('mp_recipients')
        .select('*', { count: 'exact', head: true })
        .eq('campaign_id', campaign_id)
        .in('status', ['pending', 'queued']);

      const { count: sentCount } = await supabase
        .from('mp_recipients')
        .select('*', { count: 'exact', head: true })
        .eq('campaign_id', campaign_id)
        .in('status', ['sent', 'opened', 'clicked']);

      const nextStatus = remaining === 0 ? 'completed' : 'sending';
      await supabase
        .from('mp_campaigns')
        .update({
          status: nextStatus,
          sent_count: sentCount || 0,
          updated_at: new Date().toISOString(),
        })
        .eq('id', campaign_id);

      return res.status(200).json({
        ok: true,
        via: 'gmail',
        from: senderEmail,
        sent: results.filter((r) => r.ok).length,
        failed: results.filter((r) => !r.ok).length,
        remaining: remaining || 0,
        status: nextStatus,
        throttle_ms: 10000,
        gap_seconds: 10,
        mode: 'instant',
        results,
        tracking_enabled: tracking_enabled !== false,
      });
    }

    // Single ad-hoc send (extension / quick dispatch)
    const toAddr = to;
    if (!toAddr || !subject) {
      return res.status(400).json({ error: 'to and subject are required' });
    }

    let finalHtml = html || (body || '').replace(/\n/g, '<br/>');
    let recipientRow = null;

    if (recipient_id) {
      const { data: rec } = await supabase.from('mp_recipients').select('*').eq('id', recipient_id).maybeSingle();
      recipientRow = rec;
      if (rec && campaign_id) {
        const { data: campaign } = await supabase.from('mp_campaigns').select('*').eq('id', campaign_id).maybeSingle();
        if (campaign) {
          finalHtml = buildTrackedHtml(body || campaign.body, rec, origin, tracking_enabled !== false);
        }
      }
    } else if (tracking_enabled && campaign_id) {
      // ephemeral path handled below when creating recipient
    }

    // Ensure tracking for ad-hoc if requested and we have a token path
    if (tracking_enabled && !recipientRow) {
      const tracking_token = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 14)}`;
      let cid = campaign_id;
      if (!cid) {
        const { data: quick } = await supabase
          .from('mp_campaigns')
          .insert({
            name: `Quick send · ${new Date().toLocaleString()}`,
            subject,
            body: body || html || '',
            status: 'sending',
            timezone: 'UTC',
            throttle_ms: 10000,
            target_send_hour: 9,
            recipient_count: 1,
            sent_count: 0,
            open_count: 0,
            click_count: 0,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          })
          .select()
          .single();
        cid = quick?.id;
      }
      if (cid) {
        const { data: rec } = await supabase
          .from('mp_recipients')
          .insert({
            campaign_id: cid,
            email: String(toAddr).toLowerCase().replace(/.*</, '').replace(/>.*/, '').trim(),
            name: String(toAddr).includes('<') ? String(toAddr).split('<')[0].trim() : String(toAddr).split('@')[0],
            company: '',
            status: 'pending',
            open_count: 0,
            click_count: 0,
            tracking_token,
          })
          .select()
          .single();
        recipientRow = rec;
        finalHtml = buildTrackedHtml(body || finalHtml.replace(/<br\s*\/?>/gi, '\n'), rec, origin, true);
      }
    }

    const raw = buildRawMessage({
      from: fromHeader,
      to: toAddr,
      subject,
      html: finalHtml,
    });

    const gmailRes = await gmailSend(access_token, raw);

    if (recipientRow) {
      await supabase
        .from('mp_recipients')
        .update({ status: 'sent', sent_at: new Date().toISOString() })
        .eq('id', recipientRow.id);
      await supabase.from('mp_tracking_events').insert({
        campaign_id: recipientRow.campaign_id,
        recipient_id: recipientRow.id,
        event_type: 'sent',
        meta: JSON.stringify({ via: 'gmail', gmail_id: gmailRes.id }),
      });
      const { count: sentCount } = await supabase
        .from('mp_recipients')
        .select('*', { count: 'exact', head: true })
        .eq('campaign_id', recipientRow.campaign_id)
        .in('status', ['sent', 'opened', 'clicked']);
      await supabase
        .from('mp_campaigns')
        .update({ sent_count: sentCount || 0, status: 'completed', updated_at: new Date().toISOString() })
        .eq('id', recipientRow.campaign_id);
    }

    return res.status(200).json({
      ok: true,
      via: 'gmail',
      from: senderEmail,
      gmail_id: gmailRes.id,
      threadId: gmailRes.threadId,
      tracking: Boolean(recipientRow && tracking_enabled),
      recipient_id: recipientRow?.id || null,
      campaign_id: recipientRow?.campaign_id || campaign_id || null,
    });
  } catch (err) {
    console.error('gmail-send error:', err);
    if (!res.headersSent) {
      return res.status(500).json({ error: err?.message || 'Gmail send failed', ok: false });
    }
  }
}
