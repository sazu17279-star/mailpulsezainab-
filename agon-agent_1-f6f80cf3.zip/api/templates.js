import supabase, { isDbConfigured } from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'Content-Type, Authorization, X-MailPulse-Extension, X-Requested-With'
  );
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      if (!isDbConfigured || supabase.__fallback) {
        return res.status(200).json([]);
      }
      const { data, error } = await supabase
        .from('mp_templates')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) {
        console.error('templates list:', error.message);
        return res.status(200).json([]);
      }
      return res.status(200).json(data || []);
    }

    if (req.method === 'POST') {
      const { name, subject, body, category = 'general' } = req.body || {};
      if (!name || !subject || !body) {
        return res.status(400).json({ error: 'name, subject, and body are required' });
      }
      const { data, error } = await supabase
        .from('mp_templates')
        .insert({ name, subject, body, category })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, name, subject, body, category } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const payload = {};
      if (name !== undefined) payload.name = name;
      if (subject !== undefined) payload.subject = subject;
      if (body !== undefined) payload.body = body;
      if (category !== undefined) payload.category = category;

      const { data, error } = await supabase
        .from('mp_templates')
        .update(payload)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('mp_templates').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('templates API error:', err);
    if (req.method === 'GET') return res.status(200).json([]);
    if (!res.headersSent) {
      return res.status(500).json({ error: err?.message || 'Templates error', ok: false });
    }
  }
}
