import supabase, { isDbConfigured } from './db-client.js';
import { handleOptions, ok, fail } from './_http.js';

/**
 * Lightweight polling bridge for the Chrome extension.
 * Soft-fails to empty notifications so polling never kills the preview.
 */
export default async function handler(req, res) {
  if (handleOptions(req, res, 'GET, POST, OPTIONS')) return;

  try {
    if (req.method === 'GET') {
      if (!isDbConfigured || supabase.__fallback) {
        return ok(res, {
          ok: true,
          server_time: new Date().toISOString(),
          unread: 0,
          notifications: [],
          offline: true,
        });
      }

      const since = req.query.since;
      const limit = Math.min(Number(req.query.limit) || 30, 100);

      let q = supabase
        .from('mp_notifications')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(limit);

      if (since) q = q.gt('created_at', since);
      else q = q.eq('read', false);

      const { data: notifications, error } = await q;
      if (error) {
        return ok(res, {
          ok: true,
          server_time: new Date().toISOString(),
          unread: 0,
          notifications: [],
          warning: error.message,
        });
      }

      const list = notifications || [];
      const campaignIds = [...new Set(list.map((n) => n.campaign_id).filter(Boolean))];
      const recipientIds = [...new Set(list.map((n) => n.recipient_id).filter(Boolean))];

      let campaignsById = {};
      let recipientsById = {};

      // Batch lookups — avoid N+1 that can timeout serverless
      if (campaignIds.length) {
        const { data: camps } = await supabase
          .from('mp_campaigns')
          .select('id, name, subject')
          .in('id', campaignIds);
        for (const c of camps || []) campaignsById[c.id] = c;
      }
      if (recipientIds.length) {
        const { data: recs } = await supabase
          .from('mp_recipients')
          .select('id, email, name')
          .in('id', recipientIds);
        for (const r of recs || []) recipientsById[r.id] = r;
      }

      const enriched = list.map((n) => {
        const c = campaignsById[n.campaign_id];
        const r = recipientsById[n.recipient_id];
        const campaign_name = c?.name || null;
        const recipient_email = r?.email || null;
        const recipient_name = r?.name || null;
        return {
          ...n,
          campaign_name,
          recipient_email,
          recipient_name,
          desktop_title:
            n.type === 'click'
              ? 'Link clicked'
              : n.type === 'open'
                ? 'Email opened'
                : 'MailPulse activity',
          desktop_body: [
            recipient_email || recipient_name || 'A recipient',
            campaign_name ? `· ${campaign_name}` : '',
            `· ${new Date(n.created_at).toLocaleTimeString()}`,
          ]
            .filter(Boolean)
            .join(' '),
        };
      });

      let unread = enriched.filter((n) => !n.read).length;
      try {
        const { count } = await supabase
          .from('mp_notifications')
          .select('*', { count: 'exact', head: true })
          .eq('read', false);
        if (typeof count === 'number') unread = count;
      } catch {
        /* keep local count */
      }

      return ok(res, {
        ok: true,
        server_time: new Date().toISOString(),
        unread: unread || 0,
        notifications: enriched,
      });
    }

    if (req.method === 'POST') {
      const body = req.body || {};
      const { action, ids } = body;
      if (action === 'ping') {
        return ok(res, { ok: true, pong: Date.now(), db: isDbConfigured });
      }
      if (action === 'ack' && Array.isArray(ids) && ids.length) {
        if (isDbConfigured && !supabase.__fallback) {
          await supabase.from('mp_notifications').update({ read: true }).in('id', ids);
        }
        return ok(res, { ok: true });
      }
      return fail(res, 'Unknown action', 400);
    }

    return fail(res, 'Method not allowed', 405);
  } catch (err) {
    console.error('extension-bridge error:', err);
    // Soft response so extension polling never sees connection closed
    return ok(res, {
      ok: true,
      server_time: new Date().toISOString(),
      unread: 0,
      notifications: [],
      warning: err?.message || 'bridge error',
    });
  }
}
