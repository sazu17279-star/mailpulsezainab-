import supabase from './db-client.js';

/**
 * Wipe all MailPulse operational data for a pristine zero-state.
 * Safe for demo/local reset — does not touch auth users.
 */
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method !== 'POST') {
      return res.status(405).json({ error: 'Method not allowed' });
    }

    const confirm = req.body?.confirm;
    if (confirm !== 'RESET_ALL_DATA') {
      return res.status(400).json({ error: 'Pass { confirm: "RESET_ALL_DATA" }' });
    }

    const tables = [
      'mp_notifications',
      'mp_tracking_events',
      'mp_recipients',
      'mp_campaigns',
      'mp_templates',
    ];

    for (const table of tables) {
      const { error } = await supabase.from(table).delete().gte('id', 0);
      if (error) throw new Error(`${table}: ${error.message}`);
    }

    return res.status(200).json({
      ok: true,
      message: 'All campaigns, recipients, events, notifications, and templates removed. Zero-state ready.',
    });
  } catch (err) {
    console.error('reset-data error:', err);
    return res.status(500).json({ error: err.message });
  }
}
