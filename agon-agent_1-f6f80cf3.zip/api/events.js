import supabase, { isDbConfigured } from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'Content-Type, Authorization, X-MailPulse-Extension, X-Requested-With'
  );
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      if (!isDbConfigured || supabase.__fallback) {
        return res.status(200).json([]);
      }
      const { campaign_id, limit = '100' } = req.query;
      let q = supabase
        .from('mp_tracking_events')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(Math.min(Number(limit) || 100, 500));

      if (campaign_id) q = q.eq('campaign_id', campaign_id);

      const { data, error } = await q;
      if (error) {
        console.error('events list:', error.message);
        return res.status(200).json([]);
      }
      return res.status(200).json(data || []);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('events API error:', err);
    return res.status(200).json([]);
  }
}
