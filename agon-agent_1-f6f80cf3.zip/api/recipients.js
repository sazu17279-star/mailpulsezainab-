import crypto from 'crypto';
import supabase, { isDbConfigured } from './db-client.js';

function token() {
  return crypto.randomBytes(16).toString('hex');
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'Content-Type, Authorization, X-MailPulse-Extension, X-Requested-With'
  );
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      if (!isDbConfigured || supabase.__fallback) {
        return res.status(200).json(req.query.id ? null : []);
      }
      const { campaign_id, id } = req.query;
      if (id) {
        const { data, error } = await supabase
          .from('mp_recipients')
          .select('*')
          .eq('id', id)
          .maybeSingle();
        if (error) return res.status(200).json(null);
        return res.status(200).json(data);
      }
      let q = supabase.from('mp_recipients').select('*').order('id', { ascending: true });
      if (campaign_id) q = q.eq('campaign_id', campaign_id);
      const { data, error } = await q;
      if (error) {
        console.error('recipients list:', error.message);
        return res.status(200).json([]);
      }
      return res.status(200).json(data || []);
    }

    if (req.method === 'POST') {
      const { campaign_id, recipients } = req.body || {};
      if (!campaign_id || !Array.isArray(recipients) || recipients.length === 0) {
        return res.status(400).json({ error: 'campaign_id and recipients[] required' });
      }

      const rows = recipients
        .map((r) => {
          const email = (r.email || r).toString().trim().toLowerCase();
          if (!email || !email.includes('@')) return null;
          return {
            campaign_id: Number(campaign_id),
            email,
            name: r.name || email.split('@')[0],
            company: r.company || '',
            status: 'pending',
            open_count: 0,
            click_count: 0,
            tracking_token: token(),
          };
        })
        .filter(Boolean);

      if (rows.length === 0) {
        return res.status(400).json({ error: 'No valid email addresses found' });
      }

      const { data, error } = await supabase.from('mp_recipients').insert(rows).select();
      if (error) throw error;

      await supabase
        .from('mp_campaigns')
        .update({
          recipient_count: rows.length,
          updated_at: new Date().toISOString(),
        })
        .eq('id', campaign_id);

      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, ...updates } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });

      const allowed = ['name', 'company', 'status', 'sent_at', 'open_count', 'click_count', 'last_opened_at'];
      const payload = {};
      for (const key of allowed) {
        if (updates[key] !== undefined) payload[key] = updates[key];
      }

      const { data, error } = await supabase
        .from('mp_recipients')
        .update(payload)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      await supabase.from('mp_tracking_events').delete().eq('recipient_id', id);
      const { error } = await supabase.from('mp_recipients').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('recipients API error:', err);
    if (req.method === 'GET') return res.status(200).json(req.query?.id ? null : []);
    if (!res.headersSent) {
      return res.status(500).json({ error: err?.message || 'Recipients error', ok: false });
    }
  }
}
