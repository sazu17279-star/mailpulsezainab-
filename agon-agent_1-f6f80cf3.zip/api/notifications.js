import supabase, { isDbConfigured } from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, DELETE, OPTIONS');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'Content-Type, Authorization, X-MailPulse-Extension, X-Requested-With'
  );
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      if (!isDbConfigured || supabase.__fallback) {
        return res.status(200).json([]);
      }
      const { unread_only } = req.query;
      let q = supabase
        .from('mp_notifications')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);
      if (unread_only === 'true') q = q.eq('read', false);
      const { data, error } = await q;
      if (error) {
        console.error('notifications list:', error.message);
        return res.status(200).json([]);
      }
      return res.status(200).json(data || []);
    }

    if (req.method === 'PUT') {
      const { id, mark_all } = req.body || {};
      if (mark_all) {
        const { error } = await supabase
          .from('mp_notifications')
          .update({ read: true })
          .eq('read', false);
        if (error) throw error;
        return res.status(200).json({ ok: true });
      }
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { data, error } = await supabase
        .from('mp_notifications')
        .update({ read: true })
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('mp_notifications').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('notifications API error:', err);
    if (req.method === 'GET') return res.status(200).json([]);
    if (!res.headersSent) {
      return res.status(500).json({ error: err?.message || 'Notifications error', ok: false });
    }
  }
}
