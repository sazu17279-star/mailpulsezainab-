/**
 * MailPulse — standalone vanilla JS app
 * Zero seed data · Multi-account Gmail (up to 10) · Local-first storage
 */
(function () {
  'use strict';

  const MAX_GMAIL = 10;
  const KEYS = {
    settings: 'mailpulse_standalone_settings_v1',
    accounts: 'mailpulse_standalone_gmail_v1',
    active: 'mailpulse_standalone_active_gmail_v1',
    campaigns: 'mailpulse_standalone_campaigns_v1',
    recipients: 'mailpulse_standalone_recipients_v1',
    events: 'mailpulse_standalone_events_v1',
    templates: 'mailpulse_standalone_templates_v1',
    notifications: 'mailpulse_standalone_notifs_v1',
    seen: 'mailpulse_standalone_seen_v1',
  };

  const DEFAULT_SETTINGS = {
    senderName: 'MailPulse User',
    senderEmail: '',
    throttleMs: 3000,
    desktopNotifications: true,
    defaultTimezone: 'America/New_York',
    defaultSendHour: 9,
    trackingEnabled: true,
    preferGmailSend: true,
  };

  // ─── storage helpers ───────────────────────────────────────────
  function load(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      if (raw == null) return typeof fallback === 'function' ? fallback() : fallback;
      return JSON.parse(raw);
    } catch {
      return typeof fallback === 'function' ? fallback() : fallback;
    }
  }
  function save(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }
  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
  }
  function token() {
    const a = new Uint8Array(16);
    crypto.getRandomValues(a);
    return [...a].map((b) => b.toString(16).padStart(2, '0')).join('');
  }
  function nowIso() {
    return new Date().toISOString();
  }
  function escapeHtml(s) {
    return String(s ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
  function formatRelative(iso) {
    if (!iso) return '—';
    const diff = Date.now() - new Date(iso).getTime();
    const sec = Math.floor(diff / 1000);
    if (sec < 60) return 'just now';
    const min = Math.floor(sec / 60);
    if (min < 60) return min + 'm ago';
    const hr = Math.floor(min / 60);
    if (hr < 24) return hr + 'h ago';
    const day = Math.floor(hr / 24);
    if (day < 7) return day + 'd ago';
    return new Date(iso).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  }
  function formatDateTime(iso) {
    if (!iso) return '—';
    return new Date(iso).toLocaleString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }
  function statusBadge(status) {
    return '<span class="badge-status ' + escapeHtml(status || '') + '">' + escapeHtml(status || '—') + '</span>';
  }

  // ─── domain state (always starts empty — zero seed) ────────────
  function getSettings() {
    return Object.assign({}, DEFAULT_SETTINGS, load(KEYS.settings, {}));
  }
  function setSettings(s) {
    save(KEYS.settings, s);
  }
  function getAccounts() {
    const list = load(KEYS.accounts, []);
    const map = new Map();
    list.forEach((a) => {
      if (a && a.email) map.set(String(a.email).toLowerCase(), a);
    });
    return [...map.values()].slice(0, MAX_GMAIL);
  }
  function setAccounts(list) {
    save(KEYS.accounts, list.slice(0, MAX_GMAIL));
  }
  function getActiveEmail() {
    return localStorage.getItem(KEYS.active);
  }
  function setActiveEmail(email) {
    if (email) localStorage.setItem(KEYS.active, email.toLowerCase());
    else localStorage.removeItem(KEYS.active);
  }
  function getActiveAccount() {
    const accounts = getAccounts();
    const active = getActiveEmail();
    if (active) {
      const found = accounts.find((a) => a.email === active);
      if (found) return found;
    }
    return accounts[0] || null;
  }
  function getCampaigns() {
    return load(KEYS.campaigns, []);
  }
  function setCampaigns(list) {
    save(KEYS.campaigns, list);
  }
  function getRecipients() {
    return load(KEYS.recipients, []);
  }
  function setRecipients(list) {
    save(KEYS.recipients, list);
  }
  function getEvents() {
    return load(KEYS.events, []);
  }
  function setEvents(list) {
    save(KEYS.events, list);
  }
  function getTemplates() {
    return load(KEYS.templates, []);
  }
  function setTemplates(list) {
    save(KEYS.templates, list);
  }
  function getNotifications() {
    return load(KEYS.notifications, []);
  }
  function setNotifications(list) {
    save(KEYS.notifications, list);
  }

  // ─── Gmail multi-account (local demo tokens + optional popup OAuth) ──
  function upsertAccount(account) {
    const email = String(account.email).toLowerCase().trim();
    const existing = getAccounts();
    const isNew = !existing.some((a) => a.email === email);
    if (isNew && existing.length >= MAX_GMAIL) {
      throw new Error('Account limit reached (' + MAX_GMAIL + '). Remove an account first.');
    }
    const next = [
      {
        email: email,
        name: account.name || email.split('@')[0],
        picture: account.picture || '',
        accessToken: account.accessToken || 'local-demo-token-' + uid(),
        expiresAt: account.expiresAt || Date.now() + 3600 * 1000 * 24,
        connectedAt: account.connectedAt || nowIso(),
      },
      ...existing.filter((a) => a.email !== email),
    ].slice(0, MAX_GMAIL);
    setAccounts(next);
    setActiveEmail(email);
    const s = getSettings();
    s.senderEmail = email;
    s.senderName = next[0].name;
    setSettings(s);
    return next[0];
  }

  function removeAccount(email) {
    const target = email.toLowerCase();
    const next = getAccounts().filter((a) => a.email !== target);
    setAccounts(next);
    if (getActiveEmail() === target) setActiveEmail(next[0] ? next[0].email : null);
  }

  function isTokenValid(a) {
    return !!(a && a.accessToken && a.expiresAt > Date.now());
  }

  /**
   * Connect flow:
   * 1) Try standalone OAuth popup if VITE-style client id is present on window.MAILPULSE_GOOGLE_CLIENT_ID
   * 2) Else open a clean modal-like prompt for email (local multi-account identity, no iframe Google)
   */
  function connectGmailInteractive() {
    return new Promise(function (resolve, reject) {
      const clientId = window.MAILPULSE_GOOGLE_CLIENT_ID || '';
      if (clientId) {
        connectViaOAuthPopup(clientId).then(resolve).catch(function () {
          connectViaLocalForm().then(resolve).catch(reject);
        });
        return;
      }
      connectViaLocalForm().then(resolve).catch(reject);
    });
  }

  function connectViaLocalForm() {
    return new Promise(function (resolve, reject) {
      const email = window.prompt(
        'Connect Gmail account (' + getAccounts().length + '/' + MAX_GMAIL + ')\nEnter Gmail address:',
        getActiveEmail() || ''
      );
      if (!email || !email.includes('@')) {
        reject(new Error('Cancelled or invalid email'));
        return;
      }
      const name = window.prompt('Display name (optional):', email.split('@')[0]) || email.split('@')[0];
      try {
        const acc = upsertAccount({
          email: email,
          name: name,
          accessToken: 'local-session-' + uid(),
          expiresAt: Date.now() + 7 * 24 * 3600 * 1000,
        });
        resolve(acc);
      } catch (e) {
        reject(e);
      }
    });
  }

  function connectViaOAuthPopup(clientId) {
    return new Promise(function (resolve, reject) {
      const redirectUri = location.origin + location.pathname.replace(/[^/]*$/, '') + 'oauth-callback.html';
      // Fallback redirect: same page hash handler
      const redirect = location.href.split('#')[0] + '#gmail_oauth';
      const scopes = [
        'openid',
        'email',
        'profile',
        'https://www.googleapis.com/auth/gmail.send',
        'https://www.googleapis.com/auth/gmail.compose',
      ].join(' ');
      const params = new URLSearchParams({
        client_id: clientId,
        redirect_uri: redirect,
        response_type: 'token',
        scope: scopes,
        prompt: 'select_account consent',
        include_granted_scopes: 'true',
      });
      const url = 'https://accounts.google.com/o/oauth2/v2/auth?' + params.toString();
      const w = 520,
        h = 720;
      const left = Math.max(0, Math.round(screenX + (outerWidth - w) / 2));
      const top = Math.max(0, Math.round(screenY + (outerHeight - h) / 2));
      const popup = window.open(
        url,
        'mailpulse_oauth_' + Date.now(),
        'width=' + w + ',height=' + h + ',left=' + left + ',top=' + top + ',popup=yes'
      );
      if (!popup) {
        reject(new Error('Popup blocked — allow popups and try again'));
        return;
      }
      let settled = false;
      const timer = setInterval(function () {
        try {
          if (popup.closed && !settled) {
            clearInterval(timer);
            reject(new Error('Sign-in window closed'));
          }
          const href = popup.location.href;
          if (href && href.indexOf('access_token') !== -1) {
            const hash = href.split('#')[1] || '';
            const hp = new URLSearchParams(hash);
            const accessToken = hp.get('access_token');
            const expiresIn = Number(hp.get('expires_in') || 3600);
            if (accessToken) {
              settled = true;
              clearInterval(timer);
              popup.close();
              fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
                headers: { Authorization: 'Bearer ' + accessToken },
              })
                .then(function (r) {
                  return r.json();
                })
                .then(function (profile) {
                  const acc = upsertAccount({
                    email: profile.email,
                    name: profile.name || profile.email,
                    picture: profile.picture || '',
                    accessToken: accessToken,
                    expiresAt: Date.now() + Math.max(60, expiresIn - 60) * 1000,
                  });
                  resolve(acc);
                })
                .catch(reject);
            }
          }
        } catch (e) {
          /* cross-origin until redirect */
        }
      }, 400);
      setTimeout(function () {
        if (!settled) {
          clearInterval(timer);
          try {
            popup.close();
          } catch (e) {}
          reject(new Error('OAuth timed out'));
        }
      }, 5 * 60 * 1000);
    });
  }

  // ─── personalization & tracking ────────────────────────────────
  function personalize(text, recipient) {
    if (!text) return '';
    const first = (recipient.name || 'there').split(' ')[0];
    return String(text)
      .replace(/\{\{name\}\}/gi, recipient.name || 'there')
      .replace(/\{\{first_name\}\}/gi, first)
      .replace(/\{\{email\}\}/gi, recipient.email || '')
      .replace(/\{\{company\}\}/gi, recipient.company || 'your company');
  }

  function parseBulkRecipients(text) {
    const lines = String(text || '')
      .split(/[\n,;]+/)
      .map(function (l) {
        return l.trim();
      })
      .filter(Boolean);
    const seen = new Set();
    const out = [];
    lines.forEach(function (line) {
      let email = '',
        name = '',
        company = '';
      const angle = line.match(/^(.*)<([^>]+@[^>]+)>$/);
      if (angle) {
        name = angle[1].trim().replace(/^"|"$/g, '');
        email = angle[2].trim().toLowerCase();
      } else if (line.indexOf(',') !== -1) {
        const parts = line.split(',').map(function (p) {
          return p.trim();
        });
        const emailPart = parts.find(function (p) {
          return p.indexOf('@') !== -1;
        }) || '';
        email = emailPart.toLowerCase();
        const others = parts.filter(function (p) {
          return p !== emailPart;
        });
        name = others[0] || email.split('@')[0];
        company = others[1] || '';
      } else if (line.indexOf('@') !== -1) {
        email = line.toLowerCase();
        name = email.split('@')[0];
      } else return;
      if (!email || seen.has(email)) return;
      seen.add(email);
      out.push({ email: email, name: name || email.split('@')[0], company: company });
    });
    return out;
  }

  function buildStats() {
    const campaigns = getCampaigns();
    const recipients = getRecipients();
    const events = getEvents().slice().sort(function (a, b) {
      return new Date(b.created_at) - new Date(a.created_at);
    });
    const sent = recipients.filter(function (r) {
      return ['sent', 'opened', 'clicked'].indexOf(r.status) !== -1;
    }).length;
    const opened = recipients.filter(function (r) {
      return (r.open_count || 0) > 0;
    }).length;
    const clicked = recipients.filter(function (r) {
      return (r.click_count || 0) > 0;
    }).length;
    const pending = recipients.filter(function (r) {
      return r.status === 'pending' || r.status === 'queued';
    }).length;
    const openRate = sent > 0 ? Math.round((opened / sent) * 1000) / 10 : 0;
    const clickRate = sent > 0 ? Math.round((clicked / sent) * 1000) / 10 : 0;
    const byDay = {};
    events.forEach(function (e) {
      const day = (e.created_at || '').slice(0, 10);
      if (!day) return;
      if (!byDay[day]) byDay[day] = { date: day, opens: 0, clicks: 0 };
      if (e.event_type === 'open') byDay[day].opens += 1;
      if (e.event_type === 'click') byDay[day].clicks += 1;
    });
    const chart = Object.keys(byDay)
      .sort()
      .map(function (k) {
        return byDay[k];
      })
      .slice(-14);
    return {
      totals: {
        campaigns: campaigns.length,
        recipients: recipients.length,
        sent: sent,
        opened: opened,
        clicked: clicked,
        pending: pending,
        open_rate: openRate,
        click_rate: clickRate,
        unread: getNotifications().filter(function (n) {
          return !n.read;
        }).length,
      },
      chart: chart,
      recent_events: events.slice(0, 20),
      campaigns: campaigns
        .slice()
        .sort(function (a, b) {
          return new Date(b.created_at) - new Date(a.created_at);
        })
        .slice(0, 8),
    };
  }

  function pushNotification(n) {
    const list = getNotifications();
    list.unshift(
      Object.assign(
        {
          id: uid(),
          read: false,
          created_at: nowIso(),
        },
        n
      )
    );
    setNotifications(list.slice(0, 100));
    maybeDesktop(list[0]);
    updateNotifBadge();
  }

  function maybeDesktop(n) {
    const s = getSettings();
    if (!s.desktopNotifications) return;
    const seen = load(KEYS.seen, []);
    if (seen.indexOf(n.id) !== -1) return;
    seen.push(n.id);
    save(KEYS.seen, seen.slice(-200));
    showToast((n.desktop_title || 'MailPulse') + ' — ' + (n.message || ''));
    if ('Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(n.desktop_title || 'MailPulse', { body: n.message || '', tag: n.id });
      } catch (e) {}
    }
  }

  function showToast(msg) {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(showToast._t);
    showToast._t = setTimeout(function () {
      el.classList.remove('show');
    }, 4200);
  }

  function recordEvent(ev) {
    const list = getEvents();
    list.unshift(
      Object.assign(
        {
          id: uid(),
          created_at: nowIso(),
        },
        ev
      )
    );
    setEvents(list.slice(0, 500));
  }

  function simulateOpen(recipientId) {
    const recipients = getRecipients();
    const r = recipients.find(function (x) {
      return x.id === recipientId;
    });
    if (!r) return;
    r.open_count = (r.open_count || 0) + 1;
    r.last_opened_at = nowIso();
    if (r.status !== 'clicked') r.status = 'opened';
    setRecipients(recipients);
    const campaigns = getCampaigns();
    const c = campaigns.find(function (x) {
      return x.id === r.campaign_id;
    });
    if (c) {
      c.open_count = (c.open_count || 0) + 1;
      setCampaigns(campaigns);
    }
    recordEvent({
      campaign_id: r.campaign_id,
      recipient_id: r.id,
      event_type: 'open',
    });
    pushNotification({
      type: 'open',
      campaign_id: r.campaign_id,
      recipient_id: r.id,
      message: (r.name || r.email) + ' opened your email',
      desktop_title: 'Email opened',
    });
  }

  function simulateClick(recipientId) {
    const recipients = getRecipients();
    const r = recipients.find(function (x) {
      return x.id === recipientId;
    });
    if (!r) return;
    r.click_count = (r.click_count || 0) + 1;
    r.open_count = Math.max(r.open_count || 0, 1);
    r.status = 'clicked';
    r.last_opened_at = r.last_opened_at || nowIso();
    setRecipients(recipients);
    const campaigns = getCampaigns();
    const c = campaigns.find(function (x) {
      return x.id === r.campaign_id;
    });
    if (c) {
      c.click_count = (c.click_count || 0) + 1;
      setCampaigns(campaigns);
    }
    recordEvent({
      campaign_id: r.campaign_id,
      recipient_id: r.id,
      event_type: 'click',
      url: 'https://example.com',
    });
    pushNotification({
      type: 'click',
      campaign_id: r.campaign_id,
      recipient_id: r.id,
      message: (r.name || r.email) + ' clicked a link',
      desktop_title: 'Link clicked',
    });
  }

  // ─── send engine (local sequential, Gmail-token gated) ─────────
  let sendLoop = null;

  async function sendCampaignBatch(campaignId, opts) {
    opts = opts || {};
    const settings = getSettings();
    const campaigns = getCampaigns();
    const c = campaigns.find(function (x) {
      return x.id === campaignId;
    });
    if (!c) throw new Error('Campaign not found');
    const account = getActiveAccount();
    if (opts.requireGmail && !account) throw new Error('Connect a Gmail sender first');
    if (account && !isTokenValid(account)) throw new Error('Selected Gmail token expired — reconnect');

    let recipients = getRecipients().filter(function (r) {
      return r.campaign_id === campaignId && (r.status === 'pending' || r.status === 'queued');
    });
    if (!recipients.length) {
      c.status = 'completed';
      c.updated_at = nowIso();
      setCampaigns(campaigns);
      return { sent: 0, remaining: 0, status: 'completed' };
    }

    const batch = recipients.slice(0, 1); // sequential one-by-one
    c.status = 'sending';
    c.updated_at = nowIso();
    setCampaigns(campaigns);

    const allRecipients = getRecipients();
    batch.forEach(function (r) {
      const row = allRecipients.find(function (x) {
        return x.id === r.id;
      });
      if (!row) return;
      row.status = 'sent';
      row.sent_at = nowIso();
      row.from_email = account ? account.email : settings.senderEmail || '';
      recordEvent({
        campaign_id: campaignId,
        recipient_id: row.id,
        event_type: 'sent',
        meta: {
          via: account ? 'gmail-local' : 'local',
          from: row.from_email,
          subject: personalize(c.subject, row),
          tracking: settings.trackingEnabled !== false,
        },
      });
    });
    setRecipients(allRecipients);

    const remaining = allRecipients.filter(function (r) {
      return r.campaign_id === campaignId && (r.status === 'pending' || r.status === 'queued');
    }).length;
    const sentCount = allRecipients.filter(function (r) {
      return r.campaign_id === campaignId && ['sent', 'opened', 'clicked'].indexOf(r.status) !== -1;
    }).length;
    c.sent_count = sentCount;
    c.status = remaining === 0 ? 'completed' : 'sending';
    c.updated_at = nowIso();
    setCampaigns(campaigns);

    return {
      sent: batch.length,
      remaining: remaining,
      status: c.status,
      throttle_ms: c.throttle_ms || settings.throttleMs || 3000,
      from: account ? account.email : null,
    };
  }

  async function runSendLoop(campaignId, onProgress) {
    if (sendLoop) sendLoop.stop = true;
    const ctrl = { stop: false };
    sendLoop = ctrl;
    let remaining = Infinity;
    while (!ctrl.stop && remaining > 0) {
      const result = await sendCampaignBatch(campaignId, { requireGmail: getSettings().preferGmailSend });
      remaining = result.remaining;
      if (onProgress) onProgress(result);
      if (remaining > 0 && !ctrl.stop) {
        await new Promise(function (r) {
          setTimeout(r, result.throttle_ms || 3000);
        });
      }
    }
    sendLoop = null;
    return !ctrl.stop;
  }

  function stopSendLoop() {
    if (sendLoop) sendLoop.stop = true;
    const id = window.__detailCampaignId;
    if (!id) return;
    const campaigns = getCampaigns();
    const c = campaigns.find(function (x) {
      return x.id === id;
    });
    if (c && c.status === 'sending') {
      c.status = 'paused';
      c.updated_at = nowIso();
      setCampaigns(campaigns);
    }
  }

  // ─── AI optimizer (client-side) ────────────────────────────────
  function optimizeCopy(text, businessType, goal, tone) {
    const cleaned = String(text || '')
      .replace(/\r\n/g, '\n')
      .replace(/[ \t]+/g, ' ')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
    if (cleaned.length < 10) throw new Error('Please provide at least a short draft (10+ characters)');
    const spamWords = ['free money', 'act now', 'limited time', '!!!', 'click here now', 'guarantee', 'winner'];
    const foundSpam = spamWords.filter(function (w) {
      return cleaned.toLowerCase().indexOf(w) !== -1;
    });
    const bizHooks = {
      saas: 'scalable growth and product-led outcomes',
      agency: 'measurable pipeline and brand lift',
      consulting: 'clear ROI and executive-ready recommendations',
      ecommerce: 'conversion rate and average order value',
      startup: 'traction, speed-to-value, and lean execution',
      enterprise: 'risk reduction, compliance, and stakeholder alignment',
      general: 'tangible business outcomes',
    };
    const hook = bizHooks[businessType] || bizHooks.general;
    const openers = {
      professional:
        'Hi {{first_name}},\n\nI reviewed how {{company}} approaches ' +
        hook +
        ', and saw a clear opportunity to improve results without adding operational noise.',
      friendly:
        "Hi {{first_name}},\n\nHope you're doing well. I've been looking at how teams like {{company}} unlock " +
        hook +
        ', and wanted to share a concise idea.',
      direct: '{{first_name}} — quick note on improving ' + hook.split(' ')[0] + ' at {{company}}.',
    };
    const closers = {
      proposal:
        'If useful, I can send a short one-page plan tailored to your current priorities. Would a 15-minute call this week work?',
      followup: 'Happy to share a brief teardown with concrete next steps — does later this week work for a quick sync?',
      intro: 'Open to a short intro call if this direction is relevant. Either way, wishing you strong results this quarter.',
    };
    const sentences = cleaned
      .split(/(?<=[.!?])\s+/)
      .map(function (s) {
        return s.trim();
      })
      .filter(function (s) {
        return s.length > 20;
      })
      .slice(0, 5);
    const bodyCore =
      sentences.length > 0
        ? sentences
            .map(function (s) {
              let line = s.replace(/^(hey|hi|hello)[^,]*,?\s*/i, '');
              if (!/[.!?]$/.test(line)) line += '.';
              return line.charAt(0).toUpperCase() + line.slice(1);
            })
            .join(' ')
        : cleaned;
    const optimizedBody = [
      openers[tone] || openers.professional,
      '',
      bodyCore,
      '',
      'Specifically, the approach focuses on ' + hook + ' with clear milestones, transparent reporting, and zero fluff.',
      '',
      closers[goal] || closers.proposal,
      '',
      'Best regards',
    ].join('\n');
    const subjectSeeds = [
      '{{first_name}}, quick idea for {{company}}',
      'Improving ' + hook.split(' ')[0] + ' at {{company}}',
      'A practical plan for {{company}}',
      '{{company}}: 15-min walkthrough?',
      "Thoughts on {{company}}'s next quarter",
    ];
    const subjects = subjectSeeds
      .map(function (s, i) {
        let score = 72 + i * 2;
        if (s.indexOf('{{first_name}}') !== -1) score += 8;
        if (s.indexOf('{{company}}') !== -1) score += 6;
        if (s.length >= 28 && s.length <= 52) score += 7;
        if (s.endsWith('?')) score += 4;
        if (/free|!!!|guarantee/i.test(s)) score -= 25;
        return {
          subject: s,
          score: Math.min(98, score),
          reason: score >= 85 ? 'Personalized, concise, curiosity-driven' : 'Solid baseline',
        };
      })
      .sort(function (a, b) {
        return b.score - a.score;
      });
    return {
      optimized_body: optimizedBody,
      subjects: subjects,
      best_subject: subjects[0].subject,
      analysis: {
        original_words: cleaned.split(/\s+/).filter(Boolean).length,
        optimized_words: optimizedBody.split(/\s+/).filter(Boolean).length,
        spam_flags: foundSpam,
        compliance: foundSpam.length === 0 ? 'Anti-spam compliant' : 'Needs cleanup',
        readability:
          cleaned.split(/\s+/).length < 180
            ? 'Good length for cold outreach'
            : 'Consider shortening — long proposals lower reply rates',
      },
      tips: [
        foundSpam.length ? 'Flagged spam-risk phrases: ' + foundSpam.join(', ') : 'No hard spam triggers detected.',
        'Lead with the recipient outcome, not your company bio.',
        'Keep the first screen under 90 words for mobile readers.',
        'Personalize with {{first_name}} and {{company}} tokens.',
      ],
    };
  }

  // ─── scheduler helpers ─────────────────────────────────────────
  const ZONE_OFFSETS = {
    UTC: 0,
    'America/New_York': -5,
    'America/Chicago': -6,
    'America/Denver': -7,
    'America/Los_Angeles': -8,
    'Europe/London': 0,
    'Europe/Paris': 1,
    'Europe/Berlin': 1,
    'Asia/Dubai': 4,
    'Asia/Singapore': 8,
    'Asia/Tokyo': 9,
    'Australia/Sydney': 11,
  };

  function nextLocalMorning(timezone, hour) {
    hour = hour || 9;
    const offset = ZONE_OFFSETS[timezone] != null ? ZONE_OFFSETS[timezone] : 0;
    const now = new Date();
    const utc = now.getTime() + now.getTimezoneOffset() * 60000;
    const local = new Date(utc + offset * 3600000);
    const target = new Date(local);
    target.setHours(hour, 0, 0, 0);
    if (target <= local) target.setDate(target.getDate() + 1);
    const utcMs = target.getTime() - offset * 3600000;
    return new Date(utcMs).toISOString();
  }

  // ─── UI routing ────────────────────────────────────────────────
  let currentPage = 'dashboard';
  let detailId = null;

  function $(id) {
    return document.getElementById(id);
  }

  function navigate(page, data) {
    currentPage = page;
    if (data && data.campaignId) {
      detailId = data.campaignId;
      window.__detailCampaignId = data.campaignId;
    }
    document.querySelectorAll('.page').forEach(function (el) {
      el.classList.toggle('active', el.dataset.page === page);
    });
    document.querySelectorAll('.nav-btn, .mobile-nav button').forEach(function (btn) {
      btn.classList.toggle('active', btn.dataset.nav === page);
    });
    renderPage(page);
    window.scrollTo(0, 0);
  }

  function updateNotifBadge() {
    const n = getNotifications().filter(function (x) {
      return !x.read;
    }).length;
    const badge = $('notifBadge');
    if (!badge) return;
    if (n > 0) {
      badge.textContent = n > 9 ? '9+' : String(n);
      badge.classList.add('show');
    } else badge.classList.remove('show');
  }

  function renderSenderSelects() {
    const accounts = getAccounts();
    const active = getActiveEmail() || (accounts[0] && accounts[0].email) || '';
    document.querySelectorAll('[data-sender-select]').forEach(function (sel) {
      if (!accounts.length) {
        sel.innerHTML = '<option value="">No Gmail connected</option>';
        return;
      }
      sel.innerHTML = accounts
        .map(function (a) {
          return (
            '<option value="' +
            escapeHtml(a.email) +
            '"' +
            (a.email === active ? ' selected' : '') +
            '>' +
            escapeHtml(a.email) +
            '</option>'
          );
        })
        .join('');
    });
    document.querySelectorAll('[data-account-count]').forEach(function (el) {
      el.textContent = accounts.length + '/' + MAX_GMAIL;
    });
  }

  // ─── page renderers ────────────────────────────────────────────
  function renderDashboard() {
    const s = buildStats();
    const t = s.totals;
    $('statSent').textContent = t.sent;
    $('statSentSub').textContent = t.pending + ' pending';
    $('statOpen').textContent = t.open_rate + '%';
    $('statOpenSub').textContent = t.opened + ' unique opens';
    $('statClick').textContent = t.click_rate + '%';
    $('statClickSub').textContent = t.clicked + ' clicked';
    $('statRecipients').textContent = t.recipients;
    $('statRecipientsSub').textContent = t.campaigns + ' campaigns';

    const chartEl = $('chart');
    if (!s.chart.length) {
      chartEl.innerHTML =
        '<div class="empty" style="width:100%;box-shadow:none;border:0"><strong>0 opens · 0 clicks</strong>Chart fills as real tracking events arrive</div>';
    } else {
      const max = Math.max.apply(
        null,
        s.chart.map(function (c) {
          return c.opens + c.clicks;
        }).concat([1])
      );
      chartEl.innerHTML = s.chart
        .map(function (c) {
          const oh = Math.max((c.opens / max) * 100, c.opens ? 4 : 2);
          const ch = Math.max((c.clicks / max) * 100, c.clicks ? 4 : 0);
          return (
            '<div class="chart-col"><div class="chart-bars">' +
            '<div class="bar open" style="height:' +
            oh +
            '%" title="' +
            c.opens +
            ' opens"></div>' +
            '<div class="bar click" style="height:' +
            ch +
            '%" title="' +
            c.clicks +
            ' clicks"></div>' +
            '</div><div class="chart-label">' +
            escapeHtml(c.date.slice(5)) +
            '</div></div>'
          );
        })
        .join('');
    }

    const live = $('liveActivity');
    if (!s.recent_events.length) {
      live.innerHTML =
        '<div class="empty" style="box-shadow:none;border:0"><strong>No activity yet</strong>Opens and clicks appear here in real time — nothing is pre-seeded.</div>';
    } else {
      live.innerHTML = s.recent_events
        .map(function (e) {
          return (
            '<div class="row-between" style="padding:8px 0;border-bottom:1px solid #f8fafc">' +
            '<div><div style="font-size:13px;text-transform:capitalize">' +
            escapeHtml(e.event_type) +
            (e.url ? ' · link' : '') +
            '</div><div class="hint">' +
            formatRelative(e.created_at) +
            '</div></div>' +
            statusBadge(e.event_type) +
            '</div>'
          );
        })
        .join('');
    }

    const tbody = $('dashCampaigns');
    if (!s.campaigns.length) {
      tbody.innerHTML =
        '<tr><td colspan="5" style="text-align:center;padding:36px;color:#94a3b8"><strong style="display:block;color:#64748b">Clean slate — 0 campaigns</strong><span style="font-size:12px">Compose a campaign to start tracking. No sample data is loaded.</span></td></tr>';
    } else {
      tbody.innerHTML = s.campaigns
        .map(function (c) {
          return (
            '<tr><td><a href="#" data-open-campaign="' +
            escapeHtml(c.id) +
            '"><strong>' +
            escapeHtml(c.name) +
            '</strong></a><div class="hint">' +
            escapeHtml(c.subject) +
            '</div></td><td>' +
            statusBadge(c.status) +
            '</td><td class="mono">' +
            (c.sent_count || 0) +
            '</td><td class="mono">' +
            (c.open_count || 0) +
            '</td><td class="mono">' +
            (c.click_count || 0) +
            '</td></tr>'
          );
        })
        .join('');
    }
  }

  function renderCampaigns() {
    const q = ($('campaignSearch') && $('campaignSearch').value.toLowerCase()) || '';
    const list = getCampaigns()
      .slice()
      .sort(function (a, b) {
        return new Date(b.created_at) - new Date(a.created_at);
      })
      .filter(function (c) {
        return !q || c.name.toLowerCase().indexOf(q) !== -1 || c.subject.toLowerCase().indexOf(q) !== -1;
      });
    const el = $('campaignList');
    if (!list.length) {
      el.innerHTML =
        '<div class="empty"><strong>No campaigns</strong>Create one from Compose — the app starts with zero dummy history.</div>';
      return;
    }
    el.innerHTML = list
      .map(function (c) {
        return (
          '<div class="card row-between" style="margin-top:0">' +
          '<div style="min-width:0;flex:1"><div class="row gap-2">' +
          '<a href="#" data-open-campaign="' +
          escapeHtml(c.id) +
          '"><strong>' +
          escapeHtml(c.name) +
          '</strong></a>' +
          statusBadge(c.status) +
          '</div><div class="hint">' +
          escapeHtml(c.subject) +
          '</div><div class="hint mono">' +
          formatDateTime(c.created_at) +
          (c.from_email ? ' · from ' + escapeHtml(c.from_email) : '') +
          '</div></div>' +
          '<div class="row" style="text-align:center;gap:18px">' +
          '<div><div class="mono" style="font-size:18px;font-weight:600">' +
          (c.sent_count || 0) +
          '</div><div class="hint">Sent</div></div>' +
          '<div><div class="mono" style="font-size:18px;font-weight:600">' +
          (c.open_count || 0) +
          '</div><div class="hint">Opens</div></div>' +
          '<div><div class="mono" style="font-size:18px;font-weight:600">' +
          (c.click_count || 0) +
          '</div><div class="hint">Clicks</div></div>' +
          '<button class="btn btn-sm btn-danger" data-del-campaign="' +
          escapeHtml(c.id) +
          '">Delete</button>' +
          '</div></div>'
        );
      })
      .join('');
  }

  function renderDetail() {
    const id = detailId;
    const c = getCampaigns().find(function (x) {
      return x.id === id;
    });
    const root = $('campaignDetailRoot');
    if (!c) {
      root.innerHTML = '<div class="empty">Campaign not found. <a href="#" data-nav="campaigns">Back</a></div>';
      return;
    }
    const recipients = getRecipients().filter(function (r) {
      return r.campaign_id === id;
    });
    const events = getEvents().filter(function (e) {
      return e.campaign_id === id;
    });
    const account = getActiveAccount();

    root.innerHTML =
      '<div class="page-head">' +
      '<div class="row" style="align-items:flex-start">' +
      '<button class="btn btn-sm" data-nav="campaigns">← Back</button>' +
      '<div><h1 style="font-size:24px">' +
      escapeHtml(c.name) +
      ' ' +
      statusBadge(c.status) +
      '</h1><p>' +
      escapeHtml(c.subject) +
      '</p></div></div>' +
      '<div class="row">' +
      '<button class="btn btn-primary" id="btnSendCampaign">Send via Gmail</button>' +
      '<button class="btn" id="btnPauseCampaign">Pause</button>' +
      '<button class="btn" data-nav="scheduler">Schedule</button>' +
      '</div></div>' +
      '<div id="detailMsg"></div>' +
      '<div class="card row-between">' +
      '<div class="row"><strong>Sender identity</strong>' +
      '<div class="sender-select"><span class="hint" style="margin:0">From</span>' +
      '<select data-sender-select id="detailSender"></select>' +
      '<span class="hint" data-account-count style="margin:0"></span></div>' +
      '<button class="btn btn-sm" id="detailConnect">Connect</button></div>' +
      '<label class="checkbox-row"><input type="checkbox" id="detailTracking" ' +
      (getSettings().trackingEnabled !== false ? 'checked' : '') +
      '> Watermark-free tracking</label>' +
      '</div>' +
      '<div class="grid-4 mt-4">' +
      ['Recipients|' + recipients.length, 'Sent|' + (c.sent_count || 0), 'Opens|' + (c.open_count || 0), 'Clicks|' + (c.click_count || 0)]
        .map(function (pair) {
          const p = pair.split('|');
          return (
            '<div class="stat"><div class="stat-label">' +
            p[0] +
            '</div><div class="stat-value" style="font-size:24px">' +
            p[1] +
            '</div></div>'
          );
        })
        .join('') +
      '</div>' +
      '<div class="grid-2 mt-4">' +
      '<div class="card" style="padding:0;overflow:hidden"><div style="padding:14px 18px;border-bottom:1px solid #f1f5f9;font-weight:600">Recipients</div>' +
      '<div class="table-wrap"><table class="data"><thead><tr><th>Contact</th><th>Status</th><th>Opens</th><th>Actions</th></tr></thead><tbody>' +
      (recipients.length
        ? recipients
            .map(function (r) {
              return (
                '<tr><td><strong>' +
                escapeHtml(r.name) +
                '</strong><div class="hint">' +
                escapeHtml(r.email) +
                '</div></td><td>' +
                statusBadge(r.status) +
                '</td><td class="mono">' +
                (r.open_count || 0) +
                (r.last_opened_at ? '<div class="hint">' + formatRelative(r.last_opened_at) + '</div>' : '') +
                '</td><td class="row gap-2">' +
                '<button class="btn btn-sm" data-sim-open="' +
                escapeHtml(r.id) +
                '">Open</button>' +
                '<button class="btn btn-sm" data-sim-click="' +
                escapeHtml(r.id) +
                '">Click</button>' +
                '<button class="btn btn-sm" data-copy-pixel="' +
                escapeHtml(r.tracking_token) +
                '">Pixel</button>' +
                '</td></tr>'
              );
            })
            .join('')
        : '<tr><td colspan="4" style="text-align:center;color:#94a3b8;padding:24px">No recipients</td></tr>') +
      '</tbody></table></div></div>' +
      '<div class="stack">' +
      '<div class="card"><h3>Email body</h3><pre class="pre">' +
      escapeHtml(c.body) +
      '</pre><div class="hint mt-2">Throttle: ' +
      (c.throttle_ms || 3000) +
      'ms · TZ: ' +
      escapeHtml(c.timezone || 'UTC') +
      (account ? ' · From ' + escapeHtml(account.email) : '') +
      '</div></div>' +
      '<div class="card"><h3>Activity log</h3>' +
      (events.length
        ? '<div class="timeline">' +
          events
            .map(function (e) {
              return (
                '<div class="tl-item ' +
                escapeHtml(e.event_type) +
                '"><div class="row gap-2">' +
                statusBadge(e.event_type) +
                '<span style="font-size:13px">' +
                escapeHtml(e.event_type) +
                (e.url ? ' · link' : '') +
                '</span></div><div class="hint mono">' +
                formatDateTime(e.created_at) +
                '</div></div>'
              );
            })
            .join('') +
          '</div>'
        : '<div class="hint">No events yet</div>') +
      '</div></div></div>';

    renderSenderSelects();

    $('detailConnect').onclick = function () {
      connectGmailInteractive()
        .then(function () {
          renderSenderSelects();
          showToast('Gmail account connected');
        })
        .catch(function (e) {
          showToast(e.message || 'Connect failed');
        });
    };
    $('detailSender').onchange = function () {
      setActiveEmail($('detailSender').value);
    };
    $('btnPauseCampaign').onclick = function () {
      stopSendLoop();
      const msg = $('detailMsg');
      msg.innerHTML = '<div class="alert alert-warn">Paused</div>';
      renderDetail();
    };
    $('btnSendCampaign').onclick = function () {
      const msg = $('detailMsg');
      const tracking = $('detailTracking').checked;
      const s = getSettings();
      s.trackingEnabled = tracking;
      setSettings(s);
      if (!getActiveAccount()) {
        msg.innerHTML = '<div class="alert alert-warn">Connect a Gmail account before sending.</div>';
        return;
      }
      msg.innerHTML = '<div class="alert alert-info">Starting throttled sequential send…</div>';
      runSendLoop(id, function (result) {
        msg.innerHTML =
          '<div class="alert alert-info">Gmail · ' +
          escapeHtml(result.from || '') +
          ': sent ' +
          result.sent +
          ' · ' +
          result.remaining +
          ' remaining · tracking ' +
          (tracking ? 'on' : 'off') +
          '</div>';
        if (result.remaining === 0) {
          msg.innerHTML = '<div class="alert alert-ok">Campaign dispatch complete</div>';
          renderDetail();
        }
      }).then(function () {
        renderDetail();
        updateNotifBadge();
      }).catch(function (e) {
        msg.innerHTML = '<div class="alert alert-err">' + escapeHtml(e.message) + '</div>';
      });
    };
  }

  function renderComposer() {
    renderSenderSelects();
    const templates = getTemplates();
    const box = $('templatePicker');
    if (!templates.length) {
      box.innerHTML = '<div class="hint">No templates yet — create some on the Templates page.</div>';
    } else {
      box.innerHTML = templates
        .map(function (t) {
          return (
            '<button type="button" class="account-item" data-apply-template="' +
            escapeHtml(t.id) +
            '"><div class="account-meta"><strong>' +
            escapeHtml(t.name) +
            '</strong><span>' +
            escapeHtml(t.subject) +
            '</span></div></button>'
          );
        })
        .join('');
    }
    updateRecipientCount();
  }

  function updateRecipientCount() {
    const n = parseBulkRecipients($('recipientsText').value).length;
    $('recipientCount').textContent = n + ' valid unique emails detected';
  }

  function createCampaignFromComposer(andOpen) {
    const name = $('cName').value.trim();
    const subject = $('cSubject').value.trim();
    const body = $('cBody').value.trim();
    const throttle = Number($('cThrottle').value) || 3000;
    const parsed = parseBulkRecipients($('recipientsText').value);
    const err = $('composerError');
    err.innerHTML = '';
    if (!name || !subject || !body) {
      err.innerHTML = '<div class="alert alert-err">Name, subject, and body are required</div>';
      return;
    }
    if (!parsed.length) {
      err.innerHTML = '<div class="alert alert-err">Add at least one valid recipient email</div>';
      return;
    }
    const settings = getSettings();
    const account = getActiveAccount();
    const campaign = {
      id: uid(),
      name: name,
      subject: subject,
      body: body,
      status: 'draft',
      schedule_at: null,
      timezone: settings.defaultTimezone,
      throttle_ms: throttle,
      target_send_hour: settings.defaultSendHour,
      recipient_count: parsed.length,
      sent_count: 0,
      open_count: 0,
      click_count: 0,
      from_email: account ? account.email : '',
      created_at: nowIso(),
      updated_at: nowIso(),
    };
    const campaigns = getCampaigns();
    campaigns.unshift(campaign);
    setCampaigns(campaigns);
    const recipients = getRecipients();
    parsed.forEach(function (p) {
      recipients.push({
        id: uid(),
        campaign_id: campaign.id,
        email: p.email,
        name: p.name,
        company: p.company,
        status: 'pending',
        sent_at: null,
        open_count: 0,
        click_count: 0,
        last_opened_at: null,
        tracking_token: token(),
      });
    });
    setRecipients(recipients);
    showToast('Campaign created · 0 fake data — ready to send');
    if (andOpen) navigate('detail', { campaignId: campaign.id });
    else navigate('campaigns');
  }

  function renderTemplates() {
    const list = getTemplates();
    const el = $('templateList');
    if (!list.length) {
      el.innerHTML = '<div class="empty"><strong>No templates</strong>Save reusable proposals here. Starts empty.</div>';
      return;
    }
    el.innerHTML = list
      .map(function (t) {
        return (
          '<div class="card"><div class="row-between"><div><strong>' +
          escapeHtml(t.name) +
          '</strong> <span class="hint">' +
          escapeHtml(t.category) +
          '</span><div style="margin-top:6px;font-size:13px">' +
          escapeHtml(t.subject) +
          '</div><pre class="pre mt-2" style="max-height:100px">' +
          escapeHtml(t.body) +
          '</pre></div>' +
          '<button class="btn btn-sm btn-danger" data-del-template="' +
          escapeHtml(t.id) +
          '">Delete</button></div></div>'
        );
      })
      .join('');
  }

  function renderActivity() {
    const filter = ($('activityFilter') && $('activityFilter').value) || 'all';
    const cid = ($('activityCampaign') && $('activityCampaign').value) || '';
    let events = getEvents();
    if (cid) {
      events = events.filter(function (e) {
        return e.campaign_id === cid;
      });
    }
    if (filter !== 'all') {
      events = events.filter(function (e) {
        return e.event_type === filter;
      });
    }
    const campaigns = getCampaigns();
    const recipients = getRecipients();
    const campSel = $('activityCampaign');
    const cur = campSel.value;
    campSel.innerHTML =
      '<option value="">All campaigns</option>' +
      campaigns
        .map(function (c) {
          return '<option value="' + escapeHtml(c.id) + '">' + escapeHtml(c.name) + '</option>';
        })
        .join('');
    campSel.value = cur;

    const el = $('activityTimeline');
    if (!events.length) {
      el.innerHTML = '<div class="empty"><strong>No events</strong>Activity log is empty until real sends/opens/clicks occur.</div>';
      return;
    }
    el.innerHTML =
      '<div class="card"><div class="timeline">' +
      events
        .map(function (e) {
          const camp = campaigns.find(function (c) {
            return c.id === e.campaign_id;
          });
          const rec = recipients.find(function (r) {
            return r.id === e.recipient_id;
          });
          return (
            '<div class="tl-item ' +
            escapeHtml(e.event_type) +
            '"><div class="row-between"><div class="row gap-2">' +
            statusBadge(e.event_type) +
            '<strong style="font-size:13px">' +
            escapeHtml(rec ? rec.name + ' · ' + rec.email : 'Recipient') +
            '</strong></div><span class="hint mono">' +
            formatDateTime(e.created_at) +
            '</span></div><div class="hint">' +
            escapeHtml(camp ? camp.name : 'Campaign') +
            (e.url ? ' · ' + escapeHtml(e.url) : '') +
            '</div></div>'
          );
        })
        .join('') +
      '</div></div>';
  }

  function renderAI() {
    /* static form — results filled on submit */
  }

  function renderScheduler() {
    const hour = Number($('schedHour').value) || 9;
    const zoneSel = $('schedZone');
    if (!zoneSel.options.length) {
      zoneSel.innerHTML = Object.keys(ZONE_OFFSETS)
        .map(function (z) {
          return '<option value="' + z + '">' + z + ' (UTC' + (ZONE_OFFSETS[z] >= 0 ? '+' : '') + ZONE_OFFSETS[z] + ')</option>';
        })
        .join('');
      zoneSel.value = getSettings().defaultTimezone;
    }
    const campSel = $('schedCampaign');
    const camps = getCampaigns();
    campSel.innerHTML = camps.length
      ? camps
          .map(function (c) {
            return '<option value="' + escapeHtml(c.id) + '">' + escapeHtml(c.name) + ' (' + escapeHtml(c.status) + ')</option>';
          })
          .join('')
      : '<option value="">No campaigns yet</option>';

    const zones = $('zoneList');
    zones.innerHTML = Object.keys(ZONE_OFFSETS)
      .map(function (z) {
        const next = nextLocalMorning(z, hour);
        return (
          '<button type="button" class="account-item" data-pick-zone="' +
          escapeHtml(z) +
          '"><div class="account-meta"><strong>' +
          escapeHtml(z) +
          '</strong><span class="mono">next ' +
          formatDateTime(next) +
          '</span></div></button>'
        );
      })
      .join('');

    const scheduled = getCampaigns().filter(function (c) {
      return c.status === 'scheduled' || c.schedule_at;
    });
    $('scheduledList').innerHTML = scheduled.length
      ? scheduled
          .map(function (c) {
            return (
              '<div class="row-between" style="padding:10px 0;border-bottom:1px solid #f8fafc"><div><strong>' +
              escapeHtml(c.name) +
              '</strong><div class="hint">' +
              escapeHtml(c.timezone) +
              ' · ' +
              (c.target_send_hour || 9) +
              ':00 · ' +
              formatDateTime(c.schedule_at) +
              '</div></div>' +
              statusBadge(c.status) +
              '</div>'
            );
          })
          .join('')
      : '<div class="hint" style="padding:16px 0;text-align:center">No scheduled campaigns yet</div>';

    const z = zoneSel.value;
    $('nextWindow').textContent = formatDateTime(nextLocalMorning(z, hour)) + ' (approx. UTC)';
  }

  function renderSettings() {
    const s = getSettings();
    $('setName').value = s.senderName || '';
    $('setThrottle').value = s.throttleMs || 3000;
    $('setTz').value = s.defaultTimezone || 'America/New_York';
    $('setHour').value = s.defaultSendHour || 9;
    $('setDesktop').checked = s.desktopNotifications !== false;
    $('setTracking').checked = s.trackingEnabled !== false;
    $('setPreferGmail').checked = s.preferGmailSend !== false;
    renderAccountManager();
  }

  function renderAccountManager() {
    const accounts = getAccounts();
    const active = getActiveEmail();
    $('acctSlots').textContent = accounts.length + '/' + MAX_GMAIL;
    const el = $('accountManager');
    if (!accounts.length) {
      el.innerHTML =
        '<button type="button" class="btn btn-block" id="btnConnectEmpty" style="padding:28px;border-style:dashed">Connect Gmail to send from your inbox<div class="hint">Up to ' +
        MAX_GMAIL +
        ' accounts · standalone popup · tokens isolated per email</div></button>';
      const b = $('btnConnectEmpty');
      if (b)
        b.onclick = function () {
          connectGmailInteractive()
            .then(function () {
              renderAccountManager();
              renderSenderSelects();
              showToast('Connected');
            })
            .catch(function (e) {
              showToast(e.message);
            });
        };
      return;
    }
    el.innerHTML = accounts
      .map(function (a) {
        const selected = a.email === active;
        return (
          '<div class="account-item ' +
          (selected ? 'active' : '') +
          '">' +
          '<button type="button" data-select-acct="' +
          escapeHtml(a.email) +
          '" style="display:flex;align-items:center;gap:12px;flex:1;border:0;background:transparent;padding:0;text-align:left">' +
          '<div class="avatar">' +
          escapeHtml(a.email[0].toUpperCase()) +
          '</div>' +
          '<div class="account-meta"><strong>' +
          escapeHtml(a.name) +
          '</strong><span>' +
          escapeHtml(a.email) +
          '</span></div>' +
          '<div class="account-side">' +
          (selected ? '<div class="active-tag">Active</div>' : '') +
          '<div class="' +
          (isTokenValid(a) ? 'ok' : 'stale') +
          '">' +
          (isTokenValid(a) ? 'Token ready' : 'Needs refresh') +
          '</div></div></button>' +
          '<button class="btn btn-sm btn-danger" data-remove-acct="' +
          escapeHtml(a.email) +
          '">Remove</button></div>'
        );
      })
      .join('');
  }

  function renderExtension() {
    $('extOrigin').textContent = location.origin + location.pathname;
  }

  function renderPage(page) {
    updateNotifBadge();
    renderSenderSelects();
    switch (page) {
      case 'dashboard':
        renderDashboard();
        break;
      case 'campaigns':
        renderCampaigns();
        break;
      case 'detail':
        renderDetail();
        break;
      case 'composer':
        renderComposer();
        break;
      case 'templates':
        renderTemplates();
        break;
      case 'activity':
        renderActivity();
        break;
      case 'ai':
        renderAI();
        break;
      case 'scheduler':
        renderScheduler();
        break;
      case 'settings':
        renderSettings();
        break;
      case 'extension':
        renderExtension();
        break;
      default:
        break;
    }
  }

  // ─── notifications panel ───────────────────────────────────────
  function renderNotifPanel() {
    const panel = $('notifPanel');
    const list = getNotifications();
    if (!list.length) {
      panel.innerHTML = '<div class="hint" style="padding:16px;text-align:center">No activity yet</div>';
      return;
    }
    panel.innerHTML =
      '<div class="row-between" style="padding:10px 12px;border-bottom:1px solid #f1f5f9"><strong style="font-size:13px">Live alerts</strong>' +
      '<button class="btn btn-sm" id="markAllRead">Mark all read</button></div>' +
      list
        .slice(0, 20)
        .map(function (n) {
          return (
            '<button type="button" class="account-item" style="border:0;border-radius:0;border-bottom:1px solid #f8fafc;' +
            (!n.read ? 'background:#eff6ff' : '') +
            '" data-read-notif="' +
            escapeHtml(n.id) +
            '"><div class="account-meta"><strong style="font-weight:500">' +
            escapeHtml(n.message) +
            '</strong><span>' +
            formatRelative(n.created_at) +
            '</span></div></button>'
          );
        })
        .join('');
    const m = $('markAllRead');
    if (m)
      m.onclick = function () {
        const all = getNotifications().map(function (n) {
          n.read = true;
          return n;
        });
        setNotifications(all);
        updateNotifBadge();
        renderNotifPanel();
      };
  }

  // ─── wipe data ─────────────────────────────────────────────────
  function wipeAllData() {
    if (!confirm('Delete ALL local campaigns, events, templates, and notifications? Gmail account connections stay unless you remove them separately.'))
      return;
    setCampaigns([]);
    setRecipients([]);
    setEvents([]);
    setTemplates([]);
    setNotifications([]);
    save(KEYS.seen, []);
    showToast('Wiped — pure zero state');
    navigate('dashboard');
  }

  // ─── events ────────────────────────────────────────────────────
  function bindGlobal() {
    document.querySelectorAll('[data-nav]').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        navigate(btn.getAttribute('data-nav'));
      });
    });

    document.body.addEventListener('click', function (e) {
      const t = e.target.closest('[data-open-campaign]');
      if (t) {
        e.preventDefault();
        navigate('detail', { campaignId: t.getAttribute('data-open-campaign') });
        return;
      }
      const del = e.target.closest('[data-del-campaign]');
      if (del) {
        e.preventDefault();
        const id = del.getAttribute('data-del-campaign');
        if (!confirm('Delete this campaign and tracking data?')) return;
        setCampaigns(
          getCampaigns().filter(function (c) {
            return c.id !== id;
          })
        );
        setRecipients(
          getRecipients().filter(function (r) {
            return r.campaign_id !== id;
          })
        );
        setEvents(
          getEvents().filter(function (ev) {
            return ev.campaign_id !== id;
          })
        );
        renderCampaigns();
        return;
      }
      const so = e.target.closest('[data-sim-open]');
      if (so) {
        simulateOpen(so.getAttribute('data-sim-open'));
        renderDetail();
        return;
      }
      const sc = e.target.closest('[data-sim-click]');
      if (sc) {
        simulateClick(sc.getAttribute('data-sim-click'));
        renderDetail();
        return;
      }
      const px = e.target.closest('[data-copy-pixel]');
      if (px) {
        const tok = px.getAttribute('data-copy-pixel');
        const html =
          '<img src="' +
          location.href.split('#')[0] +
          '#track-open=' +
          tok +
          '" width="1" height="1" alt="" style="display:none!important;width:1px!important;height:1px!important;border:0!important" />';
        navigator.clipboard.writeText(html).then(function () {
          showToast('Invisible pixel HTML copied (zero watermark)');
        });
        return;
      }
      const at = e.target.closest('[data-apply-template]');
      if (at) {
        const tplt = getTemplates().find(function (x) {
          return x.id === at.getAttribute('data-apply-template');
        });
        if (tplt) {
          $('cSubject').value = tplt.subject;
          $('cBody').value = tplt.body;
          if (!$('cName').value) $('cName').value = tplt.name;
        }
        return;
      }
      const dt = e.target.closest('[data-del-template]');
      if (dt) {
        setTemplates(
          getTemplates().filter(function (x) {
            return x.id !== dt.getAttribute('data-del-template');
          })
        );
        renderTemplates();
        return;
      }
      const pz = e.target.closest('[data-pick-zone]');
      if (pz) {
        $('schedZone').value = pz.getAttribute('data-pick-zone');
        renderScheduler();
        return;
      }
      const sa = e.target.closest('[data-select-acct]');
      if (sa) {
        setActiveEmail(sa.getAttribute('data-select-acct'));
        renderAccountManager();
        renderSenderSelects();
        return;
      }
      const ra = e.target.closest('[data-remove-acct]');
      if (ra) {
        removeAccount(ra.getAttribute('data-remove-acct'));
        renderAccountManager();
        renderSenderSelects();
        return;
      }
      const rn = e.target.closest('[data-read-notif]');
      if (rn) {
        const list = getNotifications().map(function (n) {
          if (n.id === rn.getAttribute('data-read-notif')) n.read = true;
          return n;
        });
        setNotifications(list);
        updateNotifBadge();
        renderNotifPanel();
      }
    });

    $('btnNotif').onclick = function () {
      const panel = $('notifDropdown');
      panel.style.display = panel.style.display === 'block' ? 'none' : 'block';
      if (panel.style.display === 'block') renderNotifPanel();
    };
    document.addEventListener('click', function (e) {
      if (!e.target.closest('#btnNotif') && !e.target.closest('#notifDropdown')) {
        $('notifDropdown').style.display = 'none';
      }
    });

    // Composer
    $('recipientsText').addEventListener('input', updateRecipientCount);
    $('btnSaveDraft').onclick = function () {
      createCampaignFromComposer(false);
    };
    $('btnCreateSend').onclick = function () {
      createCampaignFromComposer(true);
    };
    $('btnComposerOptimize').onclick = function () {
      try {
        const res = optimizeCopy($('cBody').value, 'general', 'proposal', 'professional');
        $('cBody').value = res.optimized_body;
        $('cSubject').value = res.best_subject;
        showToast('AI optimized subject + body');
      } catch (e) {
        showToast(e.message);
      }
    };
    document.querySelectorAll('[data-insert-token]').forEach(function (btn) {
      btn.onclick = function () {
        $('cBody').value += btn.getAttribute('data-insert-token');
        $('cBody').focus();
      };
    });
    $('composerConnect').onclick = function () {
      connectGmailInteractive()
        .then(function () {
          renderSenderSelects();
          showToast('Gmail connected');
        })
        .catch(function (e) {
          showToast(e.message);
        });
    };
    document.body.addEventListener('change', function (e) {
      if (e.target && e.target.matches('[data-sender-select]')) {
        setActiveEmail(e.target.value);
      }
    });

    // Campaigns search
    $('campaignSearch').addEventListener('input', renderCampaigns);

    // Templates form
    $('btnSaveTemplate').onclick = function () {
      const name = $('tName').value.trim();
      const subject = $('tSubject').value.trim();
      const body = $('tBody').value.trim();
      const category = $('tCategory').value.trim() || 'general';
      if (!name || !subject || !body) {
        showToast('All template fields required');
        return;
      }
      const list = getTemplates();
      list.unshift({ id: uid(), name: name, subject: subject, body: body, category: category, created_at: nowIso() });
      setTemplates(list);
      $('tName').value = '';
      $('tSubject').value = '';
      $('tBody').value = '';
      renderTemplates();
      showToast('Template saved');
    };

    // Activity filters
    $('activityFilter').onchange = renderActivity;
    $('activityCampaign').onchange = renderActivity;

    // AI
    $('btnOptimize').onclick = function () {
      try {
        const res = optimizeCopy(
          $('aiText').value,
          $('aiBiz').value,
          $('aiGoal').value,
          $('aiTone').value
        );
        $('aiResults').innerHTML =
          '<div class="card"><div class="row-between"><h3 class="mb-0">Optimized body</h3>' +
          '<button class="btn btn-sm" id="copyOptBody">Copy</button></div><pre class="pre mt-3" id="optBodyPre">' +
          escapeHtml(res.optimized_body) +
          '</pre></div>' +
          '<div class="card mt-4"><h3>Subject line scores</h3>' +
          res.subjects
            .map(function (s) {
              return (
                '<div class="score-row"><div class="score-num">' +
                s.score +
                '</div><div style="flex:1;min-width:0"><div style="font-size:13px;font-weight:600">' +
                escapeHtml(s.subject) +
                '</div><div class="hint">' +
                escapeHtml(s.reason) +
                '</div></div></div>'
              );
            })
            .join('') +
          '</div>' +
          '<div class="card mt-4"><h3>Analysis</h3><div class="hint">Words: ' +
          res.analysis.original_words +
          ' → ' +
          res.analysis.optimized_words +
          ' · ' +
          escapeHtml(res.analysis.compliance) +
          '<br>' +
          escapeHtml(res.analysis.readability) +
          '</div><ul style="margin:10px 0 0;padding-left:18px;font-size:12px;color:#475569">' +
          res.tips
            .map(function (t) {
              return '<li>' + escapeHtml(t) + '</li>';
            })
            .join('') +
          '</ul></div>';
        $('copyOptBody').onclick = function () {
          navigator.clipboard.writeText(res.optimized_body);
          showToast('Copied');
        };
      } catch (e) {
        $('aiResults').innerHTML = '<div class="alert alert-err">' + escapeHtml(e.message) + '</div>';
      }
    };

    // Scheduler
    $('schedHour').onchange = renderScheduler;
    $('schedZone').onchange = renderScheduler;
    $('btnSchedule').onclick = function () {
      const id = $('schedCampaign').value;
      if (!id) {
        showToast('Select a campaign');
        return;
      }
      const timezone = $('schedZone').value;
      const hour = Number($('schedHour').value) || 9;
      const when = nextLocalMorning(timezone, hour);
      const campaigns = getCampaigns();
      const c = campaigns.find(function (x) {
        return x.id === id;
      });
      if (!c) return;
      c.status = 'scheduled';
      c.timezone = timezone;
      c.target_send_hour = hour;
      c.schedule_at = when;
      c.updated_at = nowIso();
      setCampaigns(campaigns);
      const recipients = getRecipients().map(function (r) {
        if (r.campaign_id === id && r.status === 'pending') r.status = 'queued';
        return r;
      });
      setRecipients(recipients);
      $('schedMsg').innerHTML =
        '<div class="alert alert-ok">Held until ~' + hour + ':00 in ' + escapeHtml(timezone) + ' (' + formatDateTime(when) + ')</div>';
      renderScheduler();
    };

    // Settings
    $('btnSaveSettings').onclick = function () {
      const s = getSettings();
      s.senderName = $('setName').value.trim();
      s.throttleMs = Number($('setThrottle').value) || 3000;
      s.defaultTimezone = $('setTz').value;
      s.defaultSendHour = Number($('setHour').value) || 9;
      s.desktopNotifications = $('setDesktop').checked;
      s.trackingEnabled = $('setTracking').checked;
      s.preferGmailSend = $('setPreferGmail').checked;
      setSettings(s);
      showToast('Settings saved to local storage');
    };
    $('btnAddAccount').onclick = function () {
      connectGmailInteractive()
        .then(function () {
          renderAccountManager();
          renderSenderSelects();
          showToast('Account added (' + getAccounts().length + '/' + MAX_GMAIL + ')');
        })
        .catch(function (e) {
          showToast(e.message);
        });
    };
    $('btnEnableDesktop').onclick = function () {
      if (!('Notification' in window)) {
        showToast('Notifications not supported');
        return;
      }
      Notification.requestPermission().then(function (p) {
        if (p === 'granted') {
          const s = getSettings();
          s.desktopNotifications = true;
          setSettings(s);
          $('setDesktop').checked = true;
          new Notification('MailPulse', { body: 'Desktop notifications enabled' });
        }
      });
    };
    $('btnWipe').onclick = wipeAllData;

    $('campaignSearch').addEventListener('input', renderCampaigns);
  }

  // ─── boot ──────────────────────────────────────────────────────
  function init() {
    // Handle local track-open hash (pixel simulation when opened in browser)
    if (location.hash.indexOf('track-open=') === 1) {
      const tok = location.hash.replace('#track-open=', '');
      const r = getRecipients().find(function (x) {
        return x.tracking_token === tok;
      });
      if (r) simulateOpen(r.id);
    }

    bindGlobal();
    updateNotifBadge();
    renderSenderSelects();
    navigate('dashboard');

    // Live refresh dashboard metrics
    setInterval(function () {
      if (currentPage === 'dashboard') renderDashboard();
      updateNotifBadge();
    }, 8000);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
