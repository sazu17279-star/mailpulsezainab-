import { copyFileSync, mkdirSync, existsSync, readdirSync } from 'fs';
import { join } from 'path';

const dist = 'dist';
const index = join(dist, 'index.html');
if (!existsSync(index)) {
  console.error('dist/index.html missing');
  process.exit(1);
}

const routes = [
  'campaigns',
  'composer',
  'settings',
  'extension',
  'activity',
  'templates',
  'scheduler',
  'ai',
  'login',
  'dashboard',
];

for (const r of routes) {
  const dir = join(dist, r);
  mkdirSync(dir, { recursive: true });
  copyFileSync(index, join(dir, 'index.html'));
}

// Nested campaign detail placeholder — client router handles :id; serve app shell
mkdirSync(join(dist, 'campaigns'), { recursive: true });
// For deep links like /campaigns/123, Vercel rewrite must handle; also create a catch-all via 404.html
copyFileSync(index, join(dist, '404.html'));

console.log('[spa-fallback] wrote route shells + 404.html');
