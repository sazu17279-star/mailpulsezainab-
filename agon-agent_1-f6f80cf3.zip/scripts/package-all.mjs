import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { execSync } from 'child_process';
import zlib from 'zlib';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(__dirname, '..');

// Ensure extension zip exists
execSync('node scripts/package-extension.mjs', { cwd: root, stdio: 'inherit' });

const IGNORE_DIRS = new Set([
  'node_modules',
  '.git',
  '.vercel',
  'uploads',
  'dist',
]);
const IGNORE_FILES = new Set(['.env']);
const IGNORE_PREFIXES = ['.env.'];

function shouldSkip(rel) {
  const parts = rel.split(/[/\\]/);
  if (parts.some((p) => IGNORE_DIRS.has(p))) return true;
  const base = parts[parts.length - 1];
  if (IGNORE_FILES.has(base)) return true;
  if (base.startsWith('.env.') && base !== '.env.example') return true;
  if (base.endsWith('.log')) return true;
  return false;
}

function walk(dir, base = root) {
  const out = [];
  for (const name of fs.readdirSync(dir)) {
    if (name === '.' || name === '..') continue;
    const abs = path.join(dir, name);
    const rel = path.relative(base, abs).replace(/\\/g, '/');
    if (shouldSkip(rel)) continue;
    const st = fs.statSync(abs);
    if (st.isDirectory()) out.push(...walk(abs, base));
    else out.push({ abs, rel: `MailPulse/${rel}` });
  }
  return out;
}

function crc32(buf) {
  let c = ~0;
  for (let i = 0; i < buf.length; i++) {
    c ^= buf[i];
    for (let k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xedb88320 : c >>> 1;
  }
  return ~c >>> 0;
}
function u16(n) {
  const b = Buffer.alloc(2);
  b.writeUInt16LE(n, 0);
  return b;
}
function u32(n) {
  const b = Buffer.alloc(4);
  b.writeUInt32LE(n, 0);
  return b;
}

function writeZip(files, dest) {
  const locals = [];
  const centrals = [];
  let offset = 0;
  for (const f of files) {
    const data = fs.readFileSync(f.abs);
    const name = Buffer.from(f.rel, 'utf8');
    const compressed = zlib.deflateRawSync(data);
    const crc = crc32(data);
    const local = Buffer.concat([
      u32(0x04034b50),
      u16(20),
      u16(0),
      u16(8),
      u16(0),
      u16(0),
      u32(crc),
      u32(compressed.length),
      u32(data.length),
      u16(name.length),
      u16(0),
      name,
      compressed,
    ]);
    locals.push(local);
    centrals.push(
      Buffer.concat([
        u32(0x02014b50),
        u16(20),
        u16(20),
        u16(0),
        u16(8),
        u16(0),
        u16(0),
        u32(crc),
        u32(compressed.length),
        u32(data.length),
        u16(name.length),
        u16(0),
        u16(0),
        u16(0),
        u16(0),
        u32(0),
        u32(offset),
        name,
      ])
    );
    offset += local.length;
  }
  const centralDir = Buffer.concat(centrals);
  const end = Buffer.concat([
    u32(0x06054b50),
    u16(0),
    u16(0),
    u16(files.length),
    u16(files.length),
    u32(centralDir.length),
    u32(offset),
    u16(0),
  ]);
  fs.writeFileSync(dest, Buffer.concat([...locals, centralDir, end]));
}

// Copy README to root name users expect
const readmeSrc = path.join(root, 'MAILPULSE-README.md');
if (fs.existsSync(readmeSrc)) {
  fs.copyFileSync(readmeSrc, path.join(root, 'README-MAILPULSE.md'));
}

// Also put extension zip at package-friendly path inside public
const files = walk(root);

// Prefer system zip into a temp staging dir for reliability
const staging = path.join(root, '.package-staging');
const destPublic = path.join(root, 'public', 'MailPulse-Complete.zip');
const destRoot = path.join(root, 'MailPulse-Complete.zip');

function rimraf(p) {
  if (fs.existsSync(p)) fs.rmSync(p, { recursive: true, force: true });
}

try {
  rimraf(staging);
  fs.mkdirSync(path.join(staging, 'MailPulse'), { recursive: true });
  for (const f of files) {
    const target = path.join(staging, f.rel);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.copyFileSync(f.abs, target);
  }
  // Explicit copies for clarity
  const extZip = path.join(root, 'public', 'mailpulse-extension.zip');
  if (fs.existsSync(extZip)) {
    fs.copyFileSync(extZip, path.join(staging, 'MailPulse', 'mailpulse-extension.zip'));
  }

  let ok = false;
  try {
    execSync(`cd "${staging}" && zip -r "${destPublic}" MailPulse -x "*.DS_Store"`, {
      stdio: 'pipe',
    });
    ok = true;
  } catch {
    ok = false;
  }

  if (!ok) {
    const stagedFiles = walk(path.join(staging, 'MailPulse'), path.join(staging));
    // walk returns MailPulse/... already if base is staging — fix
    const list = [];
    function w(dir, base) {
      for (const name of fs.readdirSync(dir)) {
        const abs = path.join(dir, name);
        const rel = path.relative(base, abs).replace(/\\/g, '/');
        if (fs.statSync(abs).isDirectory()) w(abs, base);
        else list.push({ abs, rel });
      }
    }
    w(staging, staging);
    writeZip(list, destPublic);
  }

  fs.copyFileSync(destPublic, destRoot);
  console.log(
    'Wrote',
    destPublic,
    fs.statSync(destPublic).size,
    'bytes —',
    files.length,
    'source files packaged'
  );
} finally {
  rimraf(staging);
}
